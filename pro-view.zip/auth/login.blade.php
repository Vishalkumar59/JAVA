@extends('layouts.user.layout')
@section('title')
    <title>{{ $menus->where('id',12)->first()->navbar }}</title>
@endsection
@section('user-content')
<style>
.logingoogle a{
    width:100%!important;
}

 .icons8-google { 
display: inline-block;
width: 20px;
height: 15px;
background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHg9IjBweCIgeT0iMHB4Igp3aWR0aD0iNDgiIGhlaWdodD0iNDgiCnZpZXdCb3g9IjAgMCA0OCA0OCIKc3R5bGU9IiBmaWxsOiMwMDAwMDA7Ij48cGF0aCBmaWxsPSIjRkZDMTA3IiBkPSJNNDMuNjExLDIwLjA4M0g0MlYyMEgyNHY4aDExLjMwM2MtMS42NDksNC42NTctNi4wOCw4LTExLjMwMyw4Yy02LjYyNywwLTEyLTUuMzczLTEyLTEyYzAtNi42MjcsNS4zNzMtMTIsMTItMTJjMy4wNTksMCw1Ljg0MiwxLjE1NCw3Ljk2MSwzLjAzOWw1LjY1Ny01LjY1N0MzNC4wNDYsNi4wNTMsMjkuMjY4LDQsMjQsNEMxMi45NTUsNCw0LDEyLjk1NSw0LDI0YzAsMTEuMDQ1LDguOTU1LDIwLDIwLDIwYzExLjA0NSwwLDIwLTguOTU1LDIwLTIwQzQ0LDIyLjY1OSw0My44NjIsMjEuMzUsNDMuNjExLDIwLjA4M3oiPjwvcGF0aD48cGF0aCBmaWxsPSIjRkYzRDAwIiBkPSJNNi4zMDYsMTQuNjkxbDYuNTcxLDQuODE5QzE0LjY1NSwxNS4xMDgsMTguOTYxLDEyLDI0LDEyYzMuMDU5LDAsNS44NDIsMS4xNTQsNy45NjEsMy4wMzlsNS42NTctNS42NTdDMzQuMDQ2LDYuMDUzLDI5LjI2OCw0LDI0LDRDMTYuMzE4LDQsOS42NTYsOC4zMzcsNi4zMDYsMTQuNjkxeiI+PC9wYXRoPjxwYXRoIGZpbGw9IiM0Q0FGNTAiIGQ9Ik0yNCw0NGM1LjE2NiwwLDkuODYtMS45NzcsMTMuNDA5LTUuMTkybC02LjE5LTUuMjM4QzI5LjIxMSwzNS4wOTEsMjYuNzE1LDM2LDI0LDM2Yy01LjIwMiwwLTkuNjE5LTMuMzE3LTExLjI4My03Ljk0NmwtNi41MjIsNS4wMjVDOS41MDUsMzkuNTU2LDE2LjIyNyw0NCwyNCw0NHoiPjwvcGF0aD48cGF0aCBmaWxsPSIjMTk3NkQyIiBkPSJNNDMuNjExLDIwLjA4M0g0MlYyMEgyNHY4aDExLjMwM2MtMC43OTIsMi4yMzctMi4yMzEsNC4xNjYtNC4wODcsNS41NzFjMC4wMDEtMC4wMDEsMC4wMDItMC4wMDEsMC4wMDMtMC4wMDJsNi4xOSw1LjIzOEMzNi45NzEsMzkuMjA1LDQ0LDM0LDQ0LDI0QzQ0LDIyLjY1OSw0My44NjIsMjEuMzUsNDMuNjExLDIwLjA4M3oiPjwvcGF0aD48L3N2Zz4=') 50% 50% no-repeat;
background-size: 100%; }

.login_message p {
    text-align: center;
    font-size: 16px;
    margin: 0;
}

p {
    color: #999999;
    font-size: 14px;
    line-height: 24px;
}
</style>

<!--===BREADCRUMB PART START====-->
  <section class="wsus__breadcrumb" style="background: url({{ url($banner_image->image) }});">
    <div class="wsus_bread_overlay">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h4>{{ $menus->where('id',28)->first()->navbar }}</h4>
                    <nav style="--bs-breadcrumb-divider: '-';" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('home') }}">{{ $menus->where('id',1)->first()->navbar }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ $menus->where('id',28)->first()->navbar }}</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>
<!--===BREADCRUMB PART END====-->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.5.3/js/bootstrapValidator.min.js" integrity="sha512-Vp2UimVVK8kNOjXqqj/B0Fyo96SDPj9OCSm1vmYSrLYF3mwIOBXh/yRZDVKo8NemQn1GUjjK0vFJuCSCkYai/A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.5.3/css/bootstrapValidator.min.css" integrity="sha512-YDChav1pUAodyH1Ja7PIpEDUOoFROpZi5Lb7pY8+9+kU8UTr3J8SI8QO7SRuf4qdDKb5OI0xSt4Vk1wiYjBXgw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<section class="wsus__logon mt_45 mb_45">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-5 col-md-6">
                <div class="wsus__login_form">
                <h3>{{ $websiteLang->where('lang_key','if_account_exist')->first()->custom_text }} {{ $websiteLang->where('lang_key','login_here')->first()->custom_text }}</h3>
                <form id="loginFormSubmit"  class="row g-3 needs-validation" novalidate>
                        @csrf
                        <div class="form-group">
                            <div class="input-group input-group-lg">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fad fa-user-circle"></i>
                                    </span>
                                </div>
                                {{-- <input id="loginEmail" class="form-control form-control-lg" type="email" name="email" placeholder="{{ $websiteLang->where('lang_key','email')->first()->custom_text }}" value="{{ env('PROJECT_MODE')==0 ? 'agent@gmail.com' : '' }}"> --}}
                                <input type="email" placeholder="{{ $websiteLang->where('lang_key','email')->first()->custom_text }}" value="{{ env('PROJECT_MODE')==0 ? 'agent@gmail.com' : '' }}" class="form-control form-control-lg" id="loginEmail" name="email" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group input-group-lg">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fas fa-key"></i>
                                    </span>
                                </div>
                                <input type="password"   placeholder="{{ $websiteLang->where('lang_key','pass')->first()->custom_text }}" value="{{ env('PROJECT_MODE')==0 ? 1234 : '' }}" class="form-control form-control-lg" id="loginPassword" name="password" required>
                                {{-- <input id="loginPassword" class="form-control form-control-lg" type="password" name="password" placeholder="{{ $websiteLang->where('lang_key','pass')->first()->custom_text }}" value="{{ env('PROJECT_MODE')==0 ? 1234 : '' }}"> --}}
                            </div>
                        </div>

                        @if($setting->allow_captcha==1)
                            <div class="form-group mt-2">
                                <div class="input-group input-group-lg">
                                    <div class="g-recaptcha" data-sitekey="{{ $setting->captcha_key }}"></div>
                                </div>
                            </div>
                            @endif
                        <div class="wsus__check_area">
                            <div class="form-check">
                                <input name="remember" class="form-check-input" type="checkbox" value="" id="flexCheckDefault" required>
                                <label class="form-check-label" for="flexCheckDefault">
                                    {{ $websiteLang->where('lang_key','remember')->first()->custom_text }}
                                </label>
                            </div>
                            <a href="{{ route('forget.password') }}">{{ $websiteLang->where('lang_key','forget_your_pass')->first()->custom_text }}</a>
                        </div>

                        <div class="wsus__reg_forget">
                            <button class="common_btn " type="submit" id="userLoginBtn">{{ $websiteLang->where('lang_key','login')->first()->custom_text }}</button>

                            {{-- <a href="{{ route('registration') }}">Don't have account! Register Here</a> --}}
                            <div class="login_message">
								<p>Don&rsquo;t have an account ? <a href="{{ route('registration') }}"> Sign up </a> </p>
							</div>
                        </div>
                         <div class="logingoogle mt-2">
                            <a href="{{route('logingoogle')}}" class="btn btn-google btn-user btn-block border"><i class="icons8-google"></i> Sign up with Google </a>
                             <a href="{{route('facebooklogin')}}" class="btn btn-google btn-user btn-block  mt-2" style="background-color:#395697; color:hsl(0,0%,100%);"><i class="fab fa-facebook-f fa-fw"></i> Sign up with Facebook </a>
                        </div>
                       
                    </form>
               </div>
            </div>
            
        </div>
    </div>

</section>
  <script>
    // Example starter JavaScript for disabling form submissions if there are invalid fields
(function () {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  var forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
})()
  </script>



@php
    $search_url = request()->fullUrl();
@endphp


<script>
    (function($) {
    "use strict";
    $(document).ready(function () {
        $("#userLoginBtn").on('click',function(e) {
            e.preventDefault();
            $.ajax({
                url: "{{ route('login') }}",
                type:"post",
                data:$('#loginFormSubmit').serialize(),
                success:function(response){
                    console.log(response);
                    if(response.success){
                        // window.location.href = "{{ route('user.dashboard')}}";
                       window.location.href = "{{ url()->previous()}}";
                        toastr.success(response.success)

                    }
                    if(response.error){
                        toastr.error(response.error)

                        var query_url='<?php echo $search_url; ?>';
                        // window.location.href = query_url;

                    }
                },
                error:function(response){
                    console.log(response);  
                    if(response.responseJSON.errors.email)toastr.error(response.responseJSON.errors.email[0])
                    if(response.responseJSON.errors.password){
                        toastr.error(response.responseJSON.errors.password[0])
                    }//else{
                        //toastr.error('Please Complete the recaptcha to submit the form')
                    //}


                }

            });


        })


        $(document).on('keyup', '#loginEmail, #loginPassword', function (e) {
            if(e.keyCode == 13){
                e.preventDefault();

                $.ajax({
                url: "{{ route('login') }}",
                type:"post",
                data:$('#loginFormSubmit').serialize(),
                success:function(response){
                    if(response.success){
                        window.location.href = "{{ route('user.dashboard')}}";
                       window.location.href = "{{ url()->previous()}}";
                        toastr.success(response.success)

                    }
                   
                    if(response.error){
                        toastr.error(response.error)

                        var query_url='<?php echo $search_url; ?>';
                        // window.location.href = query_url;

                    }
                },
                error:function(response){


                    if(response.responseJSON.errors.email)toastr.error(response.responseJSON.errors.email[0])
                    if(response.responseJSON.errors.password){
                        toastr.error(response.responseJSON.errors.password[0])
                    }//else{
                        //toastr.error('Please Complete the recaptcha to submit the form')
                    //}

                }

            });
            }

        })



        $("#registerBtnn").on('click',function(e) {
            e.preventDefault();
                // project demo mode check
                var isDemo="{{ env('PROJECT_MODE') }}"
                var demoNotify="{{ env('NOTIFY_TEXT') }}"
                if(isDemo==0){
                    toastr.error(demoNotify);
                    return;
                }
                // end
            $("#reg-spinner").removeClass('d-none')
            $("#registerBtnn").addClass('custom-opacity')
            $("#registerBtnn").attr('disabled',true);
            $.ajax({
                url: "{{route('otp-verify')}}",
                type:"post",
                data:$('#registerFormSubmitt').serialize(),
                success:function(response){
                    
                    if(response.success){
                        $("#registerFormSubmitt").trigger("reset");
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtnn").removeClass('custom-opacity')
                        $("#registerBtnn").attr('disabled',false);
                        toastr.success(response.success)

                        window.location.href = "{{route('otp-verification')}}";
                    }
                    if(response.error){
                        toastr.error(response.error)

                        var query_url='<?php echo $search_url; ?>';
                        window.location.href = query_url;
                    }
                },
                error:function(response){
                   

                    if(response.responseJSON.errors.email){
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtnn").removeClass('custom-opacity')
                        $("#registerBtnn").attr('disabled',false);
                        $("#registerBtnn").addClass('site-btn-effect')
                        toastr.error(response.responseJSON.errors.email[0])
                    }

                    if(response.responseJSON.errors.password){
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtnn").removeClass('custom-opacity')
                        $("#registerBtnn").attr('disabled',false);
                        $("#registerBtnn").addClass('site-btn-effect')
                        toastr.error(response.responseJSON.errors.password[0])
                    }//else{
                       // $("#reg-spinner").addClass('d-none')
                       // $("#registerBtnn").removeClass('custom-opacity')
                       // $("#registerBtnn").attr('disabled',false);
                        //$("#registerBtnn").addClass('site-btn-effect')
                      //  toastr.error('Please Complete the recaptcha to submit the form')
                    //}



                }

            });


        })

        $(document).on('keyup', '#regiEmail, #regNumber', function (e) {
            if(e.keyCode == 13){
                e.preventDefault();
                // project demo mode check
                var isDemo="{{ env('PROJECT_MODE') }}"
                var demoNotify="{{ env('NOTIFY_TEXT') }}"
                if(isDemo==0){
                    toastr.error(demoNotify);
                    return;
                }
                // end
            $("#reg-spinner").removeClass('d-none')
            $("#registerBtn").addClass('custom-opacity')
            $("#registerBtn").attr('disabled',true);
            $.ajax({
                url: "{{ route('register') }}",
                type:"post",
                data:$('#registerFormSubmitt').serialize(),
                success:function(response){
                    if(response.success){
                        $("#registerFormSubmitt").trigger("reset");
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        toastr.success(response.success)
                    }
                    if(response.error){
                        toastr.error(response.error)
                        var query_url='<?php echo $search_url; ?>';
                        window.location.href = query_url;
                    }
                },
                error:function(response){
                    

                    if(response.responseJSON.errors.email){
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        $("#registerBtn").addClass('site-btn-effect')
                        toastr.error(response.responseJSON.errors.email[0])
                    }

                    if(response.responseJSON.errors.password){
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        $("#registerBtn").addClass('site-btn-effect')
                        toastr.error(response.responseJSON.errors.password[0])
                    }//else{
                      //  $("#reg-spinner").addClass('d-none')
                      //  $("#registerBtn").removeClass('custom-opacity')
                      //  $("#registerBtn").attr('disabled',false);
                      //  $("#registerBtn").addClass('site-btn-effect')
                       // toastr.error('Please Complete the recaptcha to submit the form')
                   // }


                }

            });

            }

        })

    });

    })(jQuery);
</script>


@endsection
