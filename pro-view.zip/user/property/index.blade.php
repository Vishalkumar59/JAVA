@extends('layouts.user.layout')
@section('title')
<title>{{ $seo_text->title }}</title>
@endsection
@section('meta')
<meta name="description" content="{{ $seo_text->meta_description }}">
@endsection
@section('user-content')

{{-- @dd($menus->where('id', 2)->first()->navbar); --}}
<!--===BREADCRUMB PART START====-->
<section class="wsus__breadcrumb" style="background: url({{ url($banner_image->image) }});">
    <div class="wsus_bread_overlay">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h4>
                        {{ $menus->where('id',2)->first()->navbar }}
                    </h4>
                    <nav style="--bs-breadcrumb-divider: '-';" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('home') }}">{{ $menus->where('id',
                                    1)->first()->navbar }}</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">
                                {{ $menus->where('id', 2)->first()->navbar }}</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>
<!--===BREADCRUMB PART END====-->


@php
$search_url = request()->fullUrl();
$get_url = substr($search_url, strpos($search_url, '?') + 1);

$grid_url = '';
$list_url = '';
$isSortingId = 0;

$page_type = request()->get('page_type');
if ($page_type == 'list_view') {
$grid_url = str_replace('page_type=list_view', 'page_type=grid_view', $search_url);
$list_url = str_replace('page_type=list_view', 'page_type=list_view', $search_url);
} elseif ($page_type == 'grid_view') {
$grid_url = str_replace('page_type=grid_view', 'page_type=grid_view', $search_url);
$list_url = str_replace('page_type=grid_view', 'page_type=list_view', $search_url);
}
if (request()->has('sorting_id')) {
$isSortingId = 1;
}
@endphp

<!--=====PROPERTY PAGE START=====-->
<section class="wsus__property_page mt_45 mb_45">
    <div class="container">
        <div class="row">
            <div class="col-xl-8">
                <div class="row">
                    <div class="col-12">
                        <div class="wsus__property_topbar d-flex justify-content-between mb-4">
                            <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
                                        aria-selected="true">
                                        <i class="fas fa-th-large"></i>
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                                        data-bs-target="#pills-profile" type="button" role="tab"
                                        aria-controls="pills-profile" aria-selected="false">
                                        <i class="far fa-stream"></i>
                                    </button>
                                </li>
                            </ul>
                            <div class="wsus__property_top_select">
                                @if ($isSortingId == 1)
                                <select class="select_2" id="sortingId">
                                    {{-- <option {{ request()->get('sorting_id')==1 ? 'selected' : '' }} value="1">{{
                                        $websiteLang->where('lang_key','default_order')->first()->custom_text }}
                                    </option>

                                    <option {{ request()->get('sorting_id')==2 ? 'selected' : '' }} value="2">{{
                                        $websiteLang->where('lang_key','most_views')->first()->custom_text }}</option>

                                    <option {{ request()->get('sorting_id')==3 ? 'selected' : '' }} value="3">{{
                                        $websiteLang->where('lang_key','featured')->first()->custom_text }}</option>

                                    <option {{ request()->get('sorting_id')==4 ? 'selected' : '' }} value="4">{{
                                        $websiteLang->where('lang_key','top')->first()->custom_text }}</option>

                                    <option {{ request()->get('sorting_id')==5 ? 'selected' : '' }} value="5">{{
                                        $websiteLang->where('lang_key','new')->first()->custom_text }}</option>

                                    <option {{ request()->get('sorting_id')==6 ? 'selected' : '' }} value="6">{{
                                        $websiteLang->where('lang_key','urgent')->first()->custom_text }}</option>

                                    <option {{ request()->get('sorting_id')==7 ? 'selected' : '' }} value="7">{{
                                        $websiteLang->where('lang_key','oldest')->first()->custom_text }}</option> --}}

                                    <option {{ request()->get('sorting_id') == 1 ? 'selected' : '' }}
                                        value="1">
                                        {{ $websiteLang->where('lang_key', 'popularity')->first()->custom_text }}
                                    </option>
                                    <option {{ request()->get('sorting_id') == 2 ? 'selected' : '' }}
                                        value="1">
                                        {{ $websiteLang->where('lang_key', 'price_high_to_low')->first()->custom_text }}
                                    </option>
                                    <option {{ request()->get('sorting_id') == 3 ? 'selected' : '' }}
                                        value="1">
                                        {{ $websiteLang->where('lang_key', 'price_low_to_high')->first()->custom_text }}
                                    </option>
                                    <option {{ request()->get('sorting_id') == 4 ? 'selected' : '' }}
                                        value="1">
                                        {{ $websiteLang->where('lang_key', ' newest_first')->first()->custom_text }}
                                    </option>

                                </select>
                                @else
                                <select class="select_2" id="sortingId">
                                    {{-- <option value="1">{{
                                        $websiteLang->where('lang_key','default_order')->first()->custom_text }}
                                    </option>
                                    <option value="2">{{
                                        $websiteLang->where('lang_key','most_views')->first()->custom_text }}</option>
                                    <option value="3">{{
                                        $websiteLang->where('lang_key','featured')->first()->custom_text }}</option>
                                    <option value="4">{{ $websiteLang->where('lang_key','top')->first()->custom_text }}
                                    </option>
                                    <option value="5">{{ $websiteLang->where('lang_key','new')->first()->custom_text }}
                                    </option>
                                    <option value="6">{{ $websiteLang->where('lang_key','urgent')->first()->custom_text
                                        }}</option>
                                    <option value="7">{{ $websiteLang->where('lang_key','oldest')->first()->custom_text
                                        }}</option> --}}
                                    <option value="1">
                                        {{ $websiteLang->where('lang_key', 'popularity')->first()->custom_text }}
                                    </option>
                                    <option value="2">
                                        {{ $websiteLang->where('lang_key', 'price_high_to_low')->first()->custom_text }}
                                    </option>
                                    <option value="3">
                                        {{ $websiteLang->where('lang_key', 'price_low_to_high')->first()->custom_text }}
                                    </option>
                                    <option value="4">
                                        {{ $websiteLang->where('lang_key', 'newest_first')->first()->custom_text }}
                                    </option>
                                </select>
                                @endif
                            </div>
                        </div>
                    </div>

                    @php
                    $isActivePropertyQty = 0;
                    foreach ($properties as $value) {
                    if ($value->expired_date == null) {
                    $isActivePropertyQty += 1;
                    } elseif ($value->expired_date >= date('Y-m-d')) {
                    $isActivePropertyQty += 1;
                    }
                    }
                    @endphp

                    <div class="col-12">
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                                aria-labelledby="pills-home-tab">
                                <div class="row">

                                    @if ($isActivePropertyQty > 0)
                                    @foreach ($properties as $item)
                                    @if ($item->expired_date == null)
                                    <div class="col-xl-6 col-md-6">
                                        <div class="wsus__single_property">
                                            <div class="wsus__single_property_img">
                                                <img src="{{ asset($item->thumbnail_image) }}" alt="properties"
                                                    class="img-fluid w-100">

                                                @if ($item->category_id == 1)
                                                <span class="sale">{{ $item->propertyPurpose->custom_purpose }}</span>
                                                @elseif($item->category_id == 2)
                                                <span class="sale">{{ $item->propertyPurpose->custom_purpose }}</span>
                                                @endif
                                                @if ($item->category_id == 2)
                                                <span class="sale">{{ $item->propertyPurpose->custom_purpose }}</span>
                                                @endif

                                                {{-- @if ($item->urgent_property == 1)
                                                <span class="rent">{{ $websiteLang->where('lang_key',
                                                    'urgent')->first()->custom_text }}</span>
                                                @endif --}}

                                            </div>
                                            <div class="wsus__single_property_text">
                                                @if ($item->category_id == 1)
                                                <span class="tk">{{ $currency->currency_icon }}{{
                                                    propAmount($item->price) }}</span>
                                                @elseif ($item->category_id == 2)
                                                <span class="tk">{{ $currency->currency_icon }}{{
                                                    propAmount($item->price) }}
                                                    /
                                                    @if ($item->period == 'Daily')
                                                    <span>{{ $websiteLang->where('lang_key',
                                                        'daily')->first()->custom_text }}</span>
                                                    @elseif ($item->period == 'Monthly')
                                                    <span>{{ $websiteLang->where('lang_key',
                                                        'monthly')->first()->custom_text }}</span>
                                                    @elseif ($item->period == 'Yearly')
                                                    <span>{{ $websiteLang->where('lang_key',
                                                        'yearly')->first()->custom_text }}</span>
                                                    @endif
                                                </span>
                                                @endif

                                                <a href="{{ route('property.details', $item->slug) }}"
                                                    class="title w-100">{{ $item->title }}</a>
                                                <ul class="d-flex flex-wrap justify-content-between">
                                                    @if(!empty($item->number_of_bedroom))
                                                    <li><i class="fal fa-bed"></i>
                                                        {{ $item->number_of_bedroom }}
                                                        {{ $websiteLang->where('lang_key', 'bed')->first()->custom_text
                                                        }}
                                                    </li>
                                                    @endif
                                                    @if(!empty($item->number_of_bathroom))
                                                    <li><i class="fal fa-shower"></i>
                                                        {{ $item->number_of_bathroom }}
                                                        {{ $websiteLang->where('lang_key', 'bath')->first()->custom_text
                                                        }}
                                                    </li>
                                                    @endif
                                                    @if(!empty($item->area))
                                                    <li><i class="fal fa-draw-square"></i>
                                                        {{ $item->area }}
                                                        {{ $websiteLang->where('lang_key',
                                                        'sqft_s')->first()->custom_text }}
                                                    </li>
                                                    @endif
                                                </ul>
                                                <div class="wsus__single_property_footer d-flex justify-content-between align-items-center">
                                                    <a href="@if (!empty($item->propertyType)) {{ route('search-property', ['page_type' => 'list_view', 'property_type' => $item->propertyType->id]) }} @endif"
                                                        class="category">
                                                        @if (!empty($item->propertyType))
                                                        {{ $item->propertyType->type }}
                                                        @endif
                                                    </a>                
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @elseif($item->expired_date >= date('Y-m-d'))
                                    <div class="col-xl-6 col-md-6">
                                        <div class="wsus__single_property">
                                            <div class="wsus__single_property_img">
                                                <img src="{{ asset($item->thumbnail_image) }}" alt="properties"
                                                    class="img-fluid w-100">

                                                @if ($item->category_id == 1)
                                                <span class="sale">{{ $item->propertyPurpose->custom_purpose }}</span>
                                                @elseif($item->category_id == 2)
                                                <span class="sale">{{ $item->propertyPurpose->custom_purpose }}</span>
                                                @endif

                                                {{-- @if ($item->urgent_property == 1)
                                                <span class="rent">{{ $websiteLang->where('lang_key',
                                                    'urgent')->first()->custom_text }}</span>
                                                @endif --}}

                                            </div>
                                            <div class="wsus__single_property_text">
                                                @if ($item->category_id == 1)
                                                <span class="tk">{{ $currency->currency_icon }}{{
                                                    propAmount($item->price) }}</span>
                                                @elseif ($item->category_id == 2)
                                                <span class="tk">{{ $currency->currency_icon }}{{
                                                    propAmount($item->price) }}
                                                    /
                                                    @if ($item->period == 'Daily')
                                                    <span>{{ $websiteLang->where('lang_key',
                                                        'daily')->first()->custom_text }}</span>
                                                    @elseif ($item->period == 'Monthly')
                                                    <span>{{ $websiteLang->where('lang_key',
                                                        'monthly')->first()->custom_text }}</span>
                                                    @elseif ($item->period == 'Yearly')
                                                    <span>{{ $websiteLang->where('lang_key',
                                                        'yearly')->first()->custom_text }}</span>
                                                    @endif
                                                </span>
                                                @endif

                                                <a href="{{ route('property.details', $item->slug) }}"
                                                    class="title w-100">{{ $item->title }}</a>
                                                <ul class="d-flex flex-wrap justify-content-between">
                                                    <li><i class="fal fa-bed"></i>
                                                        {{ $item->number_of_bedroom }}
                                                        {{ $websiteLang->where('lang_key', 'bed')->first()->custom_text
                                                        }}
                                                    </li>
                                                    <li><i class="fal fa-shower"></i>
                                                        {{ $item->number_of_bathroom }}
                                                        {{ $websiteLang->where('lang_key', 'bath')->first()->custom_text
                                                        }}
                                                    </li>
                                                    <li><i class="fal fa-draw-square"></i>
                                                        {{ $item->area }}
                                                        {{ $websiteLang->where('lang_key',
                                                        'sqft_s')->first()->custom_text }}
                                                    </li>
                                                </ul>
                                               <div
                                                    class="wsus__single_property_footer d-flex justify-content-between align-items-center">
                                                    <a href="@if (!empty($item->propertyType)) {{ route('search-property', ['page_type' => 'list_view', 'property_type' => $item->propertyType->id]) }} @endif"
                                                        class="category">
                                                        @if (!empty($item->propertyType))
                                                        {{ $item->propertyType->type }}
                                                        @endif
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                    @endforeach
                                    @else
                                    <div class="col-12 text-center">
                                        <h3 class="text-danger">
                                            {{ $websiteLang->where('lang_key',
                                            'property_not_found')->first()->custom_text }}
                                        </h3>
                                    </div>
                                    @endif


                                </div>
                            </div>
                            <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                aria-labelledby="pills-profile-tab">
                                <div class="row list_view">
                                    @if ($isActivePropertyQty > 0)
                                    @foreach ($properties->where('top_property', 1) as $item)
                                    @if ($item->expired_date == null)
                                    <div class="col-12">
                                        <div class="wsus__single_property">
                                            <div class="wsus__single_property_img">
                                                <img src="{{ asset($item->thumbnail_image) }}" alt="properties"
                                                    class="img-fluid w-100">
                                            </div>
                                            <div class="wsus__single_property_text">

                                                @if ($item->category_id == 1)
                                                <span class="sale">{{ $item->propertyPurpose->custom_purpose }}</span>
                                                @elseif($item->category_id == 2)
                                                <span class="sale">{{ $item->propertyPurpose->custom_purpose }}</span>
                                                @endif



                                                @if ($item->category_id == 1)
                                                <span class="tk">{{ $currency->currency_icon }}{{
                                                    propAmount($item->price) }}</span>
                                                @elseif ($item->category_id == 2)
                                                <span class="tk">{{ $currency->currency_icon }}{{
                                                    propAmount($item->price) }}
                                                    /
                                                    @if ($item->period == 'Daily')
                                                    <span>{{ $websiteLang->where('lang_key',
                                                        'daily')->first()->custom_text }}</span>
                                                    @elseif ($item->period == 'Monthly')
                                                    <span>{{ $websiteLang->where('lang_key',
                                                        'monthly')->first()->custom_text }}</span>
                                                    @elseif ($item->period == 'Yearly')
                                                    <span>{{ $websiteLang->where('lang_key',
                                                        'yearly')->first()->custom_text }}</span>
                                                    @endif
                                                </span>
                                                @endif

                                                <a href="{{ route('property.details', $item->slug) }}"
                                                    class="title w-100">{{ $item->title }}</a>
                                                <ul class="d-flex flex-wrap justify-content-between">
                                                    @if(!empty($item->number_of_bedroom ))
                                                    <li><i class="fal fa-bed"></i>
                                                        {{ $item->number_of_bedroom }}
                                                        {{ $websiteLang->where('lang_key', 'bed')->first()->custom_text
                                                        }}
                                                    </li>
                                                    @endif
                                                    @if(!empty($item->number_of_bathroom ))
                                                    <li><i class="fal fa-shower"></i>
                                                        {{ $item->number_of_bathroom }}
                                                        {{ $websiteLang->where('lang_key', 'bath')->first()->custom_text
                                                        }}
                                                    </li>
                                                    @endif
                                                    @if(!empty($item->area ))
                                                    <li><i class="fal fa-draw-square"></i>
                                                        {{ $item->area }}
                                                        {{ $websiteLang->where('lang_key',
                                                        'sqft_s')->first()->custom_text }}
                                                    </li>
                                                    @endif
                                                </ul>
                                                <div
                                                    class="wsus__single_property_footer d-flex justify-content-between align-items-center">
                                                    <a href="@if (!empty($item->propertyType)) {{ route('search-property', ['page_type' => 'list_view', 'property_type' => $item->propertyType->id]) }} @endif"
                                                        class="category">
                                                        @if (!empty($item->propertyType))
                                                        {{ $item->propertyType->type }}
                                                        @endif
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    @elseif($item->expired_date >= date('Y-m-d'))
                                    <div class="col-12">
                                        <div class="wsus__single_property">
                                            <div class="wsus__single_property_img">
                                                <img src="{{ asset($item->thumbnail_image) }}" alt="properties"
                                                    class="img-fluid w-100">
                                            </div>
                                            <div class="wsus__single_property_text">

                                                @if ($item->category_id == 1)
                                                <span class="sale">{{ $item->propertyPurpose->custom_purpose }}</span>
                                                @elseif($item->category_id == 2)
                                                <span class="sale">{{ $item->propertyPurpose->custom_purpose }}</span>
                                                @endif



                                                @if ($item->category_id == 1)
                                                <span class="tk">{{ $currency->currency_icon }}{{
                                                    propAmount($item->price) }}</span>
                                                @elseif ($item->category_id == 2)
                                                <span class="tk">{{ $currency->currency_icon }}{{
                                                    propAmount($item->price) }}
                                                    /
                                                    @if ($item->period == 'Daily')
                                                    <span>{{ $websiteLang->where('lang_key',
                                                        'daily')->first()->custom_text }}</span>
                                                    @elseif ($item->period == 'Monthly')
                                                    <span>{{ $websiteLang->where('lang_key',
                                                        'monthly')->first()->custom_text }}</span>
                                                    @elseif ($item->period == 'Yearly')
                                                    <span>{{ $websiteLang->where('lang_key',
                                                        'yearly')->first()->custom_text }}</span>
                                                    @endif
                                                </span>
                                                @endif

                                                <a href="{{ route('property.details', $item->slug) }}"
                                                    class="title w-100">{{ $item->title }}</a>
                                                <ul class="d-flex flex-wrap justify-content-between">
                                                    @if(!empty($item->number_of_bedroom))
                                                    <li><i class="fal fa-bed"></i>
                                                        {{ $item->number_of_bedroom }}
                                                        {{ $websiteLang->where('lang_key', 'bed')->first()->custom_text
                                                        }}
                                                    </li>
                                                    @endif
                                                    @if(!empty($item->number_of_bathroom))
                                                    <li><i class="fal fa-shower"></i>
                                                        {{ $item->number_of_bathroom }}
                                                        {{ $websiteLang->where('lang_key', 'bath')->first()->custom_text
                                                        }}
                                                    </li>
                                                    @endif
                                                    @if(!empty($item->area))
                                                    <li><i class="fal fa-draw-square"></i>
                                                        {{ $item->area }}
                                                        {{ $websiteLang->where('lang_key',
                                                        'sqft_s')->first()->custom_text }}
                                                    </li>
                                                    @endif
                                                </ul>

                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                    @endforeach
                                    @else
                                    <div class="col-12 text-center">
                                        <h3 class="text-danger">
                                            {{ $websiteLang->where('lang_key',
                                            'property_not_found')->first()->custom_text }}
                                        </h3>
                                    </div>
                                    @endif


                                </div>
                            </div>
                        </div>
                    </div>
                    @if ($isActivePropertyQty > 0)
                    <div class="col-12">
                        {{ $properties->links('user.paginator') }}
                    </div>
                    @endif
                </div>
            </div>


            <div class="col-xl-4">
                <div class="wsus__search_property" id="sticky_sidebar">
                    <h3>{{ $websiteLang->where('lang_key', 'find_property')->first()->custom_text }} </h3>
                    <form method="GET" action="{{ route('search-property') }}">
                        <div class="wsus__single_property_search">
                            <label>{{ $websiteLang->where('lang_key', 'keyword')->first()->custom_text }}</label>
                            <input type="text"
                                placeholder="{{ $websiteLang->where('lang_key', 'search_type')->first()->custom_text }}"
                                name="search">
                        </div>
                        <input type="hidden" name="page_type" value="{{ $page_type }}">
                        <div class="wsus__single_property_search">
                            <label for="city">{{ $websiteLang->where('lang_key', 'city')->first()->custom_text }}<span
                                    class="text-danger">*</span></label>

                            <select name="city" class="select_2" id="city" required>
                                <option value="">
                                    {{ $websiteLang->where('lang_key', 'select_city')->first()->custom_text }}
                                </option>

                                @foreach ($cities as $item)
                                <option value="{{ $item->id }}">
                                    {{ $item->name . ', ' . $item->countryState->name . ', ' .
                                    $item->countryState->country->name }}
                                </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="wsus__single_property_search">
                            <label>{{ $websiteLang->where('lang_key', 'location')->first()->custom_text }}</label>
                            <select class="select_2" name="location" id="location">
                                <option value="">
                                    {{ $websiteLang->where('lang_key', 'location')->first()->custom_text }}</option>
                                @foreach ($locality as $locality_item)
                                <option value="{{ $locality_item->locality_id }}">
                                    {{ $locality_item->locality_name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="wsus__single_property_search">
                            <label>{{ $websiteLang->where('lang_key', 'property_purpose')->first()->custom_text
                                }}</label>
                            <select class="select_2" id="property_category" name="purpose_type">
                                <option value="">
                                    {{ $websiteLang->where('lang_key', 'any')->first()->custom_text }}</option>

                                @foreach ($propertyCategoty as $categorylist)
                                <option {{($where_case['category_id']==$categorylist->categories_id) ? 'selected' : ''}}
                                    value="{{ $categorylist->categories_id }}">
                                    {{ $categorylist->categories_name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="wsus__single_property_search">
                            <label>{{ $websiteLang->where('lang_key', 'property_category')->first()->custom_text
                                }}</label>
                            <select class="select_2" id="property_type" name="property_type">
                                <option value="">
                                    {{ $websiteLang->where('lang_key', 'property_category')->first()->custom_text }}
                                </option>
                                @foreach ($propertyTypes as $property_type_item)

                                <option 
                                    value="{{ $property_type_item->id }}">{{ $property_type_item->type }}
                                </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="wsus__single_property_search_check">
                            <div class="accordion" id="accordionExample">
                                <h5><label>{{ $websiteLang->where('lang_key', 'aminities')->first()->custom_text
                                        }}</label>
                                    <h5>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header" id="headingThree">

                                                <button class="accordion-button collapsed" type="button"
                                                    data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                                    aria-expanded="false" aria-controls="collapseThree">
                                                    {{ $websiteLang->where('lang_key', 'any')->first()->custom_text }}
                                                </button>
                                            </h2>

                                            <div id="collapseThree" class="accordion-collapse collapse"
                                                aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                                <div class="accordion-body">
                                                    @foreach ($aminities as $aminity)
                                                    <div class="form-check">
                                                        <input name="aminity[]" class="form-check-input" type="checkbox"
                                                            value="{{ $aminity->id }}"
                                                            id="flexCheckDefault-{{ $aminity->id }}">
                                                        <label class="form-check-label"
                                                            for="flexCheckDefault-{{ $aminity->id }}">
                                                            {{ $aminity->aminity }}
                                                        </label>
                                                    </div>
                                                    @endforeach
                                                </div>
                                            </div>
                                        </div>
                            </div>
                        </div>


                        @php
                        $searhpincode = request()->get('pincode');
                        $isCollapse = false;
                        if (request()->has('pincode')) {
                        $isCollapse = true;
                        }
                        @endphp
                        <div class="wsus__single_property_search_check">
                            <div class="accordion" id="accordionExample">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingThree">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapsePincode"
                                            aria-expanded="false" aria-controls="collapseThree">
                                            {{ $websiteLang->where('lang_key', 'pincode')->first()->custom_text }}
                                        </button>
                                    </h2>
                                    <div id="collapsePincode"
                                        class="accordion-collapse collapse {{ $isCollapse ? 'show' : '' }}"
                                        aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                        <div class="accordion-body" id="pincode">
                                            @if (request()->has('pincode'))
                                            @foreach ($propertylist as $property)
                                            @php
                                            $isChecked = false;
                                            @endphp
                                            @foreach ($searhpincode as $seachpin)
                                            @if ($seachpin == $property->id)
                                            @php
                                            $isChecked = true;
                                            @endphp
                                            @endif
                                            @endforeach

                                            <div class="form-check">
                                                <input {{ $isChecked ? 'checked' : '' }} name="pincode[]"
                                                    class="form-check-input" type="checkbox" value="{{ $property->id }}"
                                                    id="flexCheckDefault-{{ $property->id }}">

                                                <label class="form-check-label"
                                                    for="flexCheckDefault-{{ $property->id }}">
                                                    {{ $property->pincode }}
                                                </label>
                                            </div>
                                            @endforeach
                                            @else
                                            @foreach ($propertylist as $property)
                                            <div class="form-check">
                                                <input name="pincode[]" class="form-check-input" type="checkbox"
                                                    value="{{ $property->id }}"
                                                    id="flexCheckDefault-{{ $property->id }}">

                                                <label class="form-check-label"
                                                    for="flexCheckDefault-{{ $property->id }}">
                                                    {{ $property->pincode }}
                                                </label>
                                            </div>
                                            @endforeach
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>



                        <div class="wsus__single_property_search">
                            <label for="bank">{{ $websiteLang->where('lang_key', 'bank')->first()->custom_text
                                }}</label>
                            <select name="bank" class="select_2" id="bank">
                                <option value="">
                                    {{ $websiteLang->where('lang_key', 'select_bank')->first()->custom_text }}
                                </option>

                                @foreach ($banklist as $bank)
                                <option value="{{ $bank->id }}">{{ $bank->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="wsus__single_property_search">
                            <label for="price">{{ $websiteLang->where('lang_key', 'price_range')->first()->custom_text
                                }}</label>
                            <select name="price" class="select_2" id="price">
                                <option value="">
                                    {{ $websiteLang->where('lang_key', 'price')->first()->custom_text }}
                                </option>
                                <option value="1">Below 50lakhs</option>
                                <option value="2">50 lakhs - 1 crore</option>
                                <option value="3">1 crore - 2 crores</option>
                                <option value="4">above 2 cr.</option>
                            </select>
                        </div>


                        {{-- <div class="form-check px-0 ">
                            <b><label for="price">{{ $websiteLang->where('lang_key', 'price')->first()->custom_text
                                    }}</label></b>

                            <div class="row">
                                <div class="price-input">
                                    <div class="field">
                                        <span>Min</span>
                                        <input type="number" class="input-min" value="100" name="minamount">
                                    </div>
                                    <div class="separator">-</div>
                                    <div class="field">
                                        <span>Max</span>
                                        <input type="number" class="input-max" value="222222220" name="maxamount">
                                    </div>
                                </div>
                                <div class="slider">
                                    <div class="progress"></div>
                                </div>
                                <div class="range-input">
                                    <input type="range" class="range-min" min="{{ $minpropertylist }}"
                                        max="{{ $maxpropertylist }}" value="100" step="100">
                                    <input type="range" class="range-max" min="{{ $minpropertylist }}"
                                        max="{{ $maxpropertylist }}" value="222222220" step="100">
                                </div>
                            </div>
                        </div> --}}

                        <div class="wsus__single_property_search">
                            <label for="price">{{ $websiteLang->where('lang_key',
                                'finance_available')->first()->custom_text }}</label>
                            <select name="finance" class="select_2" id="finance">
                                <option value="">
                                    {{ $websiteLang->where('lang_key', 'select_finance')->first()->custom_text }}
                                </option>

                                <option value="1">Yes</option>
                                <option value="0">No</option>
                            </select>
                        </div>



                        <button type="submit" class="common_btn2">{{ $websiteLang->where('lang_key',
                            'search')->first()->custom_text }}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!--=====PROPERTY PAGE END=====-->
<style>
    .price-input {
        width: 100%;
        display: flex;
        margin: 30px 0 35px;
    }

    .price-input .field {
        display: flex;
        width: 100%;
        height: 45px;
        align-items: center;
    }

    .field input {
        width: 100%;
        height: 100%;
        outline: none;
        font-size: 19px;
        margin-left: 12px;
        border-radius: 5px;
        text-align: center;
        border: 1px solid #999;
        -moz-appearance: textfield;
    }

    input[type="number"]::-webkit-outer-spin-button,
    input[type="number"]::-webkit-inner-spin-button {
        -webkit-appearance: none;
    }

    .price-input .separator {
        width: 130px;
        display: flex;
        font-size: 19px;
        align-items: center;
        justify-content: center;
    }

    .slider {
        height: 5px;
        position: relative;
        background: #ddd;
        border-radius: 5px;
    }

    .slider .progress {
        height: 100%;
        left: 6%;
        right: 53%;
        position: absolute;
        border-radius: 5px;
        background: #17a2b8;
    }

    .range-input {
        position: relative;
    }

    .range-input input {
        position: absolute;
        width: 100%;
        height: 5px;
        top: -5px;
        background: none;
        pointer-events: none;
        -webkit-appearance: none;
        -moz-appearance: none;
    }

    input[type="range"]::-webkit-slider-thumb {
        height: 17px;
        width: 17px;
        border-radius: 50%;
        background: #17a2b8;
        pointer-events: auto;
        -webkit-appearance: none;
        box-shadow: 0 0 6px rgba(0, 0, 0, 0.05);
    }

    input[type="range"]::-moz-range-thumb {
        height: 17px;
        width: 17px;
        border: none;
        border-radius: 50%;
        background: #17a2b8;
        pointer-events: auto;
        -moz-appearance: none;
        box-shadow: 0 0 6px rgba(0, 0, 0, 0.05);
    }

    .range-min {
        left: 0%
    }
</style>
<script type="text/javascript">
    $(document).ready(function() {

            $('#city').change(function() {

                var locality_id = $('#city').val();



                const url = "{{ route('get-locality') }}";

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                });

                $.ajax({
                    url: url,
                    type: "POST",
                    data: {
                        locality_id: locality_id,
                    },
                    dataType: "json",
                    success: function(result) {

                        var html = `<option value="" >Location </option>`;
                        $.each(result.propertydata, function(key, value) {
                            console.log(value);
                            html += `
                            <option value="${value.locality_id}">${value.locality_name}</option>`;
                        });
                        $("#location").html(html);

                    }
                });
            });
        });
</script>

<script>
    (function($) {


            const rangeInput = document.querySelectorAll(".range-input input"),
                priceInput = document.querySelectorAll(".price-input input"),
                range = document.querySelector(".slider .progress");
            let priceGap = 1000;

            priceInput.forEach((input) => {
                input.addEventListener("input", (e) => {
                    let minPrice = parseInt(priceInput[0].value),
                        maxPrice = parseInt(priceInput[1].value);

                    if (maxPrice - minPrice >= priceGap && maxPrice <= rangeInput[1].max) {
                        if (e.target.className === "input-min") {
                            rangeInput[0].value = minPrice;
                            range.style.left = (minPrice / rangeInput[0].max) * 100 + "%";
                        } else {
                            rangeInput[1].value = maxPrice;
                            range.style.right = 100 - (maxPrice / rangeInput[1].max) * 100 + "%";
                        }
                    }
                });
            });

            rangeInput.forEach((input) => {
                input.addEventListener("input", (e) => {
                    let minVal = parseInt(rangeInput[0].value),
                        maxVal = parseInt(rangeInput[1].value);

                    if (maxVal - minVal < priceGap) {
                        if (e.target.className === "range-min") {
                            rangeInput[0].value = maxVal - priceGap;
                        } else {
                            rangeInput[1].value = minVal + priceGap;
                        }
                    } else {
                        priceInput[0].value = minVal;
                        priceInput[1].value = maxVal;
                        range.style.left = (minVal / rangeInput[0].max) * 100 + "%";
                        range.style.right = 100 - (maxVal / rangeInput[1].max) * 100 + "%";
                    }
                });
            });



            "use strict";
            $(document).ready(function() {
                $("#sortingId").on("change", function() {
                    var id = $(this).val();

                    var isSortingId = '<?php echo $isSortingId; ?>'
                    var query_url = '<?php echo $search_url; ?>';

                    if (isSortingId == 0) {
                        var sorting_id = "&sorting_id=" + id;
                        query_url += sorting_id;
                    } else {
                        var href = new URL(query_url);
                        href.searchParams.set('sorting_id', id);
                        query_url = href.toString()
                    }

                    window.location.href = query_url;
                })

            });

        })(jQuery);
</script>



<script>
    function deleteData(id) {
            $("#deleteForm").attr("action", '{{ url('admin/property/') }}' + "/" + id)
        }

        function propertyStatus(id) {
            // project demo mode check
            var isDemo = "{{ env('PROJECT_MODE') }}"
            var demoNotify = "{{ env('NOTIFY_TEXT') }}"
            if (isDemo == 0) {
                toastr.error(demoNotify);
                return;
            }
            // end
            $.ajax({
                type: "get",
                url: "{{ url('/admin/property-status/') }}" + "/" + id,
                success: function(response) {
                    toastr.success(response)
                },
                error: function(err) {
                    console.log(err);

                }
            })
        }
</script>
<script>
    $(".common_btn2").click(function() {
            var city_val = $("#city").val();
            if (city_val == '') {
                toastr.error('City Field Is Required.');
            }
        });
</script>
{{-- <script type="text/javascript">
    $(document).ready(function() {
            
            $('#property_category').change( function() {

                var property_category_id = $('#property_category').val();
                console.log(property_category_id);
            
                const url = "{{ route('get-property') }}";

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                });

                $.ajax({
                    url:url,
                    type: "POST",
                    data: {
                        property_category_id: property_category_id,
                    },
                    dataType: "json",                            
                    success: function(result) {

                        var html= ``;
                            $.each(result.propertyTypes, function(key, value) {

                           html += `<option>${value.type}</option>`;

                         })

                        $("#property_type").html(html);
                                            
                    }
                        
                });

          });
    });
</script> --}}


<script type="text/javascript">
    $(document).ready(function() {

            $('#city').change(function() {

                var city_id = $('#city').val();


                const url = "{{ route('get-city') }}";

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                });

                $.ajax({
                    url: url,
                    type: "POST",
                    data: {
                        city_id: city_id,
                    },
                    dataType: "json",
                    success: function(result) {
                        // console.log(result);
                        var html = ``;
                        $.each(result.propertydata, function(key, value) {
                            console.log(value);
                            html += `<div class="form-check">
                                <input name="pincode[]"  class="form-check-input" type="checkbox" value="${ value.id }" id="flexCheckDefault-${ value.id }">

                                <label class="form-check-label" for="flexCheckDefault-${ value.id }">
                                    ${ value.pincode }
                                </label>
                            </div>`;
                        });
                        $("#pincode").html(html);
                    }
                });
            });
        });
</script>

@endsection