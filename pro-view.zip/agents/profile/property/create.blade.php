@extends('layouts.agents.profile.layout')
@section('title')
    <title>{{ $websiteLang->where('lang_key', 'my_property')->first()->custom_text }}</title>
@endsection
@section('agent-dashboard')

    <div class="row">
        <form action="{{ route('agents.store.agents') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="col-xl-9 ms-auto">
                <div class="wsus__dashboard_main_content">
                    <div class="wsus__add_property">
                        <h4 class="heading">{{ $websiteLang->where('lang_key', 'my_property')->first()->custom_text }} <a
                                href="{{ route('user.my.properties') }}" class="common_btn"><i
                                    class="fal fa-plus-octagon"></i>
                                {{ $websiteLang->where('lang_key', 'all_property')->first()->custom_text }}</a></h4>
                        <div class="wsus__dash_info p_25 pb_0">
                            <div class="row">
                                <h5 class="sub_heading">
                                    {{ $websiteLang->where('lang_key', 'basic_info')->first()->custom_text }}</h5>

                                    <div class="form-group">
                                    <label for="auction">{{ $websiteLang->where('lang_key', 'auction_property')->first()->custom_text }}</label>
                                    <input id="auctionproperty" value="" class="mr-5" type="radio" name="property">

                                    <label for="owen">{{ $websiteLang->where('lang_key', 'owen_property')->first()->custom_text }}</label>
                                    <input id="owen" value="" type="radio" name="property">
                                    <input type="hidden" name="property_enquiry" id="property_enquiry"/>
                                    </div>
                               
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label>{{ $websiteLang->where('lang_key', 'title')->first()->custom_text }} <span
                                                class="text-danger">*</span></label>
                                        <input type="text" name="title" id="title" value="{{ old('title') }}">
                                        <input type="hidden" name="expired_date" value="{{ $expired_date }}">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label for="#"
                                            for="slug">{{ $websiteLang->where('lang_key', 'slug')->first()->custom_text }}
                                            <span class="text-danger">*</span></label>
                                        <input type="text" name="slug" id="slug" value="{{ old('slug') }}">
                                         
                                    </div>
                                </div>


                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label for="#"
                                            for="property_unique_id">{{ $websiteLang->where('lang_key', 'property_unique_id')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <input type="text" name="property_unique_id" id="property_unique_id" value="{{ old('property_unique_id') }}">
                                         
                                    </div>
                                </div>



                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'property_purpose')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <select class="select_2" name="purpose" id="purpose">
                                            <option value="">
                                                {{ $websiteLang->where('lang_key', 'select_property_category')->first()->custom_text }}
                                            </option>
                                            
                                            @foreach ($propertycategory as $item)
                                                <option
                                                    {{ old('purpose') == $item->categories_id ? 'selected' : '' }}
                                                    value="{{ $item->categories_id }}">{{ $item->categories_name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>

                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'property_type')->first()->custom_text }}
                                            <span class="text-danger">*</span></label>
                                        <select class="select_2" name="property_type" id="property_type">
                                            <option value="">
                                                {{ $websiteLang->where('lang_key', 'select_property_type')->first()->custom_text }}
                                            </option>
                                            @foreach ($propertyTypes as $item)
                                                <option {{ old('property_type') == $item->id ? 'selected' : '' }}
                                                    value="{{ $item->id }}">{{ $item->type }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                
                                


                                <div class="col-xl-6 col-md-6" >
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'city')->first()->custom_text }}
                                            <span class="text-danger">*</span></label>
                                        <select class="select_2" name="city">
                                            <option value="">
                                                {{ $websiteLang->where('lang_key', 'select_city')->first()->custom_text }}
                                            </option>
                                            @foreach ($cities as $item)
                                                <option {{ old('city') == $item->id ? 'selected' : '' }}
                                                    value="{{ $item->id }}">
                                                    {{ $item->name . ', ' . $item->countryState->name . ', ' . $item->countryState->country->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'address')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <input type="text" name="address" value="{{ old('address') }}">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'locality')->first()->custom_text }}
                                            <span class="text-danger">*</span></label>
                                        <input type="text" name="locality" value="{{ old('locality') }}">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'pincode')->first()->custom_text }}
                                            <span class="text-danger">*</span></label>
                                        <input type="number" name="pincode" value="{{ old('pincode') }}">
                                    </div>
                                </div>
                                {{-- <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'phone')->first()->custom_text }}</label>
                                        <input type="text" name="phone" value="{{ old('phone') }}">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'email')->first()->custom_text }}
                                            <span class="text-danger">*</span></label>
                                        <input type="email" name="email" value="{{ old('email') }}">
                                    </div>
                                </div> --}}
                                
                                <div class="col-xl-6 col-md-6"  id="pricedata">
                                    <div class="wsus__property_input">
                                        <label
                                            for="price">{{ $websiteLang->where('lang_key', 'price')->first()->custom_text }}
                                            <span class="text-danger">*</span></label>
                                        <input type="number" id="price" name="price" value="{{ old('price') }}">
                                    </div>
                                </div>

                                <div class="col-xl-6 col-md-6"  id="market_pricedata">
                                    <div class="wsus__property_input">
                                        <label
                                            for="market_price">{{ $websiteLang->where('lang_key', 'market_price')->first()->custom_text }}
                                            <span class="text-danger">*</span></label>
                                        <input type="number" id="market_price" name="market_price" value="{{ old('market_price') }}">
                                    </div>
                                </div>

                                <div class="col-xl-6 col-md-6" id="emddata">
                                    <div class="wsus__property_input">
                                        <label
                                            for="emd_amount">{{ $websiteLang->where('lang_key', 'emd_amount')->first()->custom_text }}
                                            <span class="text-danger">*</span></label>
                                        <input  type="number" name="emd_amount" id="emd_amount"
                                            value="{{ old('emd_amount') }}">
                                    </div>
                                </div>

                                <div class="col-xl-6 col-md-6" id="bankdata">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'bank')->first()->custom_text }}
                                            <span class="text-danger">*</span></label>
                                        <select class="select_2" name="bank">
                                            <option value="">
                                                {{ $websiteLang->where('lang_key', 'select_bank')->first()->custom_text }}
                                            </option>
                                            @foreach ($allbank as $item)
                                                <option {{ old('bank') == $item->id ? 'selected' : '' }}
                                                    value="{{ $item->id }}">{{ $item->name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6" id="financedata">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'finance_available')->first()->custom_text }}
                                            <span class="text-danger">*</span></label>
                                        <select class="select_2" name="finance">
                                            <option value="">
                                                {{ $websiteLang->where('lang_key', 'select_finance')->first()->custom_text }}
                                            </option>
                                            <option {{ old('finance') == 1 ? 'selected' : '' }} value="1">Yes</option>
                                            <option {{ old('finance') == 0 ? 'selected' : '' }} value="0">No</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-xl-6 col-md-6" id="auctiondata">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'auction')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <input type="text" class="form-control datepicker" name="auction"
                                            id="auction" value="{{ old('auction') }}" autocomplete="off">
                                    </div>
                                </div>



                                <div class="col-xl-6 col-md-6 d-none" id="period_box">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'period')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <select class="select_2" name="period" id="period">
                                            <option value="Daily">
                                                {{ $websiteLang->where('lang_key', 'daily')->first()->custom_text }}
                                            </option>
                                            <option value="Monthly">
                                                {{ $websiteLang->where('lang_key', 'monthly')->first()->custom_text }}
                                            </option>
                                            <option value="Yearly">
                                                {{ $websiteLang->where('lang_key', 'yearly')->first()->custom_text }}
                                            </option>
                                        </select>
                                    </div>
                                </div>

                            </div>
                        </div>

                        {{-- hidden property div --}}
                        <div class="wsus__dash_info p_25 mt_25 pb_0" id="properties">
                            <div class="row" >
                                <h5 class="sub_heading">
                                    {{ $websiteLang->where('lang_key', 'others_info')->first()->custom_text }}</h5>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'total_area')->first()->custom_text }}({{ $websiteLang->where('lang_key', 'sqft')->first()->custom_text }})
                                            <span class="text-danger"></span></label>
                                        <input type="number" name="area" value="{{ old('area') }}">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'total_unit')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <input type="number" name="unit" value="{{ old('unit') }}">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'total_room')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <input type="number" name="room" value="{{ old('room') }}">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'total_bedroom')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <input type="number" name="bedroom" value="{{ old('bedroom') }}">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'total_bathroom')->first()->custom_text }}<span
                                                class="text-danger"></span></label>
                                        <input type="number" name="bathroom" value="{{ old('bathroom') }}">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'total_floor')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <input type="number" name="floor" value="{{ old('floor') }}">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'total_kitchen')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <input type="number" name="kitchen" value="{{ old('kitchen') }}">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'parking_place')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <input type="number" name="parking" value="{{ old('parking') }}">
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- hidden vehivle info --}}
                        <div class="wsus__dash_info p_25 mt_25 pb_0" id="vehicles">
                            <div class="row">
                                <h5 class="sub_heading">
                                    {{ $websiteLang->where('lang_key', 'vehicles_information')->first()->custom_text }}</h5>
                                <hr>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="vehicle_name">{{ $websiteLang->where('lang_key', 'vehicle_name')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <input type="text" name="vehicle_name" value="{{ old('vehicle_name') }}"
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="vehicle_type">{{ $websiteLang->where('lang_key', 'vehicle_type')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <input type="text" name="vehicle_type" value="{{ old('vehicle_type') }}"
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="vehicle_price">{{ $websiteLang->where('lang_key', 'vehicle_price')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <input type="number" name="vehicle_price" value="{{ old('vehicle_price') }}"
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="vehicle_size">{{ $websiteLang->where('lang_key', 'vehicle_size')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <input type="text" name="vehicle_size" value="{{ old('vehicle_size') }}"
                                            class="form-control">
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="wsus__dash_info p_25 mt_25 pb_0">
                            <div class="row">
                                <h5 class="sub_heading">
                                    {{ $websiteLang->where('lang_key', 'img_pdf_video')->first()->custom_text }}</h5>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'pdf_file')->first()->custom_text }}</label>
                                        <input type="file" name="pdf_file">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'banner_img')->first()->custom_text }}
                                            <span class="text-danger"></span></label>
                                        <input type="file" name="banner_image">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'thumb_img')->first()->custom_text }}
                                            <span class="text-danger">*</span></label>
                                        <input type="file" name="thumbnail_image">
                                    </div>
                                </div>
                                <div class="col-xl-6 col-md-6">
                                    <div class="wsus__property_input">
                                        <label
                                            for="#">{{ $websiteLang->where('lang_key', 'video_link')->first()->custom_text }}</label>
                                        <input type="text" name="video_link">
                                    </div>
                                </div>
                                <div class="col-xl-8 col-md-8 ">
                                    <div id="dynamic-img-box">
                                        <div class="row">
                                            <div class="col-md-9">
                                                <div class="wsus__property_input">
                                                    <label
                                                        for="#">{{ $websiteLang->where('lang_key', 'img')->first()->custom_text }}
                                                        <span class="text-danger">*</span></label>
                                                    <input type="file" name="slider_images[]">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="medicine_row_input">
                                                    <button class="mt_30" type="button" id="addDynamicImgBtn"><i
                                                            class="fas fa-plus" aria-hidden="true"></i></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <div id="dynamic_img_box" class="d-none">
                                    <div class="row delete-dynamic-img-row">
                                        <div class="col-md-9">
                                            <div class="wsus__property_input">
                                                <label
                                                    for="#">{{ $websiteLang->where('lang_key', 'img')->first()->custom_text }}
                                                    <span class="text-danger">*</span></label>
                                                <input type="file" name="slider_images[]">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <div class="medicine_row_input">
                                                <button class="mt_30 danger_btn removeDynamicImgId" type="button"><i
                                                        class="fas fa-trash" aria-hidden="true"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
  
 
  {{-- <a type="button" class="btn btn-primary" data-bs-toggle="collapse" data-bs-target="#demo">Simple collapsible</a> --}}
  
    
              <div  class="wsus__dash_info dash_aminities p_25 mt_25 pb_0">
          <h5 class="sub_heading d-inline">
         {{ $websiteLang->where('lang_key', 'aminities')->first()->custom_text }}</h5><a class="float-end d-inline" onclick="changeIcon(this)"><i  class="fas fa-plus  text-danger " data-bs-toggle="collapse" data-bs-target="#addproperty"></i></a>
              <hr>
              <div class="row collapse" id="addproperty">
                  
                              @foreach ($aminities as $aminity)
                                  @if (old('aminities'))
                                      @php
                                          $isChecked = false;
                                      @endphp
                                      @foreach (old('aminities') as $old_aminity)
                                          @if ($aminity->id == $old_aminity)
                                              @php
                                                  $isChecked = true;
                                              @endphp
                                          @endif
                                      @endforeach
                                      <div class="col-xl-4 col-sm-6 col-lg-4">
                                                <div class="form-check">

                                      <input id="{{ $aminity->slug }}" {{ $isChecked ? 'checked' : '' }}
                                          value="{{ $aminity->id }}" type="checkbox" name="aminities[]">
                                      <label class="mx-1"
                                          for="{{ $aminity->slug }}">{{ $aminity->aminity }}</label>
                                        </div>
                                      </div>
                                  @else
                                  <div class="col-xl-4 col-sm-6 col-lg-4">
                                                <div class="form-check">
                                      <input value="{{ $aminity->id }}" type="checkbox" name="aminities[]"
                                          id="{{ $aminity->slug }}">
                                      <label class="mx-1"
                                          for="{{ $aminity->slug }}">{{ $aminity->aminity }}</label>
                                        </div>
                                      </div>
                                  @endif
                              @endforeach
                        </div>
                    </div>

 


                        
                       
                        {{-- @if ($package->number_of_aminities == -1)
                            <div class="wsus__dash_info dash_aminities p_25 mt_25 pb_0">
                                <h5 class="sub_heading">
                                    {{ $websiteLang->where('lang_key', 'aminities')->first()->custom_text }}</h5>
                                <div class="row" id="addproperty">
                                    @foreach ($aminities as $aminity)
                                        @if (old('aminities'))
                                            @php
                                                $isChecked = false;
                                            @endphp
                                            @foreach (old('aminities') as $old_aminity)
                                                @if ($aminity->id == $old_aminity)
                                                    @php
                                                        $isChecked = true;
                                                    @endphp
                                                @endif
                                            @endforeach

                                            <div class="col-xl-4 col-sm-6 col-lg-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" {{ $isChecked ? 'checked' : '' }}
                                                        type="checkbox" name="aminities[]"
                                                        id="un-aminityId-{{ $aminity->id }}"
                                                        value="{{ $aminity->id }}">
                                                    <label class="form-check-label"
                                                        for="un-aminityId-{{ $aminity->id }}">
                                                        {{ $aminity->aminity }}
                                                    </label>
                                                </div>
                                            </div>
                                        @else
                                            <div class="col-xl-4 col-sm-6 col-lg-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="aminities[]"
                                                        id="un-aminityId-{{ $aminity->id }}"
                                                        value="{{ $aminity->id }}">
                                                    <label class="form-check-label"
                                                        for="un-aminityId-{{ $aminity->id }}">
                                                        {{ $aminity->aminity }}
                                                    </label>
                                                </div>
                                            </div>
                                        @endif
                                    @endforeach
                                </div>

                                @php
                                    $aminityList = [];
                                    foreach ($aminities as $index => $aminity) {
                                        $aminityList[] = $aminity->id;
                                    }
                                @endphp
                            @else
                                <div class="wsus__dash_info dash_aminities p_25 mt_25 pb_0">
                                    <h5 class="sub_heading">
                                        {{ $websiteLang->where('lang_key', 'aminities')->first()->custom_text }}</h5>
                                    <div class="row">
                                        @foreach ($aminities as $aminity)
                                            @if (old('aminities'))
                                                @php
                                                    $isChecked = false;
                                                @endphp
                                                @foreach (old('aminities') as $old_aminity)
                                                    @if ($aminity->id == $old_aminity)
                                                        @php
                                                            $isChecked = true;
                                                        @endphp
                                                    @endif
                                                @endforeach

                                                <div class="col-xl-4 col-sm-6 col-lg-4">
                                                    <div class="form-check">
                                                        <input class="form-check-input is-check"
                                                            {{ $isChecked ? 'checked' : '' }} type="checkbox"
                                                            name="aminities[]" id="aminityId-{{ $aminity->id }}"
                                                            value="{{ $aminity->id }}">
                                                        <label class="form-check-label"
                                                            for="aminityId-{{ $aminity->id }}">
                                                            {{ $aminity->aminity }}
                                                        </label>
                                                    </div>
                                                </div>
                                            @else
                                                <div class="col-xl-4 col-sm-6 col-lg-4">
                                                    <div class="form-check">
                                                        <input class="form-check-input is-check" type="checkbox"
                                                            name="aminities[]" id="aminityId-{{ $aminity->id }}"
                                                            value="{{ $aminity->id }}">
                                                        <label class="form-check-label"
                                                            for="aminityId-{{ $aminity->id }}">
                                                            {{ $aminity->aminity }}
                                                        </label>
                                                    </div>
                                                </div>
                                            @endif
                                        @endforeach
                                    </div>
                                    @php
                                        $aminityList = [];
                                        foreach ($aminities as $index => $aminity) {
                                            $aminityList[] = $aminity->id;
                                        }
                                    @endphp
                        @endif --}}
                    </div>
                    <div class="wsus__dash_info nearest_location p_25 mt_25">
                        <h5 class="sub_heading">{{ $websiteLang->where('lang_key', 'nearest_loc')->first()->custom_text }}
                        </h5>
                        <div id="dyamic-nearest-place-box">
                            <div class="row">
                                <div class="col-xl-5 col-md-5">
                                    <label>{{ $websiteLang->where('lang_key', 'nearest_loc')->first()->custom_text }}</label>
                                    <select class="custom-select-box" name="nearest_locations[]">
                                        <option value="">
                                            {{ $websiteLang->where('lang_key', 'select_nearest_loc')->first()->custom_text }}
                                        </option>
                                        @foreach ($nearest_locatoins as $item)
                                            <option value="{{ $item->id }}">{{ $item->location }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-xl-5 col-md-5">
                                    <label
                                        for="#">{{ $websiteLang->where('lang_key', 'distance')->first()->custom_text }}({{ $websiteLang->where('lang_key', 'km')->first()->custom_text }})</label>
                                    <input type="text" name="distances[]">
                                </div>
                                <div class="col-xl-2 col-md-2">
                                    <button class="common_btn mt_30"
                                        id="addDybanamicLocationBtn">{{ $websiteLang->where('lang_key', 'new')->first()->custom_text }}</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="hidden-location-box" class="d-none">
                        <div class="delete-dynamic-location">
                            <div class="row mt-3">
                                <div class="col-xl-5 col-md-5">
                                    <label>{{ $websiteLang->where('lang_key', 'nearest_loc')->first()->custom_text }}</label>
                                    <select class="custom-select-box" name="nearest_locations[]">
                                        <option value="">
                                            {{ $websiteLang->where('lang_key', 'select_nearest_loc')->first()->custom_text }}
                                        </option>
                                        @foreach ($nearest_locatoins as $item)
                                            <option value="{{ $item->id }}">{{ $item->location }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="col-xl-5 col-md-5">
                                    <label
                                        for="#">{{ $websiteLang->where('lang_key', 'distance')->first()->custom_text }}({{ $websiteLang->where('lang_key', 'km')->first()->custom_text }})</label>
                                    <input type="text" name="distances[]">
                                </div>
                                <div class="col-xl-2 col-md-2">
                                    <button class="common_btn mt_30 removeNearstPlaceBtnId"
                                        id="addDybanamicLocationBtn">{{ $websiteLang->where('lang_key', 'remove')->first()->custom_text }}</button>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class="wsus__dash_info pro_det_map p_25 mt_25 pb_0">
                        <h5 class="sub_heading">
                            {{ $websiteLang->where('lang_key', 'detail_google_map')->first()->custom_text }} </h5>
                        <div class="wsus__property_input">
                            <label>{{ $websiteLang->where('lang_key', 'google_map')->first()->custom_text }}</label>
                            <textarea cols="3" rows="3" name="google_map_embed_code">{{ old('google_map_embed_code') }}</textarea>
                        </div>
                        <div class="wsus__property_inpuT">
                            <label>{{ $websiteLang->where('lang_key', 'des')->first()->custom_text }} <span
                                    class="text-danger">*</span>
                                <textarea class="form-control summer_note" id="summernote" name="description">{{ old('description') }}</textarea>
                        </div>
                    </div>
                    <div class="wsus__dash_info featured p_25 mt_25">
                        <div class="row">
                            @if ($package->is_featured)
                                @if ($package->number_of_feature_property == -1)
                                    <div class="col-12">
                                        <div class="wsus__property_input">
                                            <label
                                                for="#">{{ $websiteLang->where('lang_key', 'featured')->first()->custom_text }}
                                                <span class="text-danger">*</span></label>
                                            <select class="select_2" name="featured">
                                                <option value="1">
                                                    {{ $websiteLang->where('lang_key', 'yes')->first()->custom_text }}
                                                </option>
                                                <option value="0">
                                                    {{ $websiteLang->where('lang_key', 'no')->first()->custom_text }}
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                @elseif($package->number_of_feature_property > $existFeaturedProperty)
                                    <div class="col-12">
                                        <div class="wsus__property_input">
                                            <label
                                                for="#">{{ $websiteLang->where('lang_key', 'featured')->first()->custom_text }}
                                                <span class="text-danger">*</span></label>
                                            <select class="select_2" name="featured">
                                                <option value="1">
                                                    {{ $websiteLang->where('lang_key', 'yes')->first()->custom_text }}
                                                </option>
                                                <option value="0">
                                                    {{ $websiteLang->where('lang_key', 'no')->first()->custom_text }}
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                @endif
                            @endif

                            @if ($package->is_top)
                                @if ($package->number_of_top_property == -1)
                                    <div class="col-12">
                                        <div class="wsus__property_input">
                                            <label
                                                for="#">{{ $websiteLang->where('lang_key', 'top_property')->first()->custom_text }}
                                                <span class="text-danger">*</span></label>
                                            <select class="select_2" name="top_property">
                                                <option value="1">
                                                    {{ $websiteLang->where('lang_key', 'yes')->first()->custom_text }}
                                                </option>
                                                <option value="0">
                                                    {{ $websiteLang->where('lang_key', 'no')->first()->custom_text }}
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                @elseif($package->number_of_top_property > $existTopProperty)
                                    <div class="col-12">
                                        <div class="wsus__property_input">
                                            <label
                                                for="#">{{ $websiteLang->where('lang_key', 'top_property')->first()->custom_text }}
                                                <span class="text-danger">*</span></label>
                                            <select class="select_2" name="top_property">
                                                <option value="1">
                                                    {{ $websiteLang->where('lang_key', 'yes')->first()->custom_text }}
                                                </option>
                                                <option value="0">
                                                    {{ $websiteLang->where('lang_key', 'no')->first()->custom_text }}
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                @endif
                            @endif

                            @if ($package->is_urgent)
                                @if ($package->number_of_urgent_property == -1)
                                    <div class="col-xl-12 col-md-6">
                                        <div class="wsus__property_input">
                                            <label
                                                for="#">{{ $websiteLang->where('lang_key', 'urgent_property')->first()->custom_text }}
                                                <span class="text-danger">*</span></label>
                                            <select class="select_2" name="urgent_property">
                                                <option value="1">
                                                    {{ $websiteLang->where('lang_key', 'yes')->first()->custom_text }}
                                                </option>
                                                <option value="0">
                                                    {{ $websiteLang->where('lang_key', 'no')->first()->custom_text }}
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                @elseif($package->number_of_urgent_property > $existUrgentProperty)
                                    <div class="col-xl-12 col-md-6">
                                        <div class="wsus__property_input">
                                            <label
                                                for="#">{{ $websiteLang->where('lang_key', 'urgent_property')->first()->custom_text }}
                                                <span class="text-danger">*</span></label>
                                            <select class="select_2" name="urgent_property">
                                                <option value="1">
                                                    {{ $websiteLang->where('lang_key', 'yes')->first()->custom_text }}
                                                </option>
                                                <option value="0">
                                                    {{ $websiteLang->where('lang_key', 'no')->first()->custom_text }}
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                @endif
                            @endif


                            <div class="col-12">
                                <div class="wsus__property_input">
                                    <label
                                        for="#">{{ $websiteLang->where('lang_key', 'seo_title')->first()->custom_text }}</label>
                                    <input type="text" name="seo_title" value="{{ old('seo_title') }}">
                                </div>
                            </div>
                            <div class="col-xl-12">
                                <div class="wsus__property_input">
                                    <label
                                        for="#">{{ $websiteLang->where('lang_key', 'seo_des')->first()->custom_text }}</label>
                                    <textarea cols="3" rows="3" name="seo_description">{{ old('seo_description') }}</textarea>
                                </div>
                            </div>
                            <div class="col-12">
                                <button type="submit"
                                    class="common_btn">{{ $websiteLang->where('lang_key', 'save')->first()->custom_text }}</button>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
    </div>
    </form>
    </div>
<script>
    function changeIcon(anchor) {

  var icon = anchor.querySelector("i");
  
  icon.classList.toggle('fa-plus');
  icon.classList.toggle('fa-minus');

   anchor.querySelector("span").textContent = icon.classList.contains('fa-plus') ? "Read more" : "Read less";
}
</script>
    <script>
        (function($) {
            "use strict";
            $(document).ready(function(){

                var image = 1;
                var maxImage = '{{ $package->number_of_photo }}';
                var location = 1;
                var maxLocation = '{{ $package->number_of_nearest_place }}';
                $("#addDynamicImgBtn").on('click', function(e) {
                    e.preventDefault();

                    var dynaicImage = $("#dynamic_img_box").html();
                    if (maxImage == -1) {
                        $("#dynamic-img-box").append(dynaicImage);
                    } else if (image < maxImage) {
                        image++;
                        $("#dynamic-img-box").append(dynaicImage);
                    }


                })

                $(document).on('click', '.removeDynamicImgId', function() {
                    $(this).closest('.delete-dynamic-img-row').remove();
                    image--;
                });

                $("#addDybanamicLocationBtn").on('click', function(e) {
                    e.preventDefault();
                    var newRow = $("#hidden-location-box").html()

                    if (maxLocation == -1) {
                        $("#dyamic-nearest-place-box").append(newRow);
                    } else if (location < maxLocation) {
                        location++;
                        $("#dyamic-nearest-place-box").append(newRow);
                    }

                })

                $(document).on('click', '.removeNearstPlaceBtnId', function() {
                    $(this).closest('.delete-dynamic-location').remove();
                    location--;
                });

                $("#title").on("focusout", function(e) {
               
               
                    $("#slug").val(convertToSlug($(this).val()));
                })

                $("#purpose").on("change", function() {
                    var purposeId = $(this).val()
                    if (purposeId == 2) {
                        $("#period_box").removeClass('d-none');
                    } else if (purposeId == 1) {
                        $("#period_box").addClass('d-none');
                    }
                })
              });

        })(jQuery);


        function convertToSlug(Text) {
            return Text
                .toLowerCase()
                .replace(/[^\w ]+/g, '')
                .replace(/ +/g, '-');
        }
    </script>

    <script type="text/javascript">
        $(document).ready(function() {
            "use strict";
            $('#purpose').change( function() {

                var property_category_id = $('#purpose').val();

                const url = "{{url('/agents/agent-ajax')}}";
                
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                });

                $.ajax({
                    url:url,
                    type: "POST",
                    data: {
                        property_category_id: property_category_id,
                    },
                    dataType: "json",                            
                    success: function(result) {
                        console.log(result);

                        var html= ``;
                            $.each(result.propertyTypes, function(key, value) {
                              console.log(value);
                          
                            html += `<input id="${value.slug}" value="${value.id}" type="checkbox" name="aminities[]"><label class="mx-1" for="${value.aminity}">${value.aminity}</label>`;

                         })
                        $("#addproperty").html(html);
                                            
                    }
                        
                });

          });
    });
    </script> 



<script>
    $(window).on("load",function(){
        $("#properties").hide();
    });
</script>

    <script>
        $(document).ready(function() {
            $(window).on("load", function() {
                $("#properties").hide();
                $("#vehicles").hide();
            });

            $("#purpose").change(function() {
                var value = $(this).val();
                // alert(value);
                if (value == '1') {
                    $("#properties").show();
                    $("#vehicles").hide();
                } else {
                    $("#vehicles").show();
                    $("#properties").hide();
                }

            });
        });
    </script>




    <script>
        $(document).ready(function() {
            $("#price").change(function() {
                var data = $(this).val();
                var emd_price = data * 10 / 100;
                $("#emd_amount").val(emd_price);
            });

        });
    </script>
    <script>

        $("#owen").click(function() {
            $('#property_enquiry').val('own');
            $('#emddata').hide();
            $('#bankdata').hide();
            $('#financedata').hide();
            $('#auctiondata').hide();

        });
        $(document).ready(function(){
        $("#auctionproperty").click(function() {
           
           $('#property_enquiry').val('auction');
         
            $('#emddata').show();
            $('#bankdata').show();
            $('#financedata').show();
            $('#auctiondata').show();

        });
        });
    </script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="/resources/demos/style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
    <script>
        $(function() {
            $("#auction").datepicker();
        });
    </script>

@endsection
