<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BankDetail extends Model
{
    
    protected $fillable=[
        'acount_number','bank','Branch','ifsc','status'
    ];



    
}


