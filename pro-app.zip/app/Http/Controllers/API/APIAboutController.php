<?php

namespace App\Http\Controllers\API;
use App\Http\Controllers\Controller;
use App\BannerImage;
use App\City;
use Illuminate\Pagination\Paginator;
use Illuminate\Http\Request;
use App\ListingCategory;
use App\PropertyPurpose;
use App\NearestLocation;
use App\PropertyReview;
use App\About;
use Str;
use File;
use Image;
use App\AboutSection;
use App\Locality;
use App\PropertyCategory;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class APIAboutController extends Controller
{
  
    public function index()
    {
        $data['about'] = About::all();
        return response()->json($data);
    }
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'about'=>'required',
            'service'=>'required',
            'history'=>'required',
            'short_about'=>'required',
            'image'=>'required',
           ]);
       if ($validator->fails()) {
               return response()->json([
                 'message' => 'Filled is Required', // the ,message you want to show
                   'errors' => $validator->errors()
               ], 422);
           }

    try{
        $about=new About();
        // $property->admin_id=3;
        $about->about=$request->header;
        $about->service=$request->description;
        $about->history=$request->show_homepage;
        $about->short_about=$request->content_quantity;
        $about->image=$request->icon;
        $about->save();
        $data['about'] = $about;
        return response()->json($data);
    } catch (Exception $e) {
        $data['aboutSection'] ="Something went wrong";
        return response()->json($data);
    }
}

//         public function edit($id)
//         {
//             $data['aboutSection'] = AboutSection::find($id);
//             if($data['aboutSection']){
//                 return response()->json($data);
//             }else
//             {
//                 return response()->json('About Section not found');
//             }
           
//         }
//         public function delete($id)
//         {
//             $aboutSection = AboutSection::find($id);
//             if($aboutSection){
//             $aboutSection->delete();
//             $data['aboutSection'] = $aboutSection;
//             return response()->json(['About Section delete' => $data,'message' => 'About Section delete successfully']);
//             }else{
//                 return response()->json('About Section not found');
//             }

//         }

//         public function update(Request $request, $id) {

//             $AboutSection = AboutSection::find($id);
//              if($AboutSection){
//             $AboutSection->update($request->all());
    
//             $AboutSection->save();
//             return response()->json(['Update Property Successfully' => $AboutSection]);
//              }else{
//                 return response()->json("Property not found");
//              }
//         }

}