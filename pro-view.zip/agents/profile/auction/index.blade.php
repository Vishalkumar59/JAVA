@extends('layouts.agents.profile.layout')
@section('title')
    <title>{{ $websiteLang->where('lang_key','auctions')->first()->custom_text }}</title>
@endsection
@section('agent-dashboard')

<div class="row">
    <div class="col-xl-9 ms-auto">
        <div class="wsus__dashboard_main_content">
          <h4 class="heading">{{ $websiteLang->where('lang_key','enquiry')->first()->custom_text }}</h4>
          <div class="wsus__dash_order mb_25">
            <div class="row">
              <div class="col-md-12">
                  <div class="card shadow mb-4">
                      <div class="card-body">
                          <ul class="nav nav-tabs" id="myTab" role="tablist">
                              <li class="nav-item" role="presentation">
                                <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">{{ $websiteLang->where('lang_key','auction_enq')->first()->custom_text }}</a>
                              </li>
                              <li class="nav-item" role="presentation">
                                <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">{{$websiteLang->where('lang_key','own_enq')->first()->custom_text }}</a>
                              </li>

                            </ul>
                            <div class="tab-content" id="myTabContent">
                              <div class="tab-pane fade show active mt-5" id="home" role="tabpanel" aria-labelledby="home-tab">
                              <div class="table-responsive">
                                 <table class="table text-center">
                                  <tbody>
                                      <tr>
                                         <th  class="serial">{{ $websiteLang->where('lang_key','serial')->first()->custom_text }}</th>

                                          <th  class="action">{{ $websiteLang->where('lang_key','customer_name')->first()->custom_text }}</th>

                                          <th class="package">{{ $websiteLang->where('lang_key','property_id')->first()->custom_text }}</th> 


                                          {{-- <th class="package">{{ $websiteLang->where('lang_key','agent_name')->first()->custom_text }}</th> --}}

                                          <th class="p_date">{{ $websiteLang->where('lang_key','date')->first()->custom_text }}</th>
                                          

                                          <th  class="action">{{ $websiteLang->where('lang_key','action')->first()->custom_text }}</th>



                                      </tr>
                                      <?php $index1 = 0 ?>
                                    
                                        @foreach ($kyclist as $index => $kyc)
                                       
                                          @if(!empty($kyc->property->user_id) == Auth::user()->id)
                                          <tr>
                                          
                                              <td class="serial">{{ ++$index1 }}</td>

                                              <td class="action">@if(!empty($kyc->user->name )){{ $kyc->user->name  }}@endif</td> 

                                              <td class="package">@if(!empty($kyc->property)){{$kyc->property->title}}@endif</td> 

                                              {{-- <td class="package">@if(!empty($kyc->property)){{$kyc->property->user->name}}@endif</td>  --}}
                                              
                                              <td class="p_date">{{ date('d-m-Y', strtotime($kyc->created_at ?? '')) }} </td>
                                              
                                              <td class="action">
                                              <meta name="csrf-token" content="{{ csrf_token() }}">
                                                <button value="{{$kyc->id}}" class="location"><i class="fa fa-eye" aria-hidden="true"></i></button>
                                              </td>

                                          </tr>
                                          @endif
                                          @endforeach
                                        

                                  </tbody>
                                  </table>
                                </div>
                              </div>
                              <div class="tab-pane fade mt-5" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                               <div class="table-responsive">
                                 <table class="table text-center">
                                <tbody>
                                    <tr>
                                       <th  class="serial">{{ $websiteLang->where('lang_key','serial')->first()->custom_text }}</th>

                                      <th  class="action">User Name</th>

                                      <th class="package">{{ $websiteLang->where('lang_key','property_id')->first()->custom_text }}</th> 


                                      <th class="package">{{ $websiteLang->where('lang_key','agent_name')->first()->custom_text }}</th>

                                      <th class="p_date">{{ $websiteLang->where('lang_key','date')->first()->custom_text }}</th>
                                    

                                      <th  class="action">{{ $websiteLang->where('lang_key','action')->first()->custom_text }}</th>

                                    </tr>
                                    
                                    <?php $index1 = 0 ?>
                                       @foreach ($enqlist as $index => $enq)
                                        @if(!empty($enq->property))
                                        @if($enq->property->user_id == Auth::user()->id)
                                       
                                        <tr>
                                            <td class="serial">{{ ++$index1 }}</td>
                                        
                                            <td class="action">@if(!empty($enq->user)){{ $enq->user->name  }}@endif</td> 

                                            <td class="package">@if(!empty($enq->property)){{ $enq->property->title  }}@endif</td> 
                                       
                                            <td class="package">@if(!empty($enq->property)){{$enq->property->user->name}}@endif</td> 


                                            <td class="p_date"> {{ date('d-m-Y', strtotime($enq->created_at ?? '')) }}</td>
                                            
                                            <td class="action">
                                            <meta name="csrf-token" content="{{ csrf_token() }}">
                                              <button value="{{$enq->id}}" class="enqdetails"><i class="fa fa-eye" aria-hidden="true"></i></button>
                                            </td>

                                        </tr>
                                        @endif
                                        @endif
                                        @endforeach

                                  </tbody>
                                  </table>
                                </div>
                              </div>
                              

                            </div>
                      </div>
                  </div>
              </div>
            </div>
          </div>
          
          {{ $kyclist->links('user.paginator') }}
        </div>
    </div>
</div>
<div class="modal fade" id="newLocation" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                </h5>
                <button type="button" id="modalclose" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" >
                <div class="container-fluid" id="user-key-details">

                    

                </div>  
            </div>
        </div>
    </div>
</div>


{{-- <div class="modal fade" id="newLocation" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{ $websiteLang->where('lang_key', 'user_acution_list')->first()->custom_text }}</h5>
        <button type="button" id="modalclose" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="container-fluid" id="user-key-details">
        </div>
      </div>
    </div>
  </div>
</div> --}}



  <script src="{{ asset('backend/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
  <script src="{{ asset('backend/vendor/jquery-easing/jquery.easing.min.js') }}"></script>
  <script src="{{ asset('backend/js/bootstrap4-toggle.min.js') }}"></script>
  <script src="{{ asset('backend/vendor/chart.js/Chart.min.js') }}"></script>
  <script src="{{ asset('backend/js/demo/chart-area-demo.js') }}"></script>
  <script src="{{ asset('backend/js/demo/chart-pie-demo.js') }}"></script>
  <script src="{{ asset('backend/vendor/datatables/jquery.dataTables.min.js') }}"></script>
  <script src="{{ asset('backend/vendor/datatables/dataTables.bootstrap4.min.js') }}"></script>
  <script src="{{ asset('backend/js/demo/datatables-demo.js') }}"></script>
  <script src="{{ asset('backend/js/jquery.PrintArea.js') }}"></script>
  <script src="{{ asset('backend/js/select2.min.js') }}"></script>
  <script src="{{ asset('toastr/toastr.min.js') }}"></script>
  <script src="{{ asset('backend/summernote/summernote-bs4.js') }}"></script>


  <script src="{{ asset('backend/ckeditor4/ckeditor.js') }}"></script>

  <script src="{{ asset('backend/iconpicker/fontawesome-iconpicker.min.js') }}"></script>

<script>


// <tr>
//                             <th>Property Type  :  </th> 
//                             <td>${value.property.property_type_id ?? ""}</td>
//                             </tr>
//                             <tr>
  $(".location").on('click',function(e) {

            e.preventDefault();
            var data = $(this).val();
            $.ajaxSetup({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              }
          });
            $.ajax({
                type:'POST',
                url: "{{route('agents.ajax-auction')}}",
                data:{data:data},
                success:function(response){
                  
                    var html = ``;
                    $.each(response.kyclist , function(index, value){
                      // console.log(response.currency.currency_icon);
                    html += ` <h5>Customer Infomation</h5>
                    <table class="table">
                            <tr>
                            <th>Name :  </th> 
                            <td>${value.user.name ?? ""}</td>
                            </tr>
                            <tr>
                            <th>Email :  </th> 
                            <td>${value.user.email ?? ""}</td>
                            </tr>
                            <tr >
                            <th>Property Name  :  </th> 
                            <td>${value.property.title ?? ""}</td>
                            </tr>
                            
                            <th>Date :  </th> 
                            <td>${('d-m-Y'), (value.created_at ?? '')}</td>
                            </tr>
                            </table>
                            <h5>KYC Details</h5>
                            <table class="table" >
                            <tr>
                            <th>Aadhar No :  </th> 
                            <td>${value.aadhaar_no ?? ""}</td>
                            </tr>
                            <tr>
                            <tr>
                            <th>Bank Account No :  </th> 
                            <td>${value.bank_account_no ?? ""}</td>
                            </tr>
                            <tr>
                            <tr>
                            <th>IFSC Code :  </th> 
                            <td>${value.ifsc_code ?? ""}</td>
                            </tr>
                            <tr>
                            <tr>
                            <th>Pan No :  </th> 
                            <td>${value.pan_no ?? ""}</td>
                            </tr>
                            <tr>
                            </table>
                            <table  >
                            <h5  ${value.transaction ?? "style='display:none;'"}>Transaction Details</h5>
                            <table class="table"  ${value.transaction ?? "style='display:none;'"}">
                            <tr>
                            <th>Transaction Details :  </th>
                            <td>${(value.transaction) ? value.transaction.transaction_details : "" }</td>
                            </tr>
                            <tr>
                            <tr>
                            <th>Payment Method :  </th> 
                            <td>${(value.transaction) ? value.transaction.payment_method : "" }</td>
                            </tr>
                            <tr>
                            <tr>
                            <th>Amount:  </th> 
                            <td> ${response.currency.currency_icon ?? ""} ${(value.transaction) ? value.transaction.amount : ""} </td>
                            </tr>
                            <tr>
                            <tr>
                            <th>Status:  </th> 
                            <td> ${(value.transaction) ? ((value.transaction.status == "1") ? "<p style='color:green;'>Paid</p>" : "<p style='color:red;'>Pending</p>") : ''}</td>
                            </tr>
                            <tr>
                            </table>
                           
                            `; 
                    });
                  $("#user-key-details").html(html);
                  $("#newLocation").modal('show');
                }
            });
        });

</script>

<script>
  $('#modalclose').on('click',function(){
    $('#newLocation').modal('hide');
  });
</script>
<script>

$(document).ready(function(){
  $(".enqdetails").on('click',function(e) {
            e.preventDefault();
            var data = $(this).val();
            $.ajaxSetup({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              }
          });
            $.ajax({
                type:'POST',
                url: "{{route('agents.ajax-auction-enq')}}",
                data:{data:data},
                success:function(response){
                  console.log(response);
                    var html = ``;
                    $.each(response.kyclist , function(index, value){
                      // console.log(value);
                    html += `<table class="table" ${value.property ?? "style='display:none;'"}>
                            <tr>
                            <th>Property Name : </th> 
                            <td>${value.property.title }</td>
                            </tr>
                            <tr>
                            <th>Auction Date :  </th> 
                            <td>${'d-m-Y', (value.created_at ?? '')}</td>
                            </tr>
                            <tr>
                            <th>Email :  </th> 
                            <td>${value.email}</td>
                            </tr>
                            <tr>
                            <th>Message :  </th> 
                            <td>${value.message}</td>
                            </tr>
                          
                            </table>`; 
                    });
                  $("#user-key-details").html(html);
                  $("#newLocation").modal('show');
                }
            });
        });
      });

</script>
@endsection
