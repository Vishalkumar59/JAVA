<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdminRole extends Model
{
   
    protected $table = 'admin_roles';
    protected $primaryKey = 'roles_id';

    protected $fillable=[
       'roles_name','status'
    ];
}
