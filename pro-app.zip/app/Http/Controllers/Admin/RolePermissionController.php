<?php

namespace App\Http\Controllers\Admin;

use App\Admin;
use App\ManageText;
use App\NotificationText;
use App\ValidationText;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Hash;
use Auth;
use Str;
use App\AdminRoleHasSection;
use File;
use App\AdminSection;
use App\AdminRole;


class RolePermissionController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $rolelist = AdminRole::all();
        $websiteLang=ManageText::all();
        $confirmNotify=$websiteLang->where('lang_key','are_you_sure')->first()->custom_text;
        return view('admin.role-permission.index',compact('rolelist','websiteLang','confirmNotify'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $websiteLang=ManageText::all();
        $adminsectionlist = AdminSection::All();
        return view('admin.role-permission.create',compact('websiteLang','adminsectionlist'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $rolelist = AdminRole::find($id);
        $websiteLang=ManageText::all();
        $adminsectionlist = AdminSection::All();
        $adminrolelist = AdminRoleHasSection::where('roles_id' , $id)->get();
        
        return view('admin.role-permission.edit',compact('rolelist','websiteLang','adminsectionlist','adminrolelist'));
    }

    


    public function store(Request $request)
    {
        
        
        $valid_lang=ValidationText::all();
        $rules = [
            'role_name'=>'required',
            'section_name'=>'required',
        ];
        $customMessages = [
            'role_name.required' => $valid_lang->where('lang_key','role_name')->first()->custom_text,
            'section_name.required' => $valid_lang->where('lang_key','section_name')->first()->custom_text,
        ];
        $this->validate($request, $rules, $customMessages);

        $admin=new AdminRole();
        $admin->roles_name=$request->role_name;
        $admin->status = 1;
        $admin->save();

        $role_id  = $admin->roles_id;
        $sectiondata = $request->section_name;
        foreach($sectiondata as $key=>$value){
            AdminRoleHasSection::create([
                'roles_id' => $role_id,
                'section_id' => $value
            ]);
        }


        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','create')->first()->custom_text;
        $notification=array('messege'=>$notification,'alert-type'=>'success');

        return redirect()->route('admin.role-Permission.index')->with($notification);
    }

    public function update(Request $request, $id)
    {

        


        $valid_lang=ValidationText::all();
        $rules = [
            'role_name'=>'required',
            'section_name'=>'required',
        ];
        $customMessages = [
            'role_name.required' => $valid_lang->where('lang_key','role_name')->first()->custom_text,
            'section_name.required' => $valid_lang->where('lang_key','section_name')->first()->custom_text,
        ];
        $this->validate($request, $rules, $customMessages);


        //    manage image
        $admin=AdminRole::find($id);
        $admin->roles_name=$request->role_name;
        $admin->status = 1;
        $admin->update();


        AdminRoleHasSection::where('roles_id', $id)->delete();
        
        $sectiondata = $request->section_name;
        foreach($sectiondata as $key=>$value){
            AdminRoleHasSection::updateOrCreate(
                ['roles_id'=>$id , 'section_id' => $value]);
        }
        
    //}


        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','update')->first()->custom_text;
        $notification=array('messege'=>$notification,'alert-type'=>'success');

        return redirect()->route('admin.role-Permission.index')->with($notification);

    }


    public function destroy($id)
    {
        
        $admin=AdminRole::find($id);
        AdminRoleHasSection::where('roles_id', $id)->delete();
        $old_image=$admin->image;
        $admin->delete();

        if($old_image){
            if(File::exists(public_path().'/'.$old_image))unlink(public_path().'/'.$old_image);
        }

        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','delete')->first()->custom_text;
        $notification=array('messege'=>$notification,'alert-type'=>'success');

        return redirect()->route('admin.role-Permission.index')->with($notification);
    }

  

    public function roleStatus($id){
        $role_status=AdminRole::find($id);
        if($role_status->status==1){
            $role_status->status=0;
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','inactive')->first()->custom_text;
            $message=$notification;
        }else{
            $role_status->status=1;
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','active')->first()->custom_text;
            $message=$notification;
        }
        $role_status->save();
        return response()->json($message);
    }

   
}
