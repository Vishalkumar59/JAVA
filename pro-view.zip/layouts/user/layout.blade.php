
@include('layouts.user.header')
  @yield('user-content')
@include('layouts.user.footer')
