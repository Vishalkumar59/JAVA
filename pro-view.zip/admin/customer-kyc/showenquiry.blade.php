@extends('layouts.admin.layout')
@section('title')
<title>{{$userenquiryshow->user->name}}</title>
@endsection
@section('admin-content')

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><a href="{{ route('admin.customer-kyc') }}" class="btn btn-success"> <i class="fas fa-backward" aria-hidden="true"></i> {{ $websiteLang->where('lang_key','go_back')->first()->custom_text }} </a></h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">{{ $websiteLang->where('lang_key','customer_information')->first()->custom_text }}</h6>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr>
                    <td>{{ $websiteLang->where('lang_key','customer_name')->first()->custom_text }}</td>
                    <td>{{ $userenquiryshow->user->name}}</td>
                </tr>
                <tr>
                    <td>{{ $websiteLang->where('lang_key','email')->first()->custom_text }}</td>
                    <td>{{ $userenquiryshow->user->email}}</td>
                </tr>
                <tr>
                    <td>{{ $websiteLang->where('lang_key','property_name')->first()->custom_text }}</td>
                    <td>{{ $userenquiryshow->property->title}}</td>
                </tr>
                <tr>
                    <td>{{ $websiteLang->where('lang_key','agent_name')->first()->custom_text }}</td>
                    <td>{{ $userenquiryshow->property->user->name}}</td>
                </tr>
                <tr>
                    <td>{{ $websiteLang->where('lang_key','phone')->first()->custom_text }}</td>
                    <td>{{ $userenquiryshow->user->phone }}</td>
                </tr>
                <tr>
                    <td>{{ $websiteLang->where('lang_key','message1')->first()->custom_text }}</td>
                    <td>{{ $userenquiryshow->message}}</td>
                </tr>

            </table>
        </div>
    </div>
  
    <script>

        function userStatus(id){
            $.ajax({
                type:"get",
                url:"{{url('/admin/agents-status/')}}"+"/"+id,
                success:function(response){
                   toastr.success(response)
                },
                error:function(err){
                    console.log(err);

                }
            })
        }
    </script>
@endsection
