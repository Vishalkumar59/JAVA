@extends('layouts.user.layout')
@section('title')
<title>{{ $websiteLang->where('lang_key','show_payment')->first()->custom_text }}</title>
@endsection
@section('user-content')


<style>
.paytm_btn{
    width: 39%!important;
}
.pay_btn{
    justify-content: space-between;
}
</style>


<section>
    <div class="container-fluid ">
        
            <div class="row justify-content-center ms-5">
                <div class="col-sm-5 p-4 paybutton">
                <div class="row justify-content-center">
                <div class="col-sm-6 text-center p-4 mt-4">
                        <h4>EMD Amount</h4>
                        <h2 class="text-center">{{$currency->currency_icon}} {{$showprice}}</h2>

                    </div>
                </div> 
                    <div class="row">
                        <div class="col-md-4">
                            @if ($razorpay->razorpay_status==1)
                            {{-- <button class="common_btn w-100 razorpay" ><i id="reg-spinner" class="loading-icon fa fa-spin fa-spinner d-none"></i>{{ $websiteLang->where('lang_key','razorpay')->first()->custom_text }}</button> --}}
                            <form action="{{ route('agents.razorpay') }}" method="POST" >
                                    @csrf
                                    @php
                                        $payableAmount = round($showprice * $razorpay->currency_rate,2);
                                    @endphp
                                    <script src="https://checkout.razorpay.com/v1/checkout.js"
                                            data-key="{{ $razorpay->razorpay_key }}"
                                            data-currency="{{ $razorpay->currency_code }}"
                                            data-amount= "{{ $payableAmount * 100 }}"
                                            data-buttontext="{{ $websiteLang->where('lang_key','razorpay')->first()->custom_text }} "
                                            data-name="{{ $razorpay->name }}"
                                            data-description="{{ $razorpay->description }}"
                                            data-image="{{ asset($razorpay->image) }}"
                                            data-prefill.name=""
                                            data-prefill.email=""
                                            data-theme.color="{{ $razorpay->theme_color }}">
                                    </script>
                            </form>
                            @endif
                        </div>
                        <div class="col-md-4">
                            
                            <button class="common_btn instamojo" ><i id="reg-spinner" class="loading-icon fa fa-spin fa-spinner d-none"></i>{{ $websiteLang->where('lang_key','instamojo')->first()->custom_text }}</button>
                        </div>
                        <div class="col-md-4">
                            <form action="{{ route('user.payment') }}" class="form-image-upload" method="POST" enctype="multipart/form-data">
                                {!! csrf_field() !!}
                                @if (count($errors) > 0)
                                    <div class="alert alert-danger">
                                        <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                        <ul>
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif


                                <div class="row">
                                    <div class="col-md-12">
                                        <input type="hidden" name="name" value="test" class="form-control" placeholder="Name">
                                    </div>
                                    <div class="col-md-12">
                                        <input type="hidden" name="mobile_no" value="7548257745" class="form-control" placeholder="Mobile No.">
                                    </div>
                                    <div class="col-md-12">
                                        <input type="hidden" class="form-control" value="test" placeholder="Address" name="address">
                                    </div>
                                    
                                    <div class="col-md-12">
                                        
                                        <button class="common_btn  paytm"  ><i id="reg-spinner" class="loading-icon fa fa-spin fa-spinner d-none"></i>{{ $websiteLang->where('lang_key','paytm')->first()->custom_text }}</button> 
                                    </div>
                                </div>
                            </form>
                        </div>

                        <h1 class="mt-5">Bank Details</h1>
                        @foreach ($bankdeails as $bankdeail)
                        
                            Bank Ac/N : {{$bankdeail->acount_number}} <br/>
                            Bank Name : {{$bankdeail->bank}} <br/>
                            Branch : {{$bankdeail->Branch}} <br/>
                            IFSC Code : {{$bankdeail->ifsc}} <br/>
                        @endforeach
                    </div>
              
            </div>

            
        </div>
        
        <div class="col-sm-4 p-4 mx-auto">
            @if ($razorpay->razorpay_status==1)
                <div id="v-pills-messages" class="text-center">
                   
                </div>
            @endif

            @if ($razorpay->razorpay_status==1)
            <div class="text-center" id="instamojoTab">
                <a href="" class="common_btn mt_25">{{ $websiteLang->where('lang_key','pay_with_instamojo')->first()->custom_text }}</a>
            </div>
            @endif
                
    </div>


   
</section>

<script>

//$("#v-pills-messages").hide();
$("#instamojoTab").hide();
//$("#v-paytm-messages").hide();

$( ".razorpay" ).on( "click", function() {
   // $("#v-pills-messages").show();
   // $(".paybutton").hide();
});
$( ".instamojo" ).on( "click", function() {
    $(".paybutton").hide();
    $("#instamojoTab").show();
});

$( ".paytm" ).on( "click", function() {
    //$(".paybutton").hide();
    //$("#v-paytm-messages").show();
});

</script>
@endsection