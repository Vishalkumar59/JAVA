<?php

namespace App\Http\Controllers\API;
use App\Http\Controllers\Controller;
use App\BannerImage;
use App\City;
use App\ManageText;
use App\Navigation;
use App\Property;
use App\PropertyType;
use App\SeoText;
use App\UserEnquiryDetails;
use Illuminate\Pagination\Paginator;
use Illuminate\Http\Request;
use App\ListingCategory;
use App\PropertyPurpose;
use App\Aminity;
use App\PropertyAminity;
use App\PropertyImage;
use App\Bank;
use App\Wishlist;
use App\NearestLocation;
use App\PropertyReview;
use Str;
use File;
use Image;
use App\Setting;
use App\Locality;
use App\PropertyCategory;
use App\ValidationText;
use App\PropertyNearestLocation;
use App\NotificationText;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class APIPropertyController extends Controller
{
    
    


    public function index()
    {
        $property['allProperty'] = Property::where('status',1)->get();
        return response()->json($property);
    }
   
    
    public function store(Request $request)
    {

       
        $validator = Validator::make($request->all(), [
            'title'=>'required|unique:properties',
            'slug'=>'required|unique:properties',
            'property_type'=>'required',
            'city'=>'required',
            'address'=>'required',
            'purpose'=>'required',
            'price'=>'required|numeric',
            'thumbnail_image'=>'required',
            'description'=>'required',
            'status'=>'required',
            'featured'=>'required',
            'urgent_property'=>'required',
            // "pdf_file" => "mimes:pdf|max:10000",
            'pincode' => 'required',
           'bank' => 'required',
            'finance' => 'required',
            'locality' =>'required',
        //     'auction' =>'required',
        //    'emd_amount' => 'required',
           ]);
       if ($validator->fails()) {
               return response()->json([
                 'message' => 'Filled is Required', // the ,message you want to show
                   'errors' => $validator->errors()
               ], 422);
           }
      

        // $locality = Locality::create([
        //     'locality_name' => $request->locality,
        //     'city_id' => $request->city,
        //      ]);
    
        // $locality_id = $locality->id;

        $randomString = Str::random(20);
      
        $video_link='';
        if(preg_match('/https:\/\/www\.youtube\.com\/watch\?v=[^&]+/', $request->video_link)) {
            $video_link=$request->video_link;
        }

        if($request->city){
            $value = City::where('name' , $request->city)->first();
        }else{
            $value = '';
        }
        if($request->property_type){
            $property_type = PropertyType::where('type' , $request->property_type)->first();
        }else{
            $property_type = '';
        }
        if($request->purpose){
            $purpose = PropertyPurpose::where('custom_purpose' , $request->purpose)->first();
            if($purpose->id == 1)
            {
            $validator = Validator::make($request->all(), [
                'area'=>'required',
                'unit'=>'required',
                'room'=>'required',
                'bedroom'=>'required',
                'bathroom'=>'required',
                'floor'=>'required',
                'kitchen'=>'required',
                'parking'=>'required',
            ]);
                if ($validator->fails()) {
                    return response()->json([
                    'message' => 'Filled is Required', // the ,message you want to show
                        'errors' => $validator->errors()
                    ], 422);
                }
             }else{
                $validator = Validator::make($request->all(), [
                    'vehicle_name'=>'required',
                    'vehicle_type'=>'required',
                    'vehicle_price'=>'required',
                    'vehicle_size'=>'required',

                ]);
                if ($validator->fails()) {
                    return response()->json([
                    'message' => 'Filled is Required', // the ,message you want to show
                        'errors' => $validator->errors()
                    ], 422);
                }
        }

        }else{
            $purpose = '';
        }


        if($request->bank){
            $bank = Bank::where('name' , $request->bank)->first();
        }else{
            $bank = '';
        }
        if($request->locality){
            $Locality = Locality::where('locality_name' , $request->Locality)->first();
        }else{
            $Locality = '';
        }
    try{
        $property=new Property();
        // $property->admin_id=3;
        $property->title=$request->title;
        $property->slug=$request->slug;
        $property->property_type_id=$property_type->id;
        $property->city_id=$value->id;
        $property->address=$request->address;
        $property->property_unique_id = $request->property_unique_id ? $request->property_unique_id : $randomString;
        $property->locality = $Locality->locality_id;
        // $property->phone=$request->phone;
        // $property->email=$request->email;
        $property->website=$request->website;
        $property->category_id=$purpose->id;
        $property->price=$request->price;
        $property->period=$request->period ? $request->period : null;
        $property->area=$request->area;
        $property->number_of_unit=$request->unit;
        $property->number_of_room=$request->room;
        $property->number_of_bedroom=$request->bedroom;
        $property->number_of_bathroom=$request->bathroom;
        $property->number_of_floor=$request->floor;
        $property->number_of_kitchen=$request->kitchen;
        $property->number_of_parking=$request->parking;
        $property->video_link=$video_link;
        $property->google_map_embed_code=$request->google_map_embed_code;
        $property->description=$request->description;
        $property->status=$request->status;
        $property->is_featured=$request->featured;
        $property->urgent_property=$request->urgent_property;
        $property->top_property=$request->top_property;
        $property->seo_title=$request->seo_title ? $request->seo_title : $request->title;
        $property->seo_description=$request->seo_description ? $request->seo_description : $request->title;
        $property->pincode=$request->pincode;
        $property->bank_id = $bank->id;
        $property->finance = $request->finance;
        $property->auction = $request->auction;
        $property->emd_amount = $request->emd_amount;

        $property->vehicle_name = $request->vehicle_name;
        $property->vehicle_type = $request->vehicle_type;
        $property->vehicle_price = $request->vehicle_price;
        $property->vehicle_size = $request->vehicle_size;
        $property->property_enquiry = $request->property_enquiry;




        // pdf file
        if($request->file('pdf_file')){
            $file=$request->pdf_file;
            $file_ext=$file->getClientOriginalExtension();
            $file_name= 'property-file-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$file_ext;
            $file_path=$file_name;
            $file->move(public_path().'/uploads/custom-images/',$file_path);
            $property->file=$file_path;
        }


        //thumbnail image
        // if($request->file('thumbnail_image')){
        //     $thumbnail_image=$request->thumbnail_image;
        //     $thumbnail_extention=$thumbnail_image->getClientOriginalExtension();
        //     $thumb_name= 'property-thumb-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$thumbnail_extention;
        //     $thumb_path='uploads/custom-images/'.$thumb_name;

        //     Image::make($thumbnail_image)
        //     ->save(public_path()."/".$thumb_path);
        //     $property->thumbnail_image=$thumb_path;

        // }

        if($request->file('thumbnail_image')){
            $thumbnail_image=$request->thumbnail_image;
            $thumbnail_extention=$thumbnail_image->getClientOriginalExtension();
            $property->thumbnail_image = $request->thumbnail_image;
            $thumb_name= 'property-thumb-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$thumbnail_extention;
            $thumb_path='uploads/custom-images/'.$thumb_name;
            $property->thumbnail_image=$thumb_path;

        }

        // banner image image
        if($request->file('banner_image')){
            $banner_image=$request->banner_image;
            $banner_ext=$banner_image->getClientOriginalExtension();
            $banner_name= 'listing-banner-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$banner_ext;
            $banner_path='uploads/custom-images/'.$banner_name;
            Image::make($banner_image)
                ->save(public_path()."/".$banner_path);
                $property->banner_image=$banner_path;

        }
        // else{
        //     $banner_image=$request->thumbnail_image;
        //     $banner_ext=$banner_image->getClientOriginalExtension();
        //     $banner_name= 'listing-banner-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$banner_ext;
        //     $banner_path='uploads/custom-images/'.$banner_name;
        //     Image::make($banner_image)
        //         ->save(public_path().'/'.$banner_path);
        //         $property->banner_image=$banner_path;
        // }
        $property->save();
       
       
        // property end

        // insert aminity
        if($request->aminities){
            foreach($request->aminities as $amnty){
                $aminity= new PropertyAminity();
                $aminity->property_id=$property->id;
                $aminity->aminity_id=$amnty;
                $aminity->save();
            }
        }

        // insert nearest place
        $exist_location=[];
        if($request->nearest_locations){
            foreach($request->nearest_locations as $index => $location){
                if($location){
                    if($request->distances[$index]){
                        if(!in_array($location, $exist_location)){
                            $nearest_location= new PropertyNearestLocation();
                            $nearest_location->property_id=$property->id;
                            $nearest_location->nearest_location_id=$location;
                            $nearest_location->distance=$request->distances[$index];
                            $nearest_location->save();
                        }
                        $exist_location[]=$location;

                    }
                }
            }
        }

        // slider image
        if($request->file('slider_images')){
            $images=$request->slider_images;
            foreach($images as $image){
                if($image != null){
                    $propertyImage=new PropertyImage();
                    $slider_ext=$image->getClientOriginalExtension();
                    // for small image
                    $slider_image= 'property-slide-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$slider_ext;
                    $slider_path='uploads/custom-images/'.$slider_image;

                    Image::make($image)
                        ->save(public_path()."/".$slider_path);

                    $propertyImage->image=$slider_path;
                    $propertyImage->property_id=$property->id;
                    $propertyImage->save();

                }
            }
        }
        $data['property'] = $property;
        return response()->json($data);
    } catch (Exception $e) {
        $data['property'] ="Something went wrong";
        return response()->json($data);
    }


    }

    public function edit($id)
    {
        $property['Property'] = Property::find($id);
        return response()->json($property);
    }

    public function update(Request $request, $id) {

        $Property = Property::find($id);
         if($Property){
        $Property->update($request->all());

        $Property->save();
        return response()->json(['Update Property Successfully' => $Property]);
         }else{
            return response()->json("Property not found");
         }
    }

       
    public function delete($id)
    {
        $property = Property::find($id);
        if($property){
        $old_thumbnail=$property->thumbnail_image;
        $old_banner=$property->banner_image;
        $old_pdf=$property->file;
        PropertyAminity::where('property_id',$property->id)->delete();
        WishList::where('property_id',$property->id)->delete();
        PropertyReview::where('property_id',$property->id)->delete();
        PropertyNearestLocation::where('property_id',$property->id)->delete();
        foreach($property->propertyImages as $image){
            if(File::exists(public_path().'/'.$image->image)) unlink(public_path().'/'.$image->image);
        }
        PropertyImage::where('property_id',$property->id)->delete();


        if($old_pdf){
            if(File::exists(public_path().'/'.'uploads/custom-images/'.$old_pdf)) unlink(public_path().'/'.'uploads/custom-images/'.$old_pdf);
        }
        // if(File::exists(public_path().'/'.$old_thumbnail)) unlink(public_path().'/'.$old_thumbnail);
        // if(File::exists(public_path().'/'.$old_banner)) unlink(public_path().'/'.$old_banner);

        $property->delete();
        $data['Property'] = $property;
        return response()->json(['property delete' => $data,'message' => 'property delete successfully']);
    }else{
        return response()->json('Property not found');
    }

    }
}