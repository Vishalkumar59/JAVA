
<p>{{ $emails['body'] }}.</p>