@extends('layouts.admin.layout')
@section('title')
<title>{{ $websiteLang->where('lang_key','role_create')->first()->custom_text }}</title>
@endsection
<style>

</style>
@section('admin-content')
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><a href="{{route('admin.role-Permission.index')}}" class="btn btn-primary"><i class="fas fa-list" aria-hidden="true"></i> {{ $websiteLang->where('lang_key','go_back')->first()->custom_text }} </a></h1>
    <!-- DataTales Example -->
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">{{ $websiteLang->where('lang_key','role_form')->first()->custom_text }}</h6>
                </div>
                <div class="card-body">

                    <form action="{{ route('admin.role-Permission.update',$rolelist->roles_id) }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('patch')
                        <div class="form-group col-md-6">
                            <label for="role_name">{{ $websiteLang->where('lang_key','role_name')->first()->custom_text }}</label>
                            <input type="text" name="role_name" value="{{$rolelist->roles_name}}" class="form-control" id="role_name" value="{{ old('role_name') }}">
                        </div>
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label
                                        for="category">{{ $websiteLang->where('lang_key', 'section_name')->first()->custom_text }}
                                        <span class="text-danger">*</span></label>
                                        <select name="section_name[]" multiple="multiple"  id="section_name" class="form-control select2">
                                            @foreach ($adminsectionlist as $adminsection)
                                                @php
                                                    $selected = '';
                                                    foreach($adminrolelist as $adminrole){
                                                        if($adminrole->section_id == $adminsection->id){
                                                            $selected ='selected';
                                                        }
                                                    }

                                                @endphp
                                                <option value="{{ $adminsection->id }}" {{$selected}}>{{ $adminsection->section_name }}
                                                </option>
                                            @endforeach

                                        </select>
                                </div>
                            </div>

                        <button type="submit" class="btn btn-success">{{ $websiteLang->where('lang_key','save')->first()->custom_text }}</button>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <script>
        (function($) {
        "use strict";
        $(document).ready(function () {
            $("#title").on("focusout",function(e){
                $("#slug").val(convertToSlug($(this).val()));
            })

        });

        })(jQuery);

        function convertToSlug(Text)
            {
                return Text
                    .toLowerCase()
                    .replace(/[^\w ]+/g,'')
                    .replace(/ +/g,'-');
            }
    </script>

@endsection
