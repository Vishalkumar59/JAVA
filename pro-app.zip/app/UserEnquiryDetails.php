<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserEnquiryDetails extends Model
{
    protected $table = 'user_enq_details';

    protected $fillable=[
        'user_id','property_id','name','email','message'
    ];


    public function property()
    {
        return $this->belongsTo(Property::class, 'property_id', 'id');
    }

    public function user(){
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    

    
}