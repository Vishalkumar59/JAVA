@extends('layouts.admin.layout')

@section('title')

    <title>{{ $websiteLang->where('lang_key','import')->first()->custom_text }}</title>

@endsection
@section('admin-content')
 <div class="col-xl-12 ms-auto">
  <div class="wsus__dashboard_main_content">
  
  <div class="row">
        <div class="col-md-12">
          <h4 class="heading text-danger font-weight-bold ">{{ $websiteLang->where('lang_key','bulk_import')->first()->custom_text }} </h4>
        </div>
        <div class="card shadow mb-4 col-md-12" id="properties">
        <div class="wsus__dash_info  p_25 mt_25">
          <form action="{{route('admin.import')}}"  method="POST" enctype="multipart/form-data" >
            @csrf
             <div class="row">
                  <div class="col-xl-6 col-md-6">
                   <label for="file">{{ $websiteLang->where('lang_key', 'select_csv_file')->first()->custom_text }} <span class="text-danger">*</span></label>
                    <input type="file"  name="file"/></br></br>
                    <label for="file">For sample File</label>
                    <a href="{{route('admin-donwload-file')}}">Download Now</a>
                    <input type="submit" class="btn btn-danger d-block mt-4"/>
                  </div>
              </div> 
          </form>
        </div>
    </div>
  </div>
</div>
</div>

@endsection

