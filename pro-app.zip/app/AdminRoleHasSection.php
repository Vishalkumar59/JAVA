<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdminRoleHasSection extends Model
{
   
    protected $table = 'admin_role_has_section';
    public $timestamps = false;
    protected $primaryKey = 'roles_id';

    protected $fillable=[
        'roles_id','section_id'
    ];
}
