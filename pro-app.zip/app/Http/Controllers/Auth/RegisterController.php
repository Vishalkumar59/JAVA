<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\User;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Mail\UserVerification;
use Str;
use Mail;
use App\Rules\Captcha;
use App\Setting;
use App\BannerImage;
use App\Navigation;
use App\Mail\EnquiryConfirmation;
use App\ManageText;
use App\EmailTemplate;
use App\ValidationText;
use App\NotificationText;
use App\Helpers\MailHelper;
use App\Mail\sendingEmail;
use Log;

class RegisterController extends Controller
{


    use RegistersUsers;


    protected $redirectTo = RouteServiceProvider::HOME;

    public function __construct()
    {
        $this->middleware('guest:web');
    }


    public function userRegisterPage(){
        return redirect()->to('/invalid');
    }


    public function otpgenerater(Request $request){


        $valid_lang=ValidationText::all();
        $rules = [
            'email'=>'required|unique:users|email',
            'number'=>'required|min:10|regex:/^[6-9]\d{9}$/|max:10',
        ];
        $customMessages = [
            'number.required' => $valid_lang->where('lang_key','mobile')->first()->custom_text,
            'number.regex' => $valid_lang->where('lang_key','mobile_valid')->first()->custom_text,
            'number.max' => $valid_lang->where('lang_key','max_number')->first()->custom_text,
            'email.required' => $valid_lang->where('lang_key','email')->first()->custom_text,
            'email.unique' => $valid_lang->where('lang_key','unique_email')->first()->custom_text,
            
        ];
        $this->validate($request, $rules, $customMessages);
        
        $user=User::create([
            'name'=>'Test',
            'slug'=>'test',
            'email'=>$request->email,
            'phone' => $request->number,
            'user_type' => $request->reg_type,
            'status' =>1,
            //'password'=>Hash::make($request->password),
            'password'=>Hash::make('test'),
            'email_verified_token'=>Str::random(100)
        ]);

        $otp = rand(1000,9999);
        Log::info("otp = ".$otp);
        
       

        $mail_details = [
            'subject' => 'Testing Application OTP',
            'body' => 'Your OTP is : '. $otp
        ];



       
        \Mail::to($request->email)->send(new sendingEmail($mail_details));


        $request->session()->put('otp', $otp);
        $request->session()->put('email' , $user->email);
        $request->session()->put('user_id' , $user->id);

        
        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','register')->first()->custom_text;
        
        return response()->json(['success'=>$notification]);

    }

    public function otp_verification(Request $request){

        $banner_image=BannerImage::find(11);
        $setting=Setting::first();
        $menus=Navigation::all();
        $allowLogin=$menus->where('id',12)->first();
        if($allowLogin->status!=1){
        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
        $notification=array('messege'=>$notification,'alert-type'=>'error');
        return redirect()->route('home')->with($notification);
    }

    $websiteLang=ManageText::all();

        return view('auth.otp-veryfication' , compact('banner_image','setting','menus','websiteLang'));
    }

    public function confirmation(Request $request){

    try{

        $valid_lang=ValidationText::all();
        $rules = [
            'emailotp'=>'required',
            'numberotp'=>'required',
        ];

        $customMessages = [
            'emailotp.required' => $valid_lang->where('lang_key','emailvalid')->first()->custom_text,
           
            'numberotp.required' => $valid_lang->where('lang_key','phonevalid')->first()->custom_text,
            
        ];

        $this->validate($request, $rules, $customMessages);

        $emailotp = $request->session()->get('otp');
        


        if($request->emailotp == $emailotp){
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','success')->first()->custom_text;
            return response()->json(['success'=>$notification]);
        }
        else{
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','otp_error')->first()->custom_text;
            return response()->json(['error'=>$notification]);
        }

    } catch (Exception $e) {
                $notify_lang=NotificationText::all();
                $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
                $notification=array('messege'=>$notification,'alert-type'=>'error');
                return redirect()->back()->with($notification);
            }

        
    }

    public function create_password(Request $request){

        $banner_image=BannerImage::find(11);
        $setting=Setting::first();
        $menus=Navigation::all();
        $websiteLang=ManageText::all();

        $template=EmailTemplate::where('id',15)->first();
        $message=$template->description;
        $subject=$template->subject;

        $email = $request->session()->get('email');


        Mail::to($email)->send(new EnquiryConfirmation($message,$subject));

        return view('auth.create-password' , compact('banner_image','setting','menus','websiteLang'));
    }




    public function dashboard(Request $request){
        $user_id = $request->session()->get('user_id');

        $valid_lang=ValidationText::all();
        $rules = [
            'password'=>'required',
            'password_confirmation'=>'required',
        ];

        $customMessages = [
            'password.required' => $valid_lang->where('lang_key','password')->first()->custom_text,
           
            'password_confirmation.required' => $valid_lang->where('lang_key','password_confirmation')->first()->custom_text,
            
        ];

        $this->validate($request, $rules, $customMessages);

        User::where('id',$user_id)->update(['password'=>Hash::make($request->password)]);

        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','success')->first()->custom_text;
        return response()->json(['success'=>$notification]);
    }

    

    public function storeRegister(Request $request){

        $otp = $request->session()->get('otp');


        $valid_lang=ValidationText::all();
        $rules = [
            'email'=>'required|unique:users|email',
            'number'=>'required',
            'g-recaptcha-response'=>new Captcha()
        ];
        $customMessages = [
            'number.required' => $valid_lang->where('lang_key','name')->first()->custom_text,
            'name.unique' => $valid_lang->where('lang_key','unique_name')->first()->custom_text,
            'email.required' => $valid_lang->where('lang_key','email')->first()->custom_text,
            'email.unique' => $valid_lang->where('lang_key','unique_email')->first()->custom_text,
            'password.required' => $valid_lang->where('lang_key','pass')->first()->custom_text,
            'password.min' => $valid_lang->where('lang_key','min_pass')->first()->custom_text,
        ];
        $this->validate($request, $rules, $customMessages);

        if($request->email == $otp){
        $user=User::create([
            'name'=>$request->name,
            'slug'=>Str::slug($request->name),
            'email'=>$request->email,
            'password'=>Hash::make($request->password),
            'email_verified_token'=>Str::random(100)
        ]);
    }

        MailHelper::setMailConfig();

        $template=EmailTemplate::where('id',5)->first();
        $message=$template->description;
        $subject=$template->subject;
        $message=str_replace('{{user_name}}',$user->name,$message);

        Mail::to($user->email)->send(new UserVerification($user,$message,$subject));

        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','register')->first()->custom_text;

        return response()->json(['success'=>$notification]);

    }

    public function userVerify($token){
        $user=User::where('email_verified_token',$token)->first();
        $notify=NotificationText::first();
        if($user){
            $user->email_verified_token=null;
            $user->status=1;
            $user->email_verified=1;
            $user->save();
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','verified')->first()->custom_text;
            $notification=array('messege'=>$notification,'alert-type'=>'success');
            return  redirect()->route('login')->with($notification);
        }else{

            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','invalid_token')->first()->custom_text;
            $notification=array('messege'=>$notification,'alert-type'=>'error');
            return redirect()->route('register')->with($notification);
        }
    }



    public function registration(){
        $banner_image=BannerImage::find(11);
        $setting=Setting::first();
        $menus=Navigation::all();
        $websiteLang=ManageText::all();
        return view('auth.registration' , compact('banner_image','setting','menus','websiteLang'));
    }
}
            
           