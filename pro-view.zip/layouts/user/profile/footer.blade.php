
<style type="text/css">
.float{
  position:fixed;
  width:60px;
  height:60px;
  bottom:40px;
  left:40px;
  background-color:#25d366;
  color:#FFF;
  border-radius:50px;
  text-align:center;
  font-size:30px;
  box-shadow: 2px 2px 3px #999;
  z-index:100;
}

.my-float{
  margin-top:16px;
}
</style>
{{-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<a href="https://api.whatsapp.com/send?phone=917548759584" class="float" target="_blank">
<i class="fa fa-whatsapp my-float"></i> --}}
</a>
</div>
</section>
<!--============================
  DASHBOARD PART END
==============================-->


<!---=====SCROLL BUTTON START=====-->
<div class="wsus__scroll_btn">
  <i class="fas fa-chevron-up"></i>
</div>
<!---=====SCROLL BUTTON END=====-->
@php
$setting=App\Setting::first();
@endphp

<!--bootstrap js-->
<script src="{{ asset('user/js/bootstrap.bundle.min.js') }}"></script>
<!--font-awesome js-->
<script src="{{ asset('user/js/Font-Awesome.js') }}"></script>
<!--slick js-->
<script src="{{ asset('user/js/slick.min.js') }}"></script>
<!--select-2 js-->
<script src="{{ asset('user/js/select2.min.js') }}"></script>
<!--counter-2 js-->
<script src="{{ asset('user/js/jquery.waypoints.min.js') }}"></script>
<script src="{{ asset('user/js/jquery.countup.min.js') }}"></script>
<!--add row custon js-->
<script src="{{ asset('user/js/add_row_custon.js') }}"></script>
<!--sticky sidebar js-->
<script src="{{ asset('user/js/sticky_sidebar.js') }}"></script>
<!--summer note js-->


<!--main/custom js-->
<script src="{{ asset('user/js/main.js') }}"></script>
<script src="{{ asset('toastr/toastr.min.js') }}"></script>
<script src="{{ asset('backend/iconpicker/fontawesome-iconpicker.min.js') }}"></script>

<script src="{{ asset('backend/ckeditor4/ckeditor.js') }}"></script>

<script>
    @if(Session::has('messege'))
      var type="{{Session::get('alert-type','info')}}"
      switch(type){
          case 'info':
               toastr.info("{{ Session::get('messege') }}");
               break;
          case 'success':
              toastr.success("{{ Session::get('messege') }}");
              break;
          case 'warning':
             toastr.warning("{{ Session::get('messege') }}");
              break;
          case 'error':
              toastr.error("{{ Session::get('messege') }}");
              break;
      }
    @endif
</script>

@if ($errors->any())
    @foreach ($errors->all() as $error)
        <script>
            toastr.error('{{ $error }}');
        </script>
    @endforeach
@endif



<script>
    (function($) {
    "use strict";
    $(document).ready(function () {

        CKEDITOR.replace('summernote');

        $('.custom-icon-picker').iconpicker({
            templates: {
                popover: '<div class="iconpicker-popover popover"><div class="arrow"></div>' +
                    '<div class="popover-title"></div><div class="popover-content"></div></div>',
                footer: '<div class="popover-footer"></div>',
                buttons: '<button class="iconpicker-btn iconpicker-btn-cancel btn btn-default btn-sm">Cancel</button>' +
                    ' <button class="iconpicker-btn iconpicker-btn-accept btn btn-primary btn-sm">Accept</button>',
                search: '<input type="search" class="form-control iconpicker-search" placeholder="Type to filter" />',
                iconpicker: '<div class="iconpicker"><div class="iconpicker-items"></div></div>',
                iconpickerItem: '<a role="button" href="javascript:;" class="iconpicker-item"><i></i></a>'
            }
        })
    });

    })(jQuery);
</script>


</body>

</html>
