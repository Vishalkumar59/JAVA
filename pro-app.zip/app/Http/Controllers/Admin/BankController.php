<?php

namespace App\Http\Controllers\Admin;

use App\CustomPage;
use App\NotificationText;
use App\ValidationText;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Image;
use App\Bank;
use App\BankDetail;
use App\ManageText;
use Str;
class BankController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:admin');
    }


    public function index()
    {
        $websiteLang = ManageText::all();
        $backDetails = Bank::all();
        $confirmNotify=$websiteLang->where('lang_key','are_you_sure')->first()->custom_text;
        return view('admin.bank-page.index',compact('websiteLang','backDetails','confirmNotify'));
    }


    public function bankshow($id){
        $user=Bank::find($id);
        if($user){
            $websiteLang=ManageText::all();
            return view('admin.bank-page.show',compact('user','websiteLang'));
        }

    }


    public function bankStatus($id){
        $page = Bank::find($id);
        if($page->status==1){
            $page->status=0;
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','inactive')->first()->custom_text;
            $message=$notification;
        }else{
            $page->status=1;
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','active')->first()->custom_text;
            $message=$notification;
        }
        $page->save();
        return response()->json($message);

    }
    

      public function destroy($id){
        
       
        $user= Bank::where('id',$id)->first();
        $user->delete();

        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','delete')->first()->custom_text;
        $notification=array('messege'=>$notification,'alert-type'=>'success');
        return back()->with($notification);

    }


    public function create(){

        $websiteLang=ManageText::all();
        return view('admin.bank-page.create',compact('websiteLang'));
    }

    public function store(Request $request)
    {
        // project demo mode check
        $rules = [
            'name'=>'required|unique:banks',
            'slug'=>'required',
            'status' => 'required',
        ];
        $this->validate($request, $rules);


        $page=new Bank();
        $page->name=$request->name;
        $page->slug=Str::slug($request->name);
        $page->status=$request->status;


        if($request->file('logo_url')){
            $logo_url=$request->logo_url;
            $logo_ext=$logo_url->getClientOriginalExtension();
            $logo_name= 'listing-banner-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$logo_ext;
            $logo_path='uploads/custom-images/'.$logo_name;
            Image::make($logo_url)
                ->save(public_path().'/'.$logo_path);
                $page->logo_url=$logo_path;

        }

        $page->save();

        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','create')->first()->custom_text;
        $notification=array('messege'=>$notification,'alert-type'=>'success');
        return redirect()->route('admin.bank')->with($notification);
    }

    public function bankdetails(Request $request)
    {
        $websiteLang = ManageText::all();
        $backDetails = BankDetail::first();
        $confirmNotify=$websiteLang->where('lang_key','are_you_sure')->first()->custom_text;
        return view('admin.bank-details.index',compact('websiteLang','backDetails','confirmNotify'));
    }

    public function bankUpdate(Request $request , $id)
    { 
        $bankDetails = BankDetail::find($id);
        $bankDetails->acount_number = $request->acount_number;
        $bankDetails->bank = $request->bank;
        $bankDetails->Branch = $request->Branch;
        $bankDetails->ifsc = $request->ifsc;
        $bankDetails->save();
        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','update')->first()->custom_text;
        $notification=array('messege'=>$notification,'alert-type'=>'success');
        return redirect()->route('admin.bank-details')->with($notification);



    }

}
