@extends('layouts.agents.profile.layout')

@section('title')

    <title>{{ $websiteLang->where('lang_key','import')->first()->custom_text }}</title>

@endsection
@section('agent-dashboard')
 <div class="col-xl-9 ms-auto">
  <div class="wsus__dashboard_main_content">
  
  <div class="row">
        <div class="col-md-6">
          <h4 class="heading">{{ $websiteLang->where('lang_key','bulk_import')->first()->custom_text }} </h4>
        </div>
        <div class="wsus__dash_info  p_25 mt_25">
          <form action="{{route('agents.import')}}"  method="POST" enctype="multipart/form-data" >
            @csrf
             <div class="row">
                  <div class="col-xl-6 col-md-6">
                   <label for="file">{{ $websiteLang->where('lang_key', 'select_csv_file')->first()->custom_text }} <span class="text-danger">*</span></label>
                    <input type="file"  name="file"/>
                    <input type="submit" class="btn btn-danger mb-3"/>
                    <label for="file">{{ $websiteLang->where('lang_key', 'for_sample')->first()->custom_text }}</label>

                    <a href="{{route('agents.donwload-file')}}">Download Now</a>
                  </div>

                  {{-- <a href="{{route('agents.donwload-file')}}">Download</a> --}}

 
              </div>
          </form>
          
        </div>
        
  </div>
</div>
</div>

@endsection

