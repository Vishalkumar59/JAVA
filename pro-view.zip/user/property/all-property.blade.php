@extends('layouts.user.layout')
@section('title')
    <title>{{ $seo_text->title }}</title>
@endsection
@section('meta')
    <meta name="description" content="{{ $seo_text->meta_description }}">
@endsection
@section('user-content')
    <style>
        body {
            margin: 0;
            padding: 0;
            box-sizing: border-box;

            font-family: 'Poppins', sans-serif;

        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            font-family: 'Jost', sans-serif;
        }

        tbody,
        td,
        tfoot,
        th,
        thead,
        tr {
            border-color: #ced4da;
            border: 1px solid #ced4da;
            vertical-align: middle;
        }

        th {
            border-bottom: none;
        }

        a {
            cursor: pointer;
        }

        .th-lg a {
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            color: #000;

        }

        .table>:not(:first-child) {
            border-top: 1px solid !important;
        }
        
        .property-section .form-control {
            width: 105px !important;
            border-radius: 0;
            height: 30px;
        }
        .property-section .modal-form-control .form-control {
            width: 100% !important;
        }
        .form-select {
            width: 128px;
            border-radius: 0;
        }

        .heading_wrapper {
            padding: 0 1rem 1rem;
            border: 1px solid #ced4da;
        }

        .heading_wrapper .row {
            padding: 1.4rem 0 1rem;
        }

        .table_heading {
            margin-top: 6rem;
        }

        .table_heading h4 {
            background-color: #0A547A;
            color: #fff;
            padding: 1rem 1rem;
            font-size: 18px;
            margin-bottom: 0;
        }


        .page-item.active .page-link {
            background: #f02c2d;
            border-color: #f02c2d
        }

        .table-border td,
        .table-border,
        .table-border tr,
        .table-border tbody {
            border: 0 !important
        }

        .table-border td {
            background-color: #fff !important;
        }

        table img {
            width: 50px;
            height: 50px
        }
        

        .pagination a {
            color: #000
        }

        .property_table span {
            font-size: 16px;
            font-weight: 600;
        }

        .property_search {
            width: 7px
        }

       .prop{
        width: 481px;
        display: flex;
        align-items: center
       }
       .prop-wrapper{
        display:flex;
       }
        @media (max-width:768px) {
            .heading_wrapper div {
                width: 100%
            }

            .prop-wrapper{
                flex-direction: column;
                gap:11px;
                
            }
            .property_search {
                width: 100%
            }
        }

        @media (max-width:992px) {

            .property_search {
                width: 100%
            }
        }
    </style>
    <!--===BREADCRUMB PART START====-->
<section class="wsus__breadcrumb" style="background: url({{ url($banner_image->image) }});">
    <div class="wsus_bread_overlay">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h4>
                        {{ $menus->where('id',2)->first()->navbar }}
                    </h4>
                    <nav style="--bs-breadcrumb-divider: '-';" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('home') }}">{{ $menus->where('id',
                                    1)->first()->navbar }}</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">
                                {{ $menus->where('id', 2)->first()->navbar }}</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>
<!--===BREADCRUMB PART END====-->
    <section class="wsus__property_page  mb_45">
        <div class="container">
            

            <div class="table_heading">
                <!-- Tabs navs -->
            <ul class="nav nav-tabs mb-3" id="ex1" role="tablist">
                <li class="nav-item" role="presentation">
                <a
                    class="nav-link active"
                    id="ex1-tab-1"
                    data-mdb-toggle="tab"
                    href="#all-properties"
                    role="tab"
                    aria-controls="ex1-tabs-1"
                    aria-selected="true"
                    >AUCTION PROPERTIES</a
                >
                </li>
                <li class="nav-item" role="presentation">
                <a
                    class="nav-link"
                    id="ex1-tab-2"
                    data-mdb-toggle="tab"
                    href="#all-vehicles"
                    role="tab"
                    aria-controls="ex1-tabs-2"
                    aria-selected="false"
                    >NON AUCTION PROPERTIES</a
                >
                </li>
            </ul>
            <!-- Tabs navs -->
            
            <!-- Tabs content -->
            <div class="tab-content" id="ex1-content">
                <div
                class="tab-pane fade show active"
                id="all-properties"
                role="tabpanel"
                aria-labelledby="all-properties"
                >
                <h4>ALL PROPERTIES</h4>
                    <div class="heading_wrapper">
                       
                        <div class="row  d-flex align-items-center property-section modal-form">
                            <div class="my-2" style="width: 138px;"><span>Reserve Price :</span></div>
                            <div class="my-2" style="width: 160px;">
                                <div class="d-flex gap-1">
                                    <span>From</span> <input type="number" id="pricefrom" name="pricefrom" class="form-control" min="1">
                                </div>
                            </div>
                            <div class="my-2" style="width: 140px;">
                                <div class="d-flex gap-1">
                                    <span>To</span> <input type="number" id="priceto" name="priceto" class="form-control" min="1">
                                </div>
                            </div>

                            <div style="width: 187px;" class="my-2">
                                <div class="gap-2" style=" display: -webkit-inline-box;"><span>City :</span>
                                    <select class="form-select form-select-sm" id="filterByCity" name="filterByCity" aria-label=".form-select-sm example">
                                        <option value="0">Select</option>
                                        @foreach ($citylist as $city)
                                            <option value="{{ $city->id }}">{{ $city->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="prop">
                                <div class=" prop-wrapper my-2">
                                    <div class="gap-2 align-items-center" style=" display: -webkit-inline-box;"><span>Type of Property :</span>
                                        <select class="form-select form-select-sm" aria-label=".form-select-sm example" id="proptype" name="proptype">
                                            <option value="0">Select</option>
                                            @foreach ($property_type_list as $property_type)
                                                <option value="{{ $property_type->id }}">{{ $property_type->type }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                <div class="d-flex gap-2 property_search ps-2"><span>Search</span>
                                    <input type="text" class="form-control" id="property_search">
                                </div> 
                                </div>
                            </div>

                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th width="5%">Property ID</th>
                                                <th width="10%"></th>
                                                <th width="10%">Bank Name</th>
                                                <th width="25%">Property Descriptions</th>
                                                <th width="10%">City</th>
                                                <th width="10%">Auction Date</th>
                                                <th width="15%">Price </th>
                                                <th width="10%">EMD</th>
                                            </tr>
                                        </thead>
                                        <tbody id="search_table">

                                            @foreach ($properties as $index => $item)

                                                <tr>
                                                    
                                                    <td>{{$item->property_unique_id }}</td>
                                                    <td> 
                                                        @if (!empty($item->bank->logo_url))
                                                        <img src=" {{ asset($item->bank->logo_url) }} " style="max-width:70px !important;" />
                                                        @endif
                                                    </td>
                                                    <td>
                                                        @if (!empty($item->bank))
                                                            {{ $item->bank->name }}
                                                        @endif
                                                    </td>
                                                    <td>
                                                        @if (!empty($item->title))
                                                            {{ $item->title }}
                                                        @endif

                                                        <br>
                                                        
                                                        @guest
                                                        <a href="{{ route('login') }}" id="userenquiry">I am intrested</a>
                                                        @endguest
                                                        @if(Auth::check() && auth()->user()->user_type == "1")
                                                        @php
                                                            $data = $kyclist->where('property_id' , $item->id)->where('user_id' , auth()->user()->id)->first();
                                                        @endphp
                                                        @if(!empty($data))
                                                            <a href="javascript:;" >Already Partycipate</a>
                                                        @else
                                                            <a href="javascript:;" data-index="{{$item->id}}" class="userenquiry">I am intrested</a>
                                                        @endif
                                                        @endif
                                                        
                                                    </td>
                                                    <td>
                                                        @if (!empty($item->city))
                                                            {{ $item->city->name }}
                                                        @endif
                                                    </td>
                                                    <td>{{$item->auction}}</td>
                                                    <td>₹
                                                        @if (!empty($item->price))
                                                            {{ $item->price }}
                                                        @endif
                                                    </td>

                                                    <td>₹
                                                        @if (!empty($item->emd_amount))
                                                            {{ $item->emd_amount }}
                                                        @endif
                                                    </td>
                                                    
                                                </tr>

                                                
                                            @endforeach
                                        
                                            
                                        </tbody>                                    
                                    </table>
                                    <div class="col-12">
                                        {{ $properties->links('user.paginator') }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="all-vehicles" role="tabpanel" aria-labelledby="ex1-tab-2">
                    <h4>NON AUCTION PROPERTIES</h4>
                    <div class="heading_wrapper">
                       
                        <div class="row  d-flex align-items-center property-section modal-form">
                            <div class="my-2" style="width: 138px;"><span>Reserve Price :</span></div>
                            <div class="my-2" style="width: 160px;">
                                <div class="d-flex gap-1">
                                    <span>From</span> <input type="number" id="price-from" name="pricefrom" class="form-control" min="1">
                                </div>
                            </div>
                            <div class="my-2" style="width: 140px;">
                                <div class="d-flex gap-1">
                                    <span>To</span> <input type="number" id="price-to" name="priceto" class="form-control" min="1">
                                </div>
                            </div>

                            <div style="width: 187px;" class="my-2">
                                <div class="gap-2" style=" display: -webkit-inline-box;"><span>City :</span>
                                    <select class="form-select form-select-sm" id="filter-City" name="filterByCity" aria-label=".form-select-sm example">
                                        <option value="0">Select</option>
                                        @foreach ($citylist as $city)
                                            <option value="{{ $city->id }}">{{ $city->name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="prop">
                                <div class=" prop-wrapper my-2">
                                    <div class="gap-2 align-items-center" style=" display: -webkit-inline-box;"><span>Type of Property :</span>
                                        <select class="form-select form-select-sm" aria-label=".form-select-sm example" id="property-type" name="proptype">
                                            <option value="0">Select</option>
                                            @foreach ($property_type_list as $property_type)
                                                <option value="{{ $property_type->id }}">{{ $property_type->type }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                <div class="d-flex gap-2 property_search ps-2"><span>Search</span>
                                    <input type="text" class="form-control" id="property-search">
                                </div> 
                                </div>
                            </div>

                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table table-bordered" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th width="5%">Property ID</th>
                                                <th width="10%"></th>
                                               
                                                <th width="25%">Property Descriptions</th>
                                                <th width="10%">City</th>
                                                <th width="10%">Auction Date</th>
                                                <th width="15%">Price </th>
                                                <th width="10%">EMD</th>
                                            </tr>
                                        </thead>
                                        <tbody id="search-auction-table">

                                            @foreach ($own_properties as $index => $item)

                                                <tr>
                                                    
                                                    <td>{{$item->property_unique_id }}</td>
                                                    <td> 
                                                        @if (!empty($item->thumbnail_image))
                                                        <img src=" {{ asset($item->thumbnail_image) }} " style="max-width:70px !important;" />
                                                        @endif
                                                    </td>

                                                    <td>
                                                        @if (!empty($item->title))
                                                            {{ $item->title }}
                                                        @endif

                                                        <br>
                                                        
                                                        @guest
                                                        <a href="{{ route('login') }}" id="userenquiry">I am intrested</a>
                                                        @endguest
                                                        @if(Auth::check() && auth()->user()->user_type == "1")
                                                        @php
                                                            $data = $kyclist->where('property_id' , $item->id)->where('user_id' , auth()->user()->id)->first();
                                                        @endphp
                                                        @if(!empty($data))
                                                            <a href="javascript:;" >Already Partycipate</a>
                                                        @else
                                                            <a href="javascript:;" data-index="{{$item->id}}" class="userenquiry">I am intrested</a>
                                                        @endif
                                                        @endif
                                                        
                                                    </td>
                                                    <td>
                                                        @if (!empty($item->city))
                                                            {{ $item->city->name }}
                                                        @endif
                                                    </td>
                                                    <td>{{$item->auction}}</td>
                                                    <td>₹
                                                        @if (!empty($item->price))
                                                            {{ $item->price }}
                                                        @endif
                                                    </td>

                                                    <td>₹
                                                        @if (!empty($item->emd_amount))
                                                            {{ $item->emd_amount }}
                                                        @endif
                                                    </td>
                                                    
                                                </tr>

                                               
                                            @endforeach
                                        
                                            
                                        </tbody>                                    
                                    </table>
                                    <div class="col-12">
                                        {{ $properties->links('user.paginator') }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           
        </div>
              
            <!--Table-->
        </div>

       
        <!-- Modal Start -->
        <div class="modal fade" id="newLocation" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Property Enquiry
                            </h5>
                            <button id="modalclose" type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body" >
                            <div class="container-fluid" id="user-key-details">
                                
                            </div>  
                        </div>
                    </div>
                </div>
            </div>

        <!-- End Modal -->


       

    </section>



    <script type="text/javascript">

        $(document).ready(function() {
            $('#proptype').on('change', function(e,data) {
                table_search();
            });
            $('#pricefrom,#priceto').on('keyup', function(e,data) {
                table_search();
            });

            $('#property_search').on('keyup', function(e,data) {
                table_search();
            });

           

            $('#filterByCity').on('keyup change', function(e,data) {
                table_search();
            });
 
        
            function table_search() {
               
            var filterByCity = $('#filterByCity').val();
            var pricefrom = $('#pricefrom').val();
            var priceto = $('#priceto').val();
            var proptype = $('#proptype').val();
            var property_search = $('#property_search').val();

            var data = {
                'filterByCity': filterByCity,
                'pricefrom':pricefrom,
                'priceto':priceto,
                'proptype':proptype,
                'property_search' : property_search,
            };

            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: "POST",
                url: "{{ route('property-table') }}",
                data: data,
                dataType: 'json',
                success: function(data) {
                    console.log(data); 
                    var html =   ``;
                    $.each(data.filterByCity, function(key, value) {
                        
                         html+= `<tr>
                                    <td>${ value.property_unique_id}</td>
                                    <td>`;
                                    if(value.bank != null){
                                    html += `<img src="${(value.bank)? value.bank.logo_url : ""}" style="max-width:70px !important;" />`;
                                    }
                                    html+=`
                                    </td>
                                    
                                    <td>${(value.bank)? value.bank.name : ""}</td>
                                    <td>${ value.title}<br> @guest
                                        <a href="{{ route('login') }}" class="userenquiry">I am intrested</a>
                                    @endguest
                                    @if(Auth::check() && auth()->user()->user_type == "1")
                                    <a href="javascript:;" data-index="${ value.id}" class="userenquiry">I am intrested</a>

                                    </td>
                                    @endif
                                    </td>
                                    <td>${(value.city)?value.city.name : ""}</td>
                                    <td>${value.auction}</td>
                                    <td>₹${ value.price}</td>
                                    <td>₹${ value.emd_amount}</td>
                                </tr>`;
                                
                            });

                    $("#search_table").html(html);
                }
            });
        }
    });
    </script> 

    <script type="text/javascript">

        $(document).ready(function() {
            $('#property-type').on('change', function(e,data) {
                table_non_auction_search();
            });
            $('#price-from,#price-to').on('keyup', function(e,data) {
                table_non_auction_search();
            });

            $('#property-search').on('keyup', function(e,data) {
                table_non_auction_search();
            });

            $('#filter-City').on('keyup change', function(e,data) {
                table_non_auction_search();
            });

        
            function table_non_auction_search() {
            
            var filterByCity = $('#filter-City').val();
            var pricefrom = $('#price-from').val();
            var priceto = $('#price-to').val();
            var proptype = $('#property-type').val();
            var property_search = $('#property-search').val();

            var data = {
                'filterByCity': filterByCity,
                'pricefrom':pricefrom,
                'priceto':priceto,
                'proptype':proptype,
                'property_search' : property_search,
            };

            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                type: "POST",
                url: "{{ route('property-non-auction-search') }}",
                data: data,
                dataType: 'json',
                success: function(data) {
                    console.log(data); 
                    var html =   ``;
                    $.each(data.filterByCity, function(key, value) {
                        
                        html+= `<tr>
                                    <td>${ value.property_unique_id}</td>
                                    <td>`;
                                    if(value.bank != null){
                                    html += `<img src="${(value.bank)? value.thumbnail_image : ""}" style="max-width:70px !important;" />`;
                                    }
                                    html+=`
                                    </td>
                                    
                                    
                                    <td>${ value.title}<br> @guest
                                        <a href="{{ route('login') }}" class="userenquiry">I am intrested</a>
                                    @endguest
                                    @if(Auth::check() && auth()->user()->user_type == "1")
                    
                                    <a href="javascript:;" data-index="${ value.id}" class="userenquiry">I am intrested</a>
                                
                                    </td>
                                    @endif</td>
                                    <td>${(value.city)?value.city.name : ""}</td>
                                    <td>${value.auction}</td>
                                    <td>₹${ value.price}</td>
                                    <td>₹${ value.emd_amount}</td>
                                </tr>`;
                                
                            });

                    $("#search-auction-table").html(html);
                }
            });
        }
    });
    </script>

  
    <script>
        $(document).on('click', '.userenquiry',function(e) {
                e.preventDefault();
                var data = $(this).data('index');
                    
                // alert(data);
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    type:'POST',
                    url: "{{route('user.ajax-enquiry')}}",
                    data:{data:data},
                    success:function(response){
                    //console.log(response);
                        var  html = `
                        <div class="row">
                        <form action="{{ route('user.user-enquiry') }}" method="post" enctype="multipart/form-data" class="needs-validation" id="form_validation">
                            @csrf
                                <div class="form-group has-validation">
                                    <input type="text" class="form-control" name="name" id="name" value="{{ old('name') }}" placeholder="{{ $websiteLang->where('lang_key', 'enter_your_name')->first()->custom_text }}" required>
                                </div>

                                <input type="hidden" value="${response.userenquiry.id}" name="property_id"/>
                                <input type="hidden" value="${response.userenquiry.user_id}" name="agents_id"/>
                                <div class="form-group has-validation mt-4">
                                    <input type="email" class="form-control" name="email" id="email" value="{{ old('email') }}" placeholder="{{ $websiteLang->where('lang_key', 'enter_your_email')->first()->custom_text }}" required>
                                </div>

                                <div class="form-group has-validation mt-4">
                                    <textarea class="form-control" name="message" id="message" value="{{ old('message') }}" placeholder="{{ $websiteLang->where('lang_key', 'enter_your_message')->first()->custom_text }}"></textarea>
                                </div>                           

                                <div class="modal-footer">
                                    <button type="button"  id="modalclose" class=" btn-danger" data-bs-dismiss="modal">{{ $websiteLang->where('lang_key', 'close')->first()->custom_text }}</button>
                                    <button type="submit" class="btn-primary">Send</button>
                                </div>
                        </form>
                        </div>`; 
                        
                        $("#user-key-details").html(html);
                        $("#newLocation").modal('show');
                    }
                    
                });
                
            });
    
    </script>

    <script>
        $('#modalclose').on('click',function(){
        $('#newLocation').modal('hide');
        });
    </script>

    <script>
        $(document).ready( function () {
            $('#dataTablelist').DataTable();
        } ); 
    </script>
      <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
    <!-- MDB -->
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.0.1/mdb.min.js"
></script>
@endsection
