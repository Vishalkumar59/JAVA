@extends('layouts.admin.layout')
@section('title')
<title>{{ $websiteLang->where('lang_key','bank')->first()->custom_text }}</title>
@endsection
@section('admin-content')

    <!-- Page Heading -->
   

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
       
       <div class="row">
        <div class="col-md-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        {{ $websiteLang->where('lang_key', 'bank')->first()->custom_text }}</h6>
                </div>
                <div class="card-body">

                    <form action="{{ route('admin.bank-details-update',$backDetails->id) }}" method="POST">
                        @csrf
                         <div class="row">
                            <div class="col-md-6">
                                <div class="form-group ">
                                    <label
                                        for="stripe_key">{{ $websiteLang->where('lang_key', 'acount_number')->first()->custom_text }}</label>
                                    <input type="text" name="acount_number" id="acount_number" class="form-control"
                                        value="{{ $backDetails->acount_number }}">
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group ">
                                    <label
                                        for="stripe_key">{{ $websiteLang->where('lang_key', 'bank_name')->first()->custom_text }}</label>
                                    <input type="text" name="bank" id="bank" class="form-control"
                                        value="{{ $backDetails->bank }}">
                                </div>

                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label
                                        for="stripe_key">{{ $websiteLang->where('lang_key', 'Branch_name')->first()->custom_text }}</label>
                                    <input type="text" name="Branch" id="Branch" class="form-control"
                                        value="{{ $backDetails->Branch }}">


                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label
                                        for="stripe_key">{{ $websiteLang->where('lang_key', 'ifsc_code')->first()->custom_text }}</label>
                                    <input type="text" name="ifsc" id="ifsc" class="form-control"
                                        value="{{ $backDetails->ifsc }}">
                                </div>
                            </div>
                        </div>

                      

                        <button type="submit"
                            class="btn btn-success">{{ $websiteLang->where('lang_key', 'update')->first()->custom_text }}</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
    </div>

    <script>
        function userStatus(id){
           

            // project demo mode check
         var isDemo="{{ env('PROJECT_MODE') }}"
         var demoNotify="{{ env('NOTIFY_TEXT') }}"
         if(isDemo==0){
             toastr.error(demoNotify);
             return;
         }
         // end

            $.ajax({
                type:"get",
                url:"{{url('/admin/bank-status/')}}"+"/"+id,
                success:function(response){
                   toastr.success(response)
                },
                error:function(err){
                    console.log(err);

                }
            })
        }
    </script>
@endsection
