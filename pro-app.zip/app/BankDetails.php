
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BankDetails extends Model
{
    protected $table = 'bank_details';
    protected $fillable=[
        'acount_number','bank','Branch','ifsc','status'
    ];



    
}
