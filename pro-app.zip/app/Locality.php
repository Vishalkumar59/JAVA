<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Locality extends Model
{
   protected $table = 'localities';

    protected $fillable=[
        'locality_name','city_id','locality_id'
    ];


    // public function countryState(){
    //     return $this->belongsTo(CountryState::class);
    // }

    // public function properties(){
    //     return $this->hasMany(Property::class);
    // }
}
