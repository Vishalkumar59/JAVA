<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Property extends Model
{


    protected $fillable=[
        'user_type','admin_id','user_id','property_type_id','city_id','listing_package_id','category_id','title','slug','views','address','phone','email','website','description','file','thumbnail_image','banner_image','number_of_unit','number_of_room','number_of_bedroom','number_of_bathroom','number_of_floor','number_of_kitchen','number_of_parking','area','google_map_embed_code','price','market_price','period','video_link','is_featured','verifieda','top_property','urgent_property','status','seo_title','expired_date','pincode','bank_id','finance','locality','seo_description','auction','emd_amount','vehicle_name','vehicle_type','vehicle_price','vehicle_size','property_enquiry','id','property_unique_id'

    ];



    public function propertyType(){
        return $this->belongsTo(PropertyType::class);
    }

    public function propertyPurpose(){
        return $this->belongsTo(PropertyPurpose::class,'category_id','id');
    }

    public function propertyAminities(){
        return $this->hasMany(PropertyAminity::class);
    }
    

    public function propertyImages(){
        return $this->hasMany(PropertyImage::class);
    }

    public function propertyNearestLocations(){
        return $this->hasMany(PropertyNearestLocation::class);
    }

    public function city(){
        return $this->belongsTo(City::class);
    }
    public function admin(){
        return $this->belongsTo(Admin::class);
    }
    public function user(){
        return $this->belongsTo(User::class);
    }

    public function reviews(){
        return $this->hasMany(PropertyReview::class);
    }


    public function bank(){
        return $this->belongsTo(Bank::class);
    }

    public function kycdocument(){
        return $this->hasMany(KycDocument::class, 'id' , 'property_id');
    }

     public function LocalityName()
    {
        return $this->belongsTo(Locality::class,'locality','locality_id');
    }



}
