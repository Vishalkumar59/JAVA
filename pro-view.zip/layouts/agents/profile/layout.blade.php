@include('layouts.agents.profile.header')

@yield('agent-dashboard')
@include('layouts.agents.profile.footer')

