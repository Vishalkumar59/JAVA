<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaytmDetails extends Model
{
    protected $table = 'paytm_details';
    protected $fillable=[
        'merchant_id','merchant_key','website','channel','industry_type'
    ];
}
