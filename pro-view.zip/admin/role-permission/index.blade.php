@extends('layouts.admin.layout')
@section('title')
<title>{{ $websiteLang->where('lang_key','role_list')->first()->custom_text }}</title>
@endsection
@section('admin-content')


<h1 class="h3 mb-2 text-gray-800"><a href="{{route('admin.role-Permission.create')}}" class="btn btn-primary"><i class="fas fa-plus" aria-hidden="true"></i> {{ $websiteLang->where('lang_key','create')->first()->custom_text }} </a></h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">{{ $websiteLang->where('lang_key','role_list')->first()->custom_text }}</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th width="5%">{{ $websiteLang->where('lang_key','serial')->first()->custom_text }}</th>
                            <th width="20%">{{ $websiteLang->where('lang_key','role_name')->first()->custom_text }}</th>
                            
                            <th width="10%">{{ $websiteLang->where('lang_key','status')->first()->custom_text }}</th>
                            <th width="15%">{{ $websiteLang->where('lang_key','action')->first()->custom_text }}</th>
                        </tr>
                    </thead>
                    <tbody>
                         @foreach ($rolelist as $index => $item)
                        
                        <tr>
                            <td>{{ ++$index }}</td>
                            <td>{{$item->roles_name}}</td>

                            <td class="text-center p-3" style="size:10px;"> 
                               
                                @if ($item->status==1)
                                <a href="" onclick="roleStatus({{ $item->roles_id }})"><input type="checkbox" checked data-toggle="toggle" data-on="{{ $websiteLang->where('lang_key','active')->first()->custom_text }}" data-off="{{ $websiteLang->where('lang_key','inactive')->first()->custom_text }}" data-onstyle="success" data-offstyle="danger"></a>
                                @else
                                    <a href="" onclick="roleStatus({{ $item->roles_id }})"><input type="checkbox" data-toggle="toggle" data-on="{{ $websiteLang->where('lang_key','active')->first()->custom_text }}" data-off="{{ $websiteLang->where('lang_key','inactive')->first()->custom_text }}" data-onstyle="success" data-offstyle="danger"></a>

                                @endif
                            </td>
                            <td>
                                <a href="{{ route('admin.role-Permission.edit',$item->roles_id) }}" class="btn btn-primary btn-sm"><i class="fas fa-edit    "></i></a>
                                
                                <a href="{{ route('admin.role.delete',$item->roles_id) }}" onclick="return confirm('{{ $confirmNotify }}')"class="btn btn-danger btn-sm"><i class="fas fa-trash    "></i></a>
                               
                            </td>

                        </tr>
                        @endforeach 
                       

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function roleStatus(id){
           

            // project demo mode check
         var isDemo="{{ env('PROJECT_MODE') }}"
         var demoNotify="{{ env('NOTIFY_TEXT') }}"
         if(isDemo==0){
             toastr.error(demoNotify);
             return;
         }
         // end

            $.ajax({
                type:"get",
                url:"{{url('/admin/role-status/')}}"+"/"+id,
                success:function(response){
                   toastr.success(response)
                },
                error:function(err){
                    console.log(err);

                }
            })
        }
    </script>
@endsection
