<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    protected $fillable=[

        'kyc_id','user_id','payment_method','transaction_id','transaction_details','amount','status','user_type'

    ];

    // public function property()
    // {
    //     return $this->belongsTo(Property::class, 'property_id', 'id');
    // }


    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function kycdocument()
    {
        return $this->belongsTo(KycDocument::class, 'kyc_id', 'id');
    }
    
 
}
