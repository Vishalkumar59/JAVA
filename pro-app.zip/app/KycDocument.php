<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KycDocument extends Model
{
    protected $table = 'user_kyc_details';

    protected $fillable=[
        'user_id','property_id','name','aadhaar_no','pan_no','bank_account_no','ifsc_code','payment_status','id'
    ];

    public function property()
    {
        return $this->belongsTo(Property::class, 'property_id', 'id');
    }
    public function property1()
    {
        return $this->belongsTo(Property::class, 'property_id', 'id');
    }
    

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function transaction()
    {
    return $this->hasOne(Transaction::class, 'kyc_id', 'id');
    }
    public function alltransaction()
    {
        return $this->hasMany(Transaction::class, 'kyc_id', 'id');
    }
}