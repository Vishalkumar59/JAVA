@extends('layouts.admin.layout')
@section('title')
<title>{{ $websiteLang->where('lang_key','total_kyc')->first()->custom_text }}</title>
@endsection
@section('admin-content')
    <!-- DataTales Example -->
<!-- Tabs navs -->
<ul class="nav nav-tabs mb-3" id="ex-with-icons" role="tablist">
    <li class="nav-item" role="presentation">
      <a class="nav-link active" id="ex-with-icons-tab-1" data-mdb-toggle="tab" href="#ex-with-icons-tabs-1" role="tab"
        aria-controls="ex-with-icons-tabs-1" aria-selected="true"><i class=" fa-fw me-2"></i>{{$websiteLang->where('lang_key','auction_enq')->first()->custom_text }}</a>
    </li>
    <li class="nav-item" role="presentation">
      <a class="nav-link" id="ex-with-icons-tab-2" data-mdb-toggle="tab" href="#ex-with-icons-tabs-2" role="tab"
        aria-controls="ex-with-icons-tabs-2" aria-selected="false"><i class="fa-fw me-2"></i>{{$websiteLang->where('lang_key','own_enq')->first()->custom_text }}</a>
    </li>
</ul>
  <!-- Tabs navs -->
  
  <!-- Tabs content -->
  <div class="tab-content" id="ex-with-icons-content">
    <div class="tab-pane fade show active" id="ex-with-icons-tabs-1" role="tabpanel" aria-labelledby="ex-with-icons-tab-1">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">{{ $websiteLang->where('lang_key','auction_enquiry_list')->first()->custom_text }}</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="5%">{{ $websiteLang->where('lang_key','serial')->first()->custom_text }}</th>
                                <th width="20%">{{ $websiteLang->where('lang_key','customer_name')->first()->custom_text }}</th>
                                <th width="20%">{{ $websiteLang->where('lang_key','property_name')->first()->custom_text }}</th>
                                <th width="20%">{{ $websiteLang->where('lang_key','agent_name')->first()->custom_text }}</th>
                                <th width="20%">{{ $websiteLang->where('lang_key','date')->first()->custom_text }}</th>
                                <th width="10%">{{ $websiteLang->where('lang_key','payment_status')->first()->custom_text }}</th>
                                <th width="15%">{{ $websiteLang->where('lang_key','action')->first()->custom_text }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($customer_kyc as $index => $item)
                           {{-- @dd($item->property->user->name); --}}
                            <tr>
                                <td>{{ ++$index }}</td>
                                <td>@if(!empty($item->user)){{$item->user->name}}@endif</td>
                                <td> @if(!empty($item->property)){{$item->property->title}}@endif</td>
                                <td>@if(!empty($item->property->user)){{$item->property->user->name}}@endif</td>
                                <td>{{$item->created_at->format('Y-m-d')}}</td>
                                <td class="status" style="size:10px;"> 
                                    @if($item->payment_status==1)
                                    <i class="badge bg-success text-light p-2">{{ $websiteLang->where('lang_key','paid')->first()->custom_text }}</i>
                                    @else
                                    <i class="badge bg-danger  text-light p-2">{{ $websiteLang->where('lang_key','unpaid')->first()->custom_text }}</i>
                                    @endif
                                    {{-- <td class="status">
                                        <p class="active">Active</p>
                                    </td> --}}
                                    {{-- @if ($item->payment_status==1)
                                    <a href="" onclick="userStatus({{ $item->id}})"><input type="checkbox" checked data-toggle="toggle" data-on="{{ $websiteLang->where('lang_key','paid')->first()->custom_text }}" data-off="{{ $websiteLang->where('lang_key','pending')->first()->custom_text }}" data-onstyle="success" data-offstyle="danger"></a>
                                    @else
                                        <a href="" onclick="userStatus({{ $item->id }})"><input type="checkbox" data-toggle="toggle" data-on="{{ $websiteLang->where('lang_key','paid')->first()->custom_text }}" data-off="{{ $websiteLang->where('lang_key','pending')->first()->custom_text }}" data-onstyle="success" data-offstyle="danger"></a>
    
                                    @endif --}}
                                </td>
                                <td class="d-flex">
                                    <a href="{{ route('admin.kyc.customer.show',$item->id) }}" class="btn-success btn-sm"><i class="fas fa-eye"></i></a>
                                    <a href="{{ route('admin.customer.delete',$item->id) }}" onclick="return confirm('{{ $confirmNotify }}')" class="btn-danger btn-sm"><i class="fas fa-trash    "></i></a>
                                   
                                </td>
    
                            </tr>
                            @endforeach
                           
    
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="tab-pane fade" id="ex-with-icons-tabs-2" role="tabpanel" aria-labelledby="ex-with-icons-tab-2">
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">{{ $websiteLang->where('lang_key','own_equiry_list')->first()->custom_text }}</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="5%">{{ $websiteLang->where('lang_key','serial')->first()->custom_text }}</th>
                                <th width="20%">{{ $websiteLang->where('lang_key','customer_name')->first()->custom_text }}</th>
                                <th width="20%">{{ $websiteLang->where('lang_key','email')->first()->custom_text }}</th>
                                <th width="20%">{{ $websiteLang->where('lang_key','property_name')->first()->custom_text }}</th>
                                <th width="20%">{{ $websiteLang->where('lang_key','agent_name')->first()->custom_text }}</th>
                                <th width="20%">{{ $websiteLang->where('lang_key','date')->first()->custom_text }}</th>
                                <th width="15%">{{ $websiteLang->where('lang_key','action')->first()->custom_text }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($userenquiry as $index => $item)
                            <tr>
                                <td>{{ ++$index }}</td>
                                <td>{{ $item->user->name ?? "null"}}</td>
                                <td>{{$item->user->email ?? "null"}}</td>
                                <td> {{$item->property->title ?? "null" }}</td>
                                <td>{{ $item->property->user->name ?? "null"}}</td>
                                <td>{{$item->created_at->format('Y-m-d')}}</td>
                                <td class="d-flex">
                                    <a href="{{ route('admin.customer.enquiry.show',$item->id) }}" class=" btn-success btn-sm mx-2"><i class="fas fa-eye"></i></a>
                                    <a href="{{ route('admin.customer.enquiry.delete',$item->id) }}" onclick="return confirm('{{ $confirmNotify }}')" class=" btn-danger btn-sm"><i class="fas fa-trash    "></i></a>
                                   
                                </td>
    
                            </tr>
                            @endforeach
                           
    
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

  </div>
  <!-- Tabs content -->

    <script>
        function userStatus(id){
           

            // project demo mode check
         var isDemo="{{ env('PROJECT_MODE') }}"
         var demoNotify="{{ env('NOTIFY_TEXT') }}"
         if(isDemo==0){
             toastr.error(demoNotify);
             return;
         }
         // end

            $.ajax({
                type:"get",
                url:"{{url('/admin/customer-status/')}}"+"/"+id,
                success:function(response){
                   toastr.success(response)
                },
                error:function(err){
                    console.log(err);

                }
            })
        }
    </script>
    <script
    type="text/javascript"
    src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/5.0.0/mdb.min.js"
  ></script>




@endsection
