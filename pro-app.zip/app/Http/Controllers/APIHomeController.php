<?php

namespace App\Http\Controllers;

use App\BannerImage;
use App\City;
use App\ManageText;
use App\Navigation;
use App\Property;
use App\PropertyType;
use App\SeoText;
use App\UserEnquiryDetails;
use Illuminate\Pagination\Paginator;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Auth;

class APIHomeController extends Controller
{
    
    public function allProperty(){
       
        Paginator::useBootstrap();
        // cheack page type, page type means grid view or listing view
        $seo_text=SeoText::find(2);
        $menus=Navigation::all();
        $properties = Property::where('category_id' , 1)->paginate(10);
        $citylist = City::where('status' , 1)->get();
        $property_type_list = PropertyType::where('status' , 1)->get();
        $banner_image=BannerImage::find(1);
        $websiteLang=ManageText::all();
        $kyclist = UserEnquiryDetails::all();

        return response()->json([ 'allProperty' => $properties ,'citylist'=>$citylist ,'seo_text'=>$seo_text ,'menus'=>$menus,'property_type_list'=>$property_type_list,'banner_image'=>$banner_image,'websiteLang'=>$websiteLang,'kyclist'=>$kyclist ]);
    }

    public function citysearch(Request $request){
            
        
       if($request->city){
            $value = City::where('name' , $request->city)->first();
        }else{
            $value = '';
        }

        if($value){
            $city=Property::with('bank','city')->where('city_id' , $value->id)->where('category_id' , 1)->get();
        }else{
            $city = "Not currect City name";
        }
        

        $data['city']=$city;
       



        return response()->json($data);

    }

    public function pricesearch(Request $request){
            
        $minprice = $request->pricefrom;
        $maxprice = $request->priceto;

        if($minprice != null && $maxprice != null){
            $filterprice = Property::with('bank','city')->whereBetween('price', [(int)$minprice, (int)$maxprice])->get();
        }

        if($minprice){
            $filterprice = Property::with('bank','city')->where('price', '>=',(int)$minprice)->get();
        }

        if($maxprice){
            $filterprice = Property::with('bank','city')->where('price', '<=', (int)$maxprice)->get();
        }

        $data['filterprice']=$filterprice;

        return response()->json($data);

    }

    public function inputsearch(Request $request){

        if($request->property_search){
            $filetrinput = Property::with('bank','city')->where('title', 'like', '%' . $request->property_search. '%')->orWhere('price', 'like', '%' . $request->property_search. '%')->orWhere('emd_amount', 'like', '%' . $request->property_search. '%')->orWhere('property_unique_id', 'like', '%' . $request->property_search. '%')->get();


        }else{
            $filetrinput = Property::with('bank','city')->get();
        }

       

        $data['filetrinput']=$filetrinput;

        return response()->json($data);
    }

    public function properties(Request $request){

        
        if($request->property_type){
            $proptype = PropertyType::where('type' , $request->property_type)->first();
        }
        
        if($proptype){
            $property_type = Property::with('bank','city')->where('property_type_id' , $proptype->id)->where('category_id' , 1)->get();
        }else{
            $property_type ="Not Correct Property Type Name";
        }


        
        $data['property_type']=$property_type;

        return response()->json($data);

    }

    public function allVehicles(Request $request){
        Paginator::useBootstrap();
        // cheack page type, page type means grid view or listing view
        
            
        
        $seo_text=SeoText::find(2);
        $menus=Navigation::all();
        $properties = Property::where('category_id' , 2)->paginate(10);
        $citylist = City::where('status' , 1)->get();
        $property_type_list = PropertyType::where('status' , 1)->get();
        $banner_image=BannerImage::find(1);
        $websiteLang=ManageText::all();
        $kyclist = UserEnquiryDetails::all();


        return response()->json([ 'seo_text' => $seo_text ,'properties'=>$properties ,'citylist'=>$citylist ,'property_type_list'=>$property_type_list,'menus'=>$menus,'banner_image'=>$banner_image,'websiteLang'=>$websiteLang,'kyclist'=>$kyclist ]);
    }

     
    public function vehiclescitysearch(Request $request){

        if($request->city){
            $value = City::where('name' , $request->city)->first();
        }else{
            $value = '';
        }

        if($value){
            $city=Property::with('bank','city')->where('city_id' , $value->id)->where('category_id' , 2)->get();
        }else{
            $city = "Not currect City name";
        }
        

        $data['city']=$city;
       



        return response()->json($data);

    }

    public function vehiclespropertysearch(Request $request){



        if($request->property_type){
            $proptype = PropertyType::where('type' , $request->property_type)->first();
        }
        
        if($proptype){
            $property_type = Property::with('bank','city')->where('property_type_id' , $proptype->id)->where('category_id' , 2)->get();
        }else{
            $property_type ="Not Correct Property Type Name";
        }


        
        $data['property_type']=$property_type;

        return response()->json($data);
    }
    
    public function vehiclespricesearch(Request $request){
        
        $minprice = $request->pricefrom;
        $maxprice = $request->priceto;

        if($minprice != null && $maxprice != null){
            $filterprice = Property::with('bank','city')->whereBetween('price', [(int)$minprice, (int)$maxprice])->where('category_id' , 2)->get();
        }

        if($minprice){
            $filterprice = Property::with('bank','city')->where('price', '>=',(int)$minprice)->where('category_id' , 2)->get();
        }

        if($maxprice){
            $filterprice = Property::with('bank','city')->where('price', '<=', (int)$maxprice)->where('category_id' , 2)->get();
        }
        

        $data['filterprice']=$filterprice;

        return response()->json($data);
    }

    public function vehiclesinputsearch(Request $request){

        if($request->property_search){
            $filetrinput = Property::with('bank','city')->where('title', 'like', '%' . $request->property_search. '%')->orWhere('price', 'like', '%' . $request->property_search. '%')->orWhere('emd_amount', 'like', '%' . $request->property_search. '%')->where('category_id' , 2)->get();

    
        }else{
            $filetrinput = Property::with('bank','city')->where('category_id' , 2)->get();
        }

       

        $data['filetrinput']=$filetrinput;

        return response()->json($data);
    }

}