<?php

namespace App\Import;

use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use App\Property;
use App\PropertyType;
use Auth;
use App\PropertyPurpose;
use App\Bank;
use App\City;
use Str;
use App\NotificationText;
use Illuminate\Support\Facades\Validator;

class PropertyImport implements ToModel, WithHeadingRow
{

    
   
    /** 
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {

        Validator::make($row, [

             'title' => 'required|unique:properties',

         ])->validate();


        $property_type = ($row['property_type']);
        if(!empty($property_type)){
            $Property = PropertyType::where('type' , $property_type)->first();
        }else{
            $Property =0;
        }

        $prop_cotegory = ( $row['property_category']);
        if(!empty($prop_cotegory)){
            $Property_category_id = PropertyPurpose::where('custom_purpose' , $prop_cotegory)->first();
        }else{
            $Property_category_id = 0;
        }

        $bank = ($row['bank']);
        if(!empty($bank)){
            $bank_id = Bank::where('name' , $bank)->first();
        }else{
            $bank_id = 0;
        }

        $price = ($row['price']);
        if(!empty($price)){
            $emd_price = $price*10/100;
        }else{
            $emd_price = 0;
        }

        $seo_title = ($row['title']);
        if(!empty($seo_title)){
            $slug = Str::slug($seo_title);
        }else{
            $slug ="a";
        }


        $cities = ($row['city']);
       
        if(!empty($prop_cities)){
            $prop_cities = City::where('name' , $cities)->first();
        }

        $property_unique_id = ($row['property_unique_id']);

        $randomString = Str::random(20); 
        
        if(!empty($property_unique_id)){
            $property_unique = ($row['property_unique_id']);
        }else{
            $property_unique =  $randomString;
        }

      
       
            return new Property([
                
                'user_type' => 0,
                'admin_id' => 0,
                'user_id' => Auth::user()->id,
                'property_unique_id' => $property_unique,
                'property_type_id' => $Property->id,
                'city_id' => $prop_cities->id ?? 1,
                'category_id' =>$Property_category_id->id,
                'title' => $row['title'],
                'slug' =>$slug,
                'address' => $row['address'],
                'phone' => $row['phone'],
                'email' => $row['email'],
                'website' => $row['website'],
                'file' => $row['file'],
                'thumbnail_image' => $row['thumbnail_image'],
                'banner_image' => $row['banner_image'],
                'number_of_unit' => $row['number_of_unit'],
                'number_of_room' => $row['number_of_room'],
                'number_of_bedroom' => $row['number_of_bedroom'],
                'number_of_bathroom' => $row['number_of_bathroom'],
                'number_of_floor' => $row['number_of_floor'],
                'number_of_kitchen' => $row['number_of_kitchen'],
                'number_of_parking' => $row['number_of_parking'],
                'area' => $row['area'],
                'google_map_embed_code' => $row['google_map_embed_code'],
                'price' => $row['price'],
                'video_link' => $row['video_link'],
                'is_featured' => $row['is_featured'],
                'verified' => $row['verified'],
                'top_property' => $row['top_property'],
                'urgent_property' => $row['urgent_property'],
                'status' =>1,
                'expired_date' => $row['expired_date'],
                'pincode' => $row['pincode'],
                'bank_id' => $bank_id->id,
                'finance' => (($row['finance']=='yes')?'1':0),
                'locality' => $row['locality'],
                'auction' => $row['auction'],
                'emd_amount' => $emd_price,
                'vehicle_name' => $row['vehicle_name'],
                'vehicle_type' => $row['vehicle_type'],
                'vehicle_price' => $row['vehicle_price'],
                'vehicle_size' => $row['vehicle_size'],
                'property_enquiry' =>$row['property_enquiry'],
            ]);
    }
}
