<?php

namespace App\Http\Controllers\Agents\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Auth;
use App\Admin;
use Hash;
use App\BannerImage;
use App\Rules\Captcha;
use App\User;
use App\NotificationText;
use App\Setting;
use App\Navigation;
use App\ValidationText;
use Laravel\Socialite\Facades\Socialite;
use App\ManageText;
class AgentLoginController extends Controller
{


    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::AGENTS;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {

        $this->middleware('guest:agents')->except('AgentsLogout');
    }


    public function AgentLoginForm(){
        $banner_image=BannerImage::find(11);
        $setting=Setting::first();
        $menus=Navigation::all();
        $allowLogin=$menus->where('id',12)->first();
        if($allowLogin->status!=1){
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
            $notification=array('messege'=>$notification,'alert-type'=>'error');
            return redirect()->route('home')->with($notification);
        }

        $websiteLang=ManageText::all();
        return view('agents.auth.login',compact('banner_image','setting','menus','websiteLang'));
    }

    public function storeLoginInfo(Request $request){

        $valid_lang=ValidationText::all();
        $rules = [
            'email'=>'required',
            'password'=>'required',
            'g-recaptcha-response'=>new Captcha()
        ];
        $customMessages = [
            'email.required' => $valid_lang->where('lang_key','email')->first()->custom_text,
            'password.required' => $valid_lang->where('lang_key','pass')->first()->custom_text,
        ];
        $this->validate($request, $rules, $customMessages);


        $credential=[
            'email'=> $request->email,
            'password'=> $request->password
        ];

        $user=User::where('email',$request->email)->first();
        if($user){
            if($user->status==1){
                if(Hash::check($request->password,$user->password)){
                    if($user->user_type == '2'){
                    if(Auth::guard('web')->attempt($credential,$request->remember)){
                        $notify_lang=NotificationText::all();
                        $notification=$notify_lang->where('lang_key','login')->first()->custom_text;

                        return response()->json(['success'=>$notification]);
                    }
                    }else{
                        $notify_lang=NotificationText::all();
                        $notification=$notify_lang->where('lang_key','invalid_login')->first()->custom_text;

                        return response()->json(['error'=>$notification]);
                    }
                }else{
                    $notify_lang=NotificationText::all();
                    $notification=$notify_lang->where('lang_key','invalid_login')->first()->custom_text;

                    return response()->json(['error'=>$notification]);
                }

            }else{
                $notify_lang=NotificationText::all();
                $notification=$notify_lang->where('lang_key','inactive_user')->first()->custom_text;

                return response()->json(['error'=>$notification]);
            }
        }else{
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','email_not_exist')->first()->custom_text;
            return response()->json(['error'=>$notification]);
        }


    }

    public function AgentsLogout(){
        Auth::guard('agents')->logout();
        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','logout')->first()->custom_text;
        $notification=array('messege'=>$notification,'alert-type'=>'success');
        return redirect()->route('agents.auth.login')->with($notification);
    }


}
