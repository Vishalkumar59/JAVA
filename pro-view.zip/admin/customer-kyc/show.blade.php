@extends('layouts.admin.layout')
@section('title')
<title>{{$customer_show->user->name}}</title>
@endsection
@section('admin-content')
{{-- @dd($customer_show->user); --}}
    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><a href="{{ route('admin.customer-kyc') }}" class="btn btn-success"> <i class="fas fa-backward" aria-hidden="true"></i> {{ $websiteLang->where('lang_key','go_back')->first()->custom_text }} </a></h1>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">{{ $websiteLang->where('lang_key','customer_information')->first()->custom_text }}</h6>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr>
                    <td>{{ $websiteLang->where('lang_key','customer_name')->first()->custom_text }}</td>
                    <td>{{ $customer_show->user->name}}</td>
                </tr>
                <tr>
                    <td>{{ $websiteLang->where('lang_key','email')->first()->custom_text }}</td>
                    <td>{{ $customer_show->user->email}}</td>
                </tr>
                <tr>
                    <td>{{ $websiteLang->where('lang_key','phone')->first()->custom_text }}</td>
                    <td>{{ $customer_show->user->phone }}</td>
                </tr>
                <tr>
                    <td>{{ $websiteLang->where('lang_key','image')->first()->custom_text }}</td>
                    <td> <img src="{{ $customer_show->user->image ? url($customer_show->user->image) : "" }}" width="80px">
                    </td>
                </tr>

            </table>
        </div>
    </div>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">{{ $websiteLang->where('lang_key','kyc_info')->first()->custom_text }}</h6>
        </div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr>
                    <td>{{ $websiteLang->where('lang_key','kyc_name')->first()->custom_text }}</td>
                    <td>{{ $customer_show->name}}</td>
                </tr>
                <tr>
                    <td>{{ $websiteLang->where('lang_key','aadhar_no')->first()->custom_text }}</td>
                    <td>{{ $customer_show->aadhaar_no }}</td>
                </tr>
                <tr>
                    <td>{{ $websiteLang->where('lang_key','pan_no')->first()->custom_text }}</td>
                    <td>{{ $customer_show->pan_no }}</td>
                </tr>
                <tr>
                    <td>{{ $websiteLang->where('lang_key','bank_account_no')->first()->custom_text }}</td>
                    <td>{{ $customer_show->bank_account_no }}</td>
                </tr>
                <tr>
                    <td>{{ $websiteLang->where('lang_key','ifsc_code')->first()->custom_text }}</td>
                    <td>{{ $customer_show->ifsc_code }}</td>
                </tr>
                
                <tr>
                    <td>{{ $websiteLang->where('lang_key','property')->first()->custom_text }}</td>
                    <td class="w-50">{{$customer_show->property->title}}</td>
                </tr>
                <tr>
                    <td>{{ $websiteLang->where('lang_key','agent_name')->first()->custom_text }}</td>
                   
                    <td> @if(!empty($customer_show->property->user)){{$customer_show->property->user->name}}@endif</td>
                </tr>
                <tr>
                    <td>{{ $websiteLang->where('lang_key','date')->first()->custom_text }}</td>
                    <td>{{$customer_show->created_at->format('Y-m-d')}}</td>
                </tr>
                 {{-- <tr>
                    <td>{{ $websiteLang->where('lang_key','payment_status')->first()->custom_text }}</td>
                    <td>
                        @if ($customer_show->payment_status==0)
                        <i class="badge bg-success text-light p-2">{{ $websiteLang->where('lang_key','paid')->first()->custom_text }}</i>
                          @else
                          <i class="badge bg-danger  text-light p-2">{{ $websiteLang->where('lang_key','unpaid')->first()->custom_text }}</i>
                          @endif
                    </td>
                </tr> --}}

            </table>
        </div>
    </div>
   
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">{{ $websiteLang->where('lang_key','transaction_infomation')->first()->custom_text }}</h6>
        </div>
        <div class="card-body">
            @if(!empty($customer_show->alltransaction))
            @foreach($customer_show->alltransaction as $key => $custopayinfo)
           
            <table class="table table-bordered">
               
                @if(!empty( $custopayinfo->payment_method))
                <tr>
                    <td>{{ $websiteLang->where('lang_key','payment_method')->first()->custom_text }}</td>
                    <td>{{ $custopayinfo->payment_method}}</td>
                </tr>
                @endif
                @if(!empty( $custopayinfo->transaction_details))
                <tr>
                    <td>{{ $websiteLang->where('lang_key','transaction_details')->first()->custom_text }}</td>
                    <td>{{ $custopayinfo->transaction_details}}</td>
                </tr>
                @endif
                @if(!empty( $custopayinfo->amount))
                <tr>
                    <td>{{ $websiteLang->where('lang_key','amount')->first()->custom_text }}</td>
                    <td class="w-50">{{ $custopayinfo->amount }}</td>
                </tr>
                @endif
                @if(!empty( $custopayinfo->status))
                <tr>
                    <td>{{ $websiteLang->where('lang_key','status')->first()->custom_text }}</td>
                    {{-- <td class="w-50">{{ $custopayinfo->status}}</td> --}}
                    <td>
                        @if ($custopayinfo->status==1)
                        <i class="badge bg-success  text-light p-2">{{ $websiteLang->where('lang_key','paid')->first()->custom_text }}</i>
                        @else
                        <i class="badge bg-danger text-light p-2">{{ $websiteLang->where('lang_key','unpaid')->first()->custom_text }}</i>
                        @endif 
                    </td>
                </tr>
                @endif
                

            </table>
            @endforeach
                @endif
        </div>
    </div>

    <script>

        function userStatus(id){
            $.ajax({
                type:"get",
                url:"{{url('/admin/agents-status/')}}"+"/"+id,
                success:function(response){
                   toastr.success(response)
                },
                error:function(err){
                    console.log(err);

                }
            })
        }
    </script>
@endsection
