@extends('layouts.user.layout')
@section('title')
<title>{{ $websiteLang->where('lang_key','instamojo')->first()->custom_text }}</title>
@endsection
@section('user-content')


