@extends('layouts.user.layout')
@section('title')
<title>{{ $websiteLang->where('lang_key','property_type')->first()->custom_text }}</title>
@endsection
@section('user-content')

 

<section>
    <div class="container justify-content-center">
        <div class="row justify-content-center p-4">
            <div class="col-sm-6">
                <h3 class="text-center text-dark">Your Verification Request Successfully</h3>
                
            </div>

        </div>
        <div class="row justify-content-center">
            <div class="col-sm-6" style="margin-left:190px ">
                <div class="m-5">
                    
                    <a href="{{route('user.showpaymet')}}" class="btn btn-primary p-3">Proceed for Auction</a>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection