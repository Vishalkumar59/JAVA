<?php

namespace App\Http\Controllers\Admin;

use App\Property;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\ListingCategory;
use App\City;
use App\PropertyPurpose;
use App\Aminity;
use App\PropertyAminity;
use App\PropertyImage;
use App\PropertyType;
use App\Bank;
use App\Wishlist;
use App\NearestLocation;
use App\PropertyReview;
use Str;
use File;
use Image;
use Auth;
use App\Setting;
use App\Locality;
use App\ManageText;
use App\PropertyCategory;
use App\ValidationText;
use App\PropertyNearestLocation;
use App\NotificationText;
use App\Import\AdminPropertyImport;
use Maatwebsite\Excel\Facades\Excel;
class AdminPropertyController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    public function index()
    {
        
        $properties=Property::with('bank','city')->where('user_type',1)->orderBy('id','desc')->get();
        $settings=Setting::first();
        $websiteLang=ManageText::all();
        return view('admin.property.index',compact('properties','settings','websiteLang'));
    }

    public function create()
    {
        $propertycategory = PropertyCategory::all();
        $propertyTypes=PropertyType::where('status',1)->get();
        $cities=City::where('status',1)->get();
        $purposes=PropertyPurpose::where('status',1)->get();
        $aminities=Aminity::where('status',1)->get();
        $nearest_locatoins=NearestLocation::where('status',1)->get();
        $websiteLang=ManageText::all();
        $banklist = Bank::all();
        return view('admin.property.create',compact('propertyTypes','cities','purposes','aminities','nearest_locatoins','websiteLang','banklist','propertycategory'));
    }



    public function store(Request $request)
    {
       
        $valid_lang=ValidationText::all();

        $rules = [
            'title'=>'required|unique:properties',
            'slug'=>'required|unique:properties',
            'property_type'=>'required',
            'city'=>'required',
            'address'=>'required',
            'locality' =>'required',
            'pincode' => 'required',
            'price'=>'required|numeric',
            'thumbnail_image'=>'required|file',
            'description'=>'required',
            'status'=>'required',
            'featured'=>'required',
            'urgent_property'=>'required',
            'top_property' => 'required',         
           

        ];


        $customMessages = [
            'title.required' => $valid_lang->where('lang_key','title')->first()->custom_text,
            'title.unique' => $valid_lang->where('lang_key','unique_title')->first()->custom_text,
            'slug.required' => $valid_lang->where('lang_key','slug')->first()->custom_text,
            'slug.unique' => $valid_lang->where('lang_key','unique_slug')->first()->custom_text,

            'property_type.required' => $valid_lang->where('lang_key','property_type')->first()->custom_text,
            'city.required' => $valid_lang->where('lang_key','city')->first()->custom_text,
            'address.required' => $valid_lang->where('lang_key','address')->first()->custom_text,
            'locality.required' => $valid_lang->where('lang_key','locality')->first()->custom_text,
            'pincode.required' => $valid_lang->where('lang_key','pincode')->first()->custom_text,
             'price.required' => $valid_lang->where('lang_key','price')->first()->custom_text,
            
            'commission.required' => $valid_lang->where('lang_key','commission')->first()->custom_text,
            'thumbnail_image.required' => $valid_lang->where('lang_key','thumb_img')->first()->custom_text,
            'description.required' => $valid_lang->where('lang_key','des')->first()->custom_text,
            'status.required' => $valid_lang->where('lang_key','status')->first()->custom_text,
            'featured.required' => $valid_lang->where('lang_key','featured')->first()->custom_text,
            'urgent_property.required' => $valid_lang->where('lang_key','urgent_property')->first()->custom_text,
            
        ];


         $this->validate($request, $rules, $customMessages);

        $locality = Locality::create([
            'locality_name' => $request->locality,
            'city_id' => $request->city,
             ]);
    
        $locality_id = $locality->id;


        do {
            $randomString = random_int(10000000, 99999999);
        } while (!empty(Property::where("property_unique_id", "=", $randomString)->first()));


      
        $video_link='';
        if(preg_match('/https:\/\/www\.youtube\.com\/watch\?v=[^&]+/', $request->video_link)) {
            $video_link=$request->video_link;
        }
    
    try{
        $property=new Property();
        $admin=Auth::guard('admin')->user();
        $property->admin_id=$admin->id;
        $property->title=$request->title;
        $property->slug=$request->slug;
        $property->property_type_id=$request->property_type;
        $property->city_id=$request->city;
        $property->address=$request->address;
        $property->property_unique_id = $request->property_unique_id ? $request->property_unique_id : $randomString;
        $property->locality = $locality_id;
        // $property->phone=$request->phone;
        // $property->email=$request->email;
        $property->website=$request->website;
        $property->category_id=$request->purpose;
        $property->price=$request->price;
        $property->market_price=$request->market_price;
        $property->commission=$request->commission;
        $property->period=$request->period ? $request->period : null;
        $property->area=$request->area;
        $property->number_of_unit=$request->unit;
        $property->number_of_room=$request->room;
        $property->number_of_bedroom=$request->bedroom;
        $property->number_of_bathroom=$request->bathroom;
        $property->number_of_floor=$request->floor;
        $property->number_of_kitchen=$request->kitchen;
        $property->number_of_parking=$request->parking;
        $property->video_link=$video_link;
        $property->google_map_embed_code=$request->google_map_embed_code;
        $property->description=$request->description;
        $property->status=$request->status;
        $property->is_featured=$request->featured;
        $property->urgent_property=$request->urgent_property;
        $property->top_property=$request->top_property;
        $property->seo_title=$request->seo_title ? $request->seo_title : $request->title;
        $property->seo_description=$request->seo_description ? $request->seo_description : $request->title;
        $property->pincode=$request->pincode;
        $property->bank_id = $request->bank;
        $property->finance = $request->finance;
        $property->auction = $request->auction;
        $property->emd_amount = $request->emd_amount;

        $property->vehicle_name = $request->vehicle_name;
        $property->vehicle_type = $request->vehicle_type;
        $property->vehicle_price = $request->vehicle_price;
        $property->vehicle_size = $request->vehicle_size;
        $property->property_enquiry = $request->property_enquiry;




        // pdf file
        if($request->file('pdf_file')){
            $file=$request->pdf_file;
            $file_ext=$file->getClientOriginalExtension();
            $file_name= 'property-file-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$file_ext;
            $file_path=$file_name;
            $file->move(public_path().'/uploads/custom-images/',$file_path);
            $property->file=$file_path;
        }


        //thumbnail image
        if($request->file('thumbnail_image')){
            $thumbnail_image=$request->thumbnail_image;
            $thumbnail_extention=$thumbnail_image->getClientOriginalExtension();
            $thumb_name= 'property-thumb-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$thumbnail_extention;
            $thumb_path='uploads/custom-images/'.$thumb_name;

            Image::make($thumbnail_image)
            ->save(public_path()."/".$thumb_path);
            $property->thumbnail_image=$thumb_path;

        }

        // banner image image
        if($request->file('banner_image') != null){
            $banner_image=$request->banner_image;
            $banner_ext=$banner_image->getClientOriginalExtension();
            $banner_name= 'listing-banner-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$banner_ext;
            $banner_path='uploads/custom-images/'.$banner_name;
            Image::make($banner_image)
                ->save(public_path()."/".$banner_path);
                $property->banner_image=$banner_path;

        }else if($request->file('thumbnail_image') != null){
            $banner_image=$request->thumbnail_image;
            $banner_ext=$banner_image->getClientOriginalExtension();
            $banner_name= 'listing-banner-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$banner_ext;
            $banner_path='uploads/custom-images/'.$banner_name;
            Image::make($banner_image)
                ->save(public_path().'/'.$banner_path);
                $property->banner_image=$banner_path;
        }
        $property->save();
       
       
        // property end

        // insert aminity
        if($request->aminities){
            foreach($request->aminities as $amnty){
                $aminity= new PropertyAminity();
                $aminity->property_id=$property->id;
                $aminity->aminity_id=$amnty;
                $aminity->save();
            }
        }

        // insert nearest place
        $exist_location=[];
        if($request->nearest_locations){
            foreach($request->nearest_locations as $index => $location){
                if($location){
                    if($request->distances[$index]){
                        if(!in_array($location, $exist_location)){
                            $nearest_location= new PropertyNearestLocation();
                            $nearest_location->property_id=$property->id;
                            $nearest_location->nearest_location_id=$location;
                            $nearest_location->distance=$request->distances[$index];
                            $nearest_location->save();
                        }
                        $exist_location[]=$location;

                    }
                }
            }
        }

        // slider image
        if($request->file('slider_images')){
            $images=$request->slider_images;
            foreach($images as $image){
                if($image != null){
                    $propertyImage=new PropertyImage();
                    $slider_ext=$image->getClientOriginalExtension();
                    // for small image
                    $slider_image= 'property-slide-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$slider_ext;
                    $slider_path='uploads/custom-images/'.$slider_image;

                    Image::make($image)
                        ->save(public_path()."/".$slider_path);

                    $propertyImage->image=$slider_path;
                    $propertyImage->property_id=$property->id;
                    $propertyImage->save();

                }
            }
        }

        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','create')->first()->custom_text;
        $notification=array('messege'=>$notification,'alert-type'=>'success');

        return redirect()->route('admin.property.index')->with($notification);
    } catch (Exception $e) {
        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
        $notification=array('messege'=>$notification,'alert-type'=>'error');
        return redirect()->back()->with($notification);
    }


    }


    public function show(Property $property)
    {
        //
    }


    public function edit(Property $property)
    {
        $banklist = Bank::all();
        $propertyTypes=PropertyType::where('status',1)->get();
        $cities=City::where('status',1)->get();
        $purposes=PropertyPurpose::all();
       
        $aminities=Aminity::where('status',1)->get();
        $nearest_locatoins=NearestLocation::where('status',1)->get();
        $websiteLang=ManageText::all();
        return view('admin.property.edit',compact('property','propertyTypes','cities','purposes','aminities','nearest_locatoins','websiteLang','banklist'));
    }


    public function update(Request $request, Property $property)
    {
       $valid_lang=ValidationText::all();

        $rules = [
            // 'title'=>'required|unique:properties',
            // 'slug'=>'required|unique:properties',
            'property_type'=>'required',
            'city'=>'required',
            'address'=>'required',
            'locality' =>'required',
            'pincode' => 'required',
            'price'=>'required|numeric',
            'description'=>'required',
            'status'=>'required',
            'featured'=>'required',
            'urgent_property'=>'required',
            'top_property' => 'required',         
           

        ];


        $customMessages = [
            // 'title.required' => $valid_lang->where('lang_key','title')->first()->custom_text,
            // 'title.unique' => $valid_lang->where('lang_key','unique_title')->first()->custom_text,
            // 'slug.required' => $valid_lang->where('lang_key','slug')->first()->custom_text,
            // 'slug.unique' => $valid_lang->where('lang_key','unique_slug')->first()->custom_text,

            'property_type.required' => $valid_lang->where('lang_key','property_type')->first()->custom_text,
            'city.required' => $valid_lang->where('lang_key','city')->first()->custom_text,
            'address.required' => $valid_lang->where('lang_key','address')->first()->custom_text,
            'locality.required' => $valid_lang->where('lang_key','locality')->first()->custom_text,
            'pincode.required' => $valid_lang->where('lang_key','pincode')->first()->custom_text,
             'price.required' => $valid_lang->where('lang_key','price')->first()->custom_text,
            
            'commission.required' => $valid_lang->where('lang_key','commission')->first()->custom_text,
            // 'thumbnail_image.required' => $valid_lang->where('lang_key','thumb_img')->first()->custom_text,
            'description.required' => $valid_lang->where('lang_key','des')->first()->custom_text,
            'status.required' => $valid_lang->where('lang_key','status')->first()->custom_text,
            'featured.required' => $valid_lang->where('lang_key','featured')->first()->custom_text,
            'urgent_property.required' => $valid_lang->where('lang_key','urgent_property')->first()->custom_text,
            
        ];


        $this->validate($request, $rules, $customMessages);
        Locality::where('locality_id', $property->locality)->update(['locality_name' => $request->locality , 'city_id' =>$request->city]);


        $video_link='';
        if(preg_match('/https:\/\/www\.youtube\.com\/watch\?v=[^&]+/', $request->video_link)) {
            $video_link=$request->video_link;
        }

        if(empty($request->slug)){
            $slug = Str::of($request->title)->slug('-');
            
        } else{
             $slug= $request->slug;
        }


        if(empty($request->property_unique_id)){
            do {
                $randomString = random_int(10000000, 99999999);
            } while (!empty(Property::where("property_unique_id", "=", $randomString)->first()));
        } else{
            $randomString =$request->property_unique_id;
        }


        $admin=Auth::guard('admin')->user();
        $property->title=$request->title;
        $property->slug=$slug;
        $property->property_type_id=$request->property_type;
        $property->city_id=$request->city;
        $property->address=$request->address;
        $property->property_unique_id = $randomString;
        $property->website=$request->website;
        $property->category_id=$request->purpose;
        $property->price=$request->price;
        $property->market_price=$request->market_price;
        $property->commission=$request->commission;
        $property->period=$request->period ? $request->period : null;
        $property->area=$request->area;
        $property->number_of_unit=$request->unit;
        $property->number_of_room=$request->room;
        $property->number_of_bedroom=$request->bedroom;
        $property->number_of_bathroom=$request->bathroom;
        $property->number_of_floor=$request->floor;
        $property->number_of_kitchen=$request->kitchen;
        $property->number_of_parking=$request->parking;
        $property->video_link=$video_link;
        $property->google_map_embed_code=$request->google_map_embed_code;
        $property->description=$request->description;
        $property->status=$request->status;
        $property->is_featured=$request->featured;
        $property->urgent_property=$request->urgent_property;
        $property->top_property=$request->top_property;
        $property->seo_title=$request->seo_title ? $request->seo_title : $request->title;
        $property->seo_description=$request->seo_description ? $request->seo_description : $request->title;
        $property->pincode=$request->pincode;
        $property->bank_id = $request->bank;
        $property->finance = $request->finance;
        $property->auction = $request->auction;
        $property->emd_amount = $request->emd_amount;

        $property->vehicle_name = $request->vehicle_name;
        $property->vehicle_type = $request->vehicle_type;
        $property->vehicle_price = $request->vehicle_price;
        $property->vehicle_size = $request->vehicle_size;
        $property->property_enquiry = $request->property_enquiry;


        // pdf file
        if($request->file('pdf_file')){
            $file=$request->pdf_file;
            $old_file=$property->file;
            $file_ext=$file->getClientOriginalExtension();
            $file_name= 'property-file-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$file_ext;
            $file_path=$file_name;
            $file->move(public_path().'/uploads/custom-images/',$file_path);
            $property->file=$file_path;
            $property->save();

            if($old_file){
                if(File::exists(public_path().'/'."uploads/custom-images/".$old_file)) unlink(public_path().'/'."uploads/custom-images/".$old_file);
            }

        }


        //thumbnail image
        if($request->file('thumbnail_image')){
            $old_thumbnail=$property->thumbnail_image;
            $thumbnail_image=$request->thumbnail_image;
            $thumbnail_extention=$thumbnail_image->getClientOriginalExtension();
            $thumb_name= 'property-thumb-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$thumbnail_extention;
            $thumb_path='uploads/custom-images/'.$thumb_name;
            Image::make($thumbnail_image)
                ->save(public_path().'/'.$thumb_path);

            $property->thumbnail_image=$thumb_path;
            $property->save();
            if(File::exists(public_path().'/'.$old_thumbnail)) unlink(public_path().'/'.$old_thumbnail);
        }

        // banner image image
        if($request->file('banner_image') != null){
            $old_banner=$property->banner_image;
            $banner_image=$request->banner_image;
            $banner_ext=$banner_image->getClientOriginalExtension();
            $banner_name= 'listing-banner-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$banner_ext;
            $banner_path='uploads/custom-images/'.$banner_name;

            Image::make($banner_image)
                ->save(public_path().'/'.$banner_path);


            $property->banner_image=$banner_path;
            $property->save();
            if(File::exists(public_path().'/'.$old_banner)) unlink(public_path().'/'.$old_banner);
        }
        // }else{
        //     $old_banner=$property->banner_image;
        //     $banner_image=$request->thumbnail_image;
        //     $banner_ext=$banner_image->getClientOriginalExtension();
        //     $banner_name= 'listing-banner-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$banner_ext;
        //     $banner_path='uploads/custom-images/'.$banner_name;

        //     Image::make($banner_image)
        //         ->save(public_path().'/'.$banner_path);


        //     $property->banner_image=$banner_path;
        //     $property->save();
        //     if(File::exists(public_path().'/'.$old_banner)) unlink(public_path().'/'.$old_banner);
        // }
        $property->save();
        // property end


        // for aminity
        $old_aminities=$property->propertyAminities;
        if($request->aminities){
            foreach($request->aminities as $amnty){
                $aminity= new PropertyAminity();
                $aminity->property_id=$property->id;
                $aminity->aminity_id=$amnty;
                $aminity->save();
            }

            if($old_aminities->count()>0){
                foreach($old_aminities as $old_aminity){
                    $old_aminity->delete();
                }
            }
        }else{
            if($old_aminities->count()>0){
                foreach($old_aminities as $old_aminity){
                    $old_aminity->delete();
                }
            }
        }



        // insert nearest place
        $old_nearest_locations=$property->propertyNearestLocations;
        $exist_location=[];
        $new_nearest_location=false;
        if($request->nearest_locations){
            foreach($request->nearest_locations as $index => $location){
                if($location){
                    if($request->distances[$index]){
                        if(!in_array($location, $exist_location)){
                            $nearest_location= new PropertyNearestLocation();
                            $nearest_location->property_id=$property->id;
                            $nearest_location->nearest_location_id=$location;
                            $nearest_location->distance=$request->distances[$index];
                            $nearest_location->save();
                            $new_nearest_location=true;
                        }
                        $exist_location[]=$location;

                    }
                }
            }

            if($new_nearest_location){
                if($old_nearest_locations->count() > 0){
                    foreach($old_nearest_locations as $old_location){
                        $old_location->delete();
                    }
                }
            }
        }else{
            if($old_nearest_locations->count() > 0){
                foreach($old_nearest_locations as $old_location){
                    $old_location->delete();
                }
            }

        }

        // slider image
        if($request->file('slider_images')){
            $images=$request->slider_images;
            foreach($images as $image){
                if($image != null){
                    $propertyImage=new PropertyImage();
                    $slider_ext=$image->getClientOriginalExtension();
                    // for small image
                    $slider_image= 'property-slide-'.date('Y-m-d-h-i-s-').rand(999,9999).'.'.$slider_ext;
                    $slider_path='uploads/custom-images/'.$slider_image;
                    Image::make($image)
                    ->save(public_path().'/'.$slider_path);

                    $propertyImage->image=$slider_path;
                    $propertyImage->property_id=$property->id;
                    $propertyImage->save();

                }
            }
        }

        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','update')->first()->custom_text;
        $notification=array('messege'=>$notification,'alert-type'=>'success');

        return redirect()->route('admin.property.index')->with($notification);
    }


    public function destroy(Property $property)
    {
       

        $old_thumbnail=$property->thumbnail_image;
        $old_banner=$property->banner_image;
        $old_pdf=$property->file;
        PropertyAminity::where('property_id',$property->id)->delete();
        WishList::where('property_id',$property->id)->delete();
        PropertyReview::where('property_id',$property->id)->delete();
        PropertyNearestLocation::where('property_id',$property->id)->delete();
        foreach($property->propertyImages as $image){
            if(File::exists(public_path().'/'.$image->image)) unlink(public_path().'/'.$image->image);
        }
        PropertyImage::where('property_id',$property->id)->delete();


        if($old_pdf){
            if(File::exists(public_path().'/'.'uploads/custom-images/'.$old_pdf)) unlink(public_path().'/'.'uploads/custom-images/'.$old_pdf);
        }

        if($old_thumbnail){
            if(File::exists(public_path().'/'.$old_thumbnail)) unlink(public_path().'/'.$old_thumbnail);
        }
        
        if(!empty($old_banner)){
            if(File::exists(public_path().'/'.$old_banner)) unlink(public_path().'/'.$old_banner);
        }
    

        $property->delete();
        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','delete')->first()->custom_text;
        $notification=array('messege'=>$notification,'alert-type'=>'success');
        return redirect()->back()->with($notification);

    }


    public function propertySliderImage($id){
        $image=PropertyImage::find($id);
        $old_image=$image->image;
        $image->delete();
        if(File::exists(public_path().'/'.$old_image)) unlink(public_path().'/'.$old_image);

        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','delete')->first()->custom_text;

        return response()->json(['success'=>$notification]);
    }

    public function deletePdfFile($id){

        $property=Property::find($id);
        $old_file= $property->file;
        $property->file=null;
        $property->save();
        $old_file= "uploads/custom-images/".$old_file;
        if(File::exists(public_path().'/'.$old_file)) unlink(public_path().'/'.$old_file);

        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','delete')->first()->custom_text;

        return response()->json(['success'=>$notification]);
    }

    public function changeStatus($id){
        $property=Property::find($id);
        if($property->status==1){
            $property->status=0;
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','inactive')->first()->custom_text;
            $message=$notification;
        }else{
            $property->status=1;
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','active')->first()->custom_text;
            $message=$notification;
        }
        $property->save();
        return response()->json($message);

    }

    public function existNearestLocation($id){
        $nearest_location=PropertyNearestLocation::find($id);
        $nearest_location->delete();

        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','delete')->first()->custom_text;

        return response()->json(['success'=>$notification]);
    }





    public function agentProperty(){
        $properties=Property::where('user_id',2)->orderBy('id','desc')->get();
        $settings=Setting::first();
        $websiteLang=ManageText::all();
        return view('admin.property.agent-property',compact('properties','settings','websiteLang'));
    }


    public function propertyAjax(Request $request)
    {
        $property_id = $request->property_category_id;
        
        //$status=Aminity::where('status', 1)->orderBy('id','asc')->get();
        if($property_id){
            $propertyTypes=Aminity::where('category_id',$property_id)->where('status', 1)->get();
            $data['propertyTypes']=$propertyTypes;
        
        } else{
            $data['propertyTypes']=[];
        }
        

        return response()->json($data);
    }

     public function import(){
        $websiteLang=ManageText::all();
        return view('admin.profile.import.index' , compact('websiteLang'));
    }
    public function uploadProperty(Request $request)
    {       
        
           Excel::import(new AdminPropertyImport, $request->file);


            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','create')->first()->custom_text;
            $notification=array('messege'=>$notification,'alert-type'=>'success');
    
            return redirect()->route('admin.property.index')->with($notification);
    }

}
