@extends('layouts.user.layout')
@section('title')
<title>{{ $property->seo_title }}</title>
@endsection
@section('meta')
<meta name="description" content="{{ $property->seo_description }}">
@endsection
@section('user-content')


<!--===BREADCRUMB PART START====-->
@if(!empty($property->banner_image))
<section class="wsus__breadcrumb" style="background: url({{ url($property->banner_image) }});">
@endif
    <div class="wsus_bread_overlay">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h4>{{ $menus->where('id', 2)->first()->navbar }}</h4>
                    <nav style="--bs-breadcrumb-divider: '-';" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('home') }}">{{ $menus->where('id', 1)->first()->navbar }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">
                                {{ $menus->where('id', 2)->first()->navbar }}</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>
<!--===BREADCRUMB PART END====-->


<!--=====PROPERTY DETAILD START=====-->
<section class="wsus__property_details mt_45 mb_20">
    <div class="container">
        <div class="row pro_det_slider">
            @foreach ($property->propertyImages as $imag_item)
            <div class="col-12">
                @if(!empty($imag_item->image))
                <div class="pro_det_slider_item">
                   
                    <img src="{{ url($imag_item->image) }}" alt="property" class="img-fluid w-100">
                </div>
                @endif
            </div>
            @endforeach
        </div>
      
        <div class="row mt_40">
            <div class="col-xl-8 col-lg-7">
                <div class="wsus__property_det_content">
                    <div class="row">
                        <div class="col-12">
                            <div class="wsus__single_details pb-sm-2">
                                <div class="wsus__single_det_top d-flex justify-content-between">
                                    <p>
                                        <span class="sale">@if(!empty( $property->propertyPurpose)){{ $property->propertyPurpose->custom_purpose }}@endif</span>
                                        {{-- @if ($property->urgent_property == 1)
                                        <span class="rent">{{ $websiteLang->where('lang_key', 'urgent')->first()->custom_text }}</span>
                                        @endif --}}
                                    </p>


                                    @if ($property->category_id == 1)
                                    <span class="tk">{{ $currency->currency_icon }}{{ propAmount($property->price) }}</span>
                                    @elseif ($property->category_id == 2)
                                    <span class="tk">{{ $currency->currency_icon }}{{ propAmount($property->price) }} /
                                        @if ($property->period == 'Daily')
                                        <span>{{ $websiteLang->where('lang_key', 'daily')->first()->custom_text }}</span>
                                        @elseif ($property->period == 'Monthly')
                                        <span>{{ $websiteLang->where('lang_key', 'monthly')->first()->custom_text }}</span>
                                        @elseif ($property->period == 'Yearly')
                                        <span>{{ $websiteLang->where('lang_key', 'yearly')->first()->custom_text }}</span>
                                        @endif
                                    </span>
                                    @endif

                                </div>
                                <h4>{{ $property->title }}</h4>


                                {{-- review commented  --}}
                                {{-- @php
                                $total_review = $property->reviews->where('status', 1)->count();
                                if ($total_review > 0) {
                                $avg_sum = $property->reviews->where('status', 1)->sum('avarage_rating');

                                $avg = $avg_sum / $total_review;
                                $intAvg = intval($avg);
                                $nextVal = $intAvg + 1;
                                $reviewPoint = $intAvg;
                                $halfReview = false;
                                if ($intAvg < $avg && $avg < $nextVal) { $reviewPoint=$intAvg + 0.5; $halfReview=true; } } 
                                
                                @endphp 
                                
                                @if ($total_review> 0)
                                    <p class="wsus__pro_det_top_rating">
                                        @for ($i = 1; $i <= 5; $i++) @if ($i <=$reviewPoint) <i class="fas fa-star"></i>
                                            @elseif ($i > $reviewPoint)
                                            @if ($halfReview == true)
                                            <i class="fas fa-star-half-alt"></i>
                                            @php
                                            $halfReview = false;
                                            @endphp
                                            @else
                                            <i class="fal fa-star"></i>
                                            @endif
                                            @endif
                                            @endfor
                                            <span>{{ sprintf('%.1f', $reviewPoint) }}</span>
                                    </p>
                                    @else
                                    <p class="wsus__pro_det_top_rating">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star-half-alt"></i>
                                        <span>0.0</span>
                                    </p>
                                    @endif --}}


                                    <p> {{ $property->address . ', ' . $property->city->name . ', ' . $property->city->countryState->name . ', ' . $property->city->countryState->country->name }}
                                    </p>
                                    <br>
                                    @php
                                        $market_price = $property->market_price;
                                        $sell_price = $property->price;

                                        $price = $market_price - $sell_price;
                                        
                                        if($market_price){
                                        $percent_price = 100*$price/$market_price;
                                        }
                                        
                                    @endphp
                                    @if($market_price)
                                    <h6>Grab at {{round($percent_price,2)}}% less than market price ({{ $currency->currency_icon }}{{propAmount($market_price)}}) </h6>
                                    @endif

                                    @if ($property->category_id == 1)
                                    <ul class="item d-flex flex-wrap mt-3">
                                        @if(!empty($property->number_of_bedroom ))
                                        <li><i class="fal fa-bed"></i> {{ $property->number_of_bedroom }}
                                            {{ $websiteLang->where('lang_key', 'bed')->first()->custom_text }}</li>
                                            @endif
                                         @if(!empty($property->number_of_bathroom ))
                                        <li><i class="fal fa-shower"></i> {{ $property->number_of_bathroom }}
                                            {{ $websiteLang->where('lang_key', 'bath')->first()->custom_text }}</li>
                                            @endif
                                        @if(!empty($property->area ))
                                        <li><i class="fal fa-draw-square"></i> {{ $property->area }}
                                            {{ $websiteLang->where('lang_key', 'sqft_s')->first()->custom_text }}</li>
                                        @endif
                                    </ul>
                                    @else
                                    <ul class="item d-flex flex-wrap mt-3">
                                        @if(!empty($property->vehicle_name))
                                        <li><i class="fas fa-car-side"></i> {{ $property->vehicle_name }}</li>
                                        @endif
                                        @if(!empty($property->vehicle_type))
                                        <li><i class="fal fa-toolbox"></i> {{ $property->vehicle_type }}</li>
                                        @endif
                                        @if(!empty($property->vehicle_price))
                                        <li><i class="far fa-money-bill-alt"></i> {{ $property->vehicle_price }}</li>
                                        @endif
                                        @if(!empty($property->vehicle_size))
                                        <li><i class="fal fa-draw-square"></i> {{ $property->vehicle_size }}</li>
                                        @endif
                                    </ul>
                                    @endif


                                    <ul class="list d-flex flex-wrap featurestyle">
                                        @if ($property->is_featured == 1)
                                        <li><a href="javascript:;"><i class="fas fa-check-circle"></i>{{ $websiteLang->where('lang_key', 'featured')->first()->custom_text }}</a>
                                        </li>
                                        @endif

                                        <li><a href="javascript:;"><i class="far fa-eye"></i> {{ $property->views }}</a>
                                        </li>

                                        
                                         <li><a href="{{ route('user.add.to.wishlist', $property->id) }}"><i class="fas fa-heart"></i>
                                                {{ $websiteLang->where('lang_key', 'add_wishlist')->first()->custom_text }}</a>
                                        </li>
                            
                                    @guest
                                    @if($property->property_enquiry == 'auction')
                                        <li><a href="{{ route('login') }}"><i class="fas fa-sign-in-alt"></i>
                                                {{ $websiteLang->where('lang_key', 'participate_in_auction')->first()->custom_text }}</a>
                                        </li>
                                    @else
                                        <li><a href="{{ route('login') }}" ><i class="fas fa-sign-in-alt"></i>
                                                {{ $websiteLang->where('lang_key', 'send_enquiry')->first()->custom_text }} </a>
                                        </li>
                                    @endif
                                    @endguest
                                    @if(Auth::check() && auth()->user()->user_type == "1")
                                        @php
                                            $data = $kyclist->where('property_id' , $property->id)->where('user_id' , auth()->user()->id)->first();
                                            $data = $enqlist->where('property_id' , $property->id)->where('user_id' , auth()->user()->id)->first();
                                        @endphp
                                        @if(!empty($data))
                                            <li><a href="javascript:;"><i class="fas fa-sign-in-alt"></i>
                                                        {{ $websiteLang->where('lang_key', 'already_participate')->first()->custom_text }}</a>
                                            </li>
                                        @else
                                   
                                        @if($property->property_enquiry == 'auction')
                                            <li><a href="javascript:;"  data-target="#newLocation" data-toggle="modal"><i class="fas fa-sign-in-alt"></i>
                                                    {{ $websiteLang->where('lang_key', 'participate_in_auction')->first()->custom_text }}</a>
                                            </li> @else
                                            <li><a href="javascript:;" data-target="#sendEnquery" data-toggle="modal"><i class="fas fa-sign-in-alt"></i>
                                                    {{ $websiteLang->where('lang_key', 'send_enquiry')->first()->custom_text }} </a>
                                            </li>
                                        @endif
                                        
                                        @endif
                                    @endif
                                        @if(!empty($property->emd_amount))
                                        <li><a><i class="fa fa-money"></i>{{ $websiteLang->where('lang_key', 'emd')->first()->custom_text }}
                                            {{$currency->currency_icon}} {{propAmount($property->emd_amount)}} </a></li>
                                        @endif
                                        
                                        @if (!empty($property->bank))
                                        <li><a><i class="fa fa-bank"></i> {{ $property->bank->name }}
                                            </a></li>
                                        @endif
                                    </ul>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="wsus__single_details details_future">
                                <h5>{{ $websiteLang->where('lang_key', 'detail_and_feature')->first()->custom_text }}
                                </h5>
                                <div class="details_futurr_single">
                                    <div class="row">
                                        @if ($property->category_id == '1')
                                        <div class="col-xl-6">
                                            <table class="table">
                                                <tbody>
                                                    <tr>
                                                        @if (!empty($property->propertyType))
                                                        <th>{{ $websiteLang->where('lang_key', 'property_category')->first()->custom_text }}:
                                                        </th>
                                                        <td>
                                                            {{ $property->propertyType->type }}
                                                            
                                                        </td>
                                                        @endif
                                                    </tr>
                                                    <tr>
                                                        @if (!empty($property->area))
                                                        <th> {{ $websiteLang->where('lang_key', 'area')->first()->custom_text }}:
                                                        </th>
                                                        <td>{{ $property->area }}
                                                            {{ $websiteLang->where('lang_key', 'sqft_s')->first()->custom_text }}
                                                        </td>
                                                        @endif
                                                    </tr>
                                                    <tr>
                                                        @if (!empty($property->number_of_bedroom))
                                                        <th>{{ $websiteLang->where('lang_key', 'bedrooms')->first()->custom_text }}:
                                                        </th>
                                                        <td>{{ $property->number_of_bedroom }}</td>
                                                        @endif
                                                    </tr>
                                                    <tr>
                                                        @if (!empty($property->number_of_bathroom))
                                                        <th>{{ $websiteLang->where('lang_key', 'bathrooms')->first()->custom_text }}:
                                                        </th>
                                                        <td>{{ $property->number_of_bathroom }}</td>
                                                        @endif
                                                    </tr>
                                                    <tr>
                                                        @if (!empty($property->number_of_room))
                                                        <th>{{ $websiteLang->where('lang_key', 'rooms')->first()->custom_text }}:
                                                        </th>
                                                        <td>{{ $property->number_of_room }}</td>
                                                        @endif
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-xl-6">
                                            <table class="table xs_sm_mb">
                                                <tbody>
                                                    <tr>

                                                        @if (!empty($property->number_of_unit))
                                                        <th>{{ $websiteLang->where('lang_key', 'units')->first()->custom_text }}:
                                                        </th>
                                                        <td>{{ $property->number_of_unit }}</td>
                                                        @endif
                                                      
                                                    </tr>
                                                    <tr>
                                                        @if (!empty($property->number_of_floor))
                                                        <th> {{ $websiteLang->where('lang_key', 'floors')->first()->custom_text }}:
                                                        </th>
                                                        <td>{{ $property->number_of_floor }}</td>
                                                        @endif
                                                    </tr>
                                                    <tr>
                                                        @if (!empty($property->number_of_kitchen))
                                                        <th>{{ $websiteLang->where('lang_key', 'kitchens')->first()->custom_text }}:
                                                        </th>
                                                        <td>{{ $property->number_of_kitchen }}</td>
                                                        @endif
                                                    </tr>
                                                    <tr>
                                                        @if (!empty($property->number_of_parking))
                                                        <th>{{ $websiteLang->where('lang_key', 'parking_place_s')->first()->custom_text }}:
                                                        </th>
                                                        <td>{{ $property->number_of_parking }}</td>
                                                        @endif
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>
                                        @endif
                                        @if ($property->category_id == '2')
                                        <div class="col-xl-6">
                                            <table class="table">
                                                <tbody>
                                                    <tr>
                                                        @if (!empty($property->propertyType->type))
                                                        <th>{{ $websiteLang->where('lang_key', 'property_category')->first()->custom_text }}:
                                                        </th>
                                                        <td>
                                                            
                                                            {{ $property->propertyType->type }}
                                                           
                                                        </td>
                                                        @endif
                                                    </tr>
                                                    <tr>
                                                        @if (!empty($property->vehicle_name))
                                                        <th> {{ $websiteLang->where('lang_key', 'vehicle_name')->first()->custom_text }}:
                                                        </th>
                                                        <td>{{ $property->vehicle_name }}
                                                        </td>
                                                        @endif
                                                    </tr>
                                                    <tr>
                                                        @if (!empty($property->vehicle_type))
                                                        <th>{{ $websiteLang->where('lang_key', 'vehicle_type')->first()->custom_text }}:
                                                        </th>
                                                        <td>{{ $property->vehicle_type }}</td>
                                                        @endif
                                                    </tr>
                                                    <tr>
                                                        @if (!empty($property->vehicle_price))
                                                        <th>{{ $websiteLang->where('lang_key', 'vehicle_price')->first()->custom_text }}:
                                                        </th>
                                                        <td>{{ $property->vehicle_price }}</td>
                                                        @endif
                                                    </tr>
                                                    <tr>
                                                        @if (!empty($property->vehicle_size))
                                                        <th>{{ $websiteLang->where('lang_key', 'vehicle_size')->first()->custom_text }}:
                                                        </th>
                                                        <td>{{ $property->vehicle_size }}</td>
                                                        @endif
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        @endif

                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="col-12">
                            <div class="wsus__single_details details_description">
                                <h5>{{ $websiteLang->where('lang_key', 'des')->first()->custom_text }}</h5>
                                {!! clean($property->description) !!}

                                @if ($property->file)
                                <a href="{{ route('download-listing-file', $property->file) }}" class="common_btn mt_20 my-3">{{ $websiteLang->where('lang_key', 'download_pdf')->first()->custom_text }}</a>
                                @endif


                            </div>
                        </div>
                        @if ($property->video_link)
                        @php
                        $video_id = explode('=', $property->video_link);
                        @endphp
                        <div class="col-12">
                            <div class="wsus__single_details details_videos pb_10">
                                <h5>{{ $websiteLang->where('lang_key', 'property_video')->first()->custom_text }}
                                </h5>
                                <iframe width="560" height="315" src="https://www.youtube.com/embed/{{ $video_id[1] }}" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                            </div>
                        </div>
                        @endif
                        
                    
                        @if ($property->propertyAminities->count() != 0)
                        <div class="col-12">
                            <div class="wsus__single_details details_aminities pb_10">
                                <h5>{{ $websiteLang->where('lang_key', 'aminities')->first()->custom_text }}</h5>
                                <ul class="d-flex flex-wrap">
                            @if(!empty($property->propertyAminities))
                               @foreach ($property->propertyAminities as $aminity_item)
                                  @if(!empty($aminity_item->aminity))
                                    <li><i class="fal fa-check"></i> {{ $aminity_item->aminity->aminity }}</li>
                                  @endif
                                     {{-- <li><i class="fal fa-check"></i> {{ $aminity_item->aminity->aminity }}</li> --}}
                                    
                                 @endforeach
                             @endif

                                </ul>
                            </div>
                        </div>
                        @endif

                        @if ($property->propertyNearestLocations->count() != 0)
                        <div class="col-12">
                            <div class="wsus__single_details details_nearest_location pb_10">
                                <h5>{{ $websiteLang->where('lang_key', 'nearest_place')->first()->custom_text }}
                                </h5>
                                <ul class="d-flex flex-wrap">
                                    @foreach ($property->propertyNearestLocations as $item)
                                    <li><span>{{ $item->nearestLocation->location }}:</span>
                                        {{ $item->distance }}{{ $websiteLang->where('lang_key', 'km')->first()->custom_text }}
                                    </li>
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                        @endif
                        @if(!empty($property->LocalityName->locality_name))
                        <div class="col-12">
                            <div class="wsus__single_details details_map">
                                <h5>Locality
                                </h5>
                                 <ul class="d-flex flex-wrap">
                                    
                                    <li><span>{{$property->LocalityName->locality_name }}</span></li>
                                   
                                </ul>
                            </div>
                        </div>
                         @endif
                        @if ($property->google_map_embed_code)
                        <div class="col-12">
                            <div class="wsus__single_details details_map">
                                <h5>{{ $websiteLang->where('lang_key', 'google_map')->first()->custom_text }}
                                </h5>
                                {!! $property->google_map_embed_code !!}
                            </div>
                        </div>
                        @endif

                        
                    </div>
                </div>
            </div>
           
            <div class="col-xl-4 col-lg-5">
                <div class="wsus__property_sidebar" id="sticky_sidebar">
                    <div class="wsus__sidebar_message">
                        @if ($property->user_type == 1)
                        <div class="wsus__sidebar_message_top">
                            @if(!empty($property->admin->image))
                            <img src="{{ $property->admin->image ? url($property->admin->image) : url($default_image->image) }}" alt="images" class="img-fluid img-thumbnail">
                            @endif
                            @if(!empty($property->admin->slug))
                            <a class="name" href="{{ route('agent.show', ['user_type' => '1', 'user_name' => $property->admin->slug]) }}">{{ $property->admin->name }}</a>
                            @endif
                            @if(!empty($property->admin->email))
                            <a class="mail" href="mailto:{{ $property->admin->email }}"><i class="fal fa-envelope-open"></i> {{ $property->admin->email }}</a>
                            @endif
                        </div>
                        @else
                        <div class="wsus__sidebar_message_top">
                            @if(!empty($property->user->image))
                            <img src="{{ $property->user->image ? url($property->user->image) : url($default_image->image) }}" alt="images" class="img-fluid img-thumbnail">
                            @endif
                            @if(!empty($property->user->slug))
                            <a class="name" href="{{ route('agent.show', ['user_type' => '2', 'user_name' => $property->user->slug]) }}">{{ $property->user->name }}</a>
                            @endif
                            @if(!empty($property->user->email))
                            <a class="mail" href="mailto:{{ $property->user->email }}"><i class="fal fa-envelope-open"></i> {{ $property->user->email }}</a>
                            @endif
                        </div>
                        @endif
                        {{-- <form id="listingAuthContactForm">
                    @csrf
                    <div class="wsus__sidebar_input">
                        <label>{{ $websiteLang->where('lang_key','name')->first()->custom_text }}</label>
                        <input type="text" name="name">
                    </div>
                    <div class="wsus__sidebar_input">
                        <label>{{ $websiteLang->where('lang_key','email')->first()->custom_text }}</label>
                        <input type="email" name="email">
                    </div>
                    <div class="wsus__sidebar_input">
                        <label>{{ $websiteLang->where('lang_key','phone')->first()->custom_text }}</label>
                        <input type="text" name="phone">
                    </div>
                    <div class="wsus__sidebar_input">
                        <label>{{ $websiteLang->where('lang_key','subject')->first()->custom_text }}</label>
                        <input type="text" name="subject">
                    </div>
                    <div class="wsus__sidebar_input">
                        <label>{{ $websiteLang->where('lang_key','des')->first()->custom_text }}</label>
                        <textarea cols="3" rows="3" name="message"></textarea>
                        <input type="hidden" name="user_type" value="{{ $property->user_type }}">
                        @if ($property->user_type == 1)
                        <input type="hidden" name="admin_id" value="{{ $property->admin_id }}">
                        @else
                        <input type="hidden" name="user_id" value="{{ $property->user_id }}">
                        @endif


                        @if ($setting->allow_captcha == 1)
                        <p class="g-recaptcha mt-3" data-sitekey="{{ $setting->captcha_key }}"></p>
                        @endif

                        <button type="submit" id="listingAuthorContctBtn" class="common_btn"><i id="listcontact-spinner" class="loading-icon fa fa-spin fa-spinner d-none mr-5"></i> {{ $websiteLang->where('lang_key','send_msg')->first()->custom_text }}</button>
                    </div>

                    </form> --}}
                </div>

                @php
                $isActivePropertyQty = 0;
                foreach ($similarProperties as $value) {
                if ($value->expired_date == null) {
                $isActivePropertyQty += 1;
                } elseif ($value->expired_date >= date('Y-m-d')) {
                $isActivePropertyQty += 1;
                }
                }
                @endphp

                @if ($isActivePropertyQty != 0)
                <div class="row">
                    @foreach ($similarProperties as $similar_item)
                    @if ($similar_item->expired_date == null)
                    <div class="col-xl-12 col-md-6 col-lg-12">
                        <div class="wsus__single_property">
                            <div class="wsus__single_property_img">
                                <img src="{{ asset($similar_item->thumbnail_image) }}" alt="properties" class="img-fluid w-100">

                                @if ($similar_item->category_id == 1)
                                <span class="sale">@if(!empty( $similar_item->propertyPurpose)){{ $similar_item->propertyPurpose->custom_purpose }}@endif</span>
                                @elseif($similar_item->category_id == 2)
                                <span class="sale">@if(!empty( $similar_item->propertyPurpose)){{ $similar_item->propertyPurpose->custom_purpose }}@endif</span>
                                @endif

                                {{-- @if ($similar_item->urgent_property == 1)
                                <span class="rent">{{ $websiteLang->where('lang_key', 'urgent')->first()->custom_text }}</span>
                                @endif --}}

                            </div>
                            <div class="wsus__single_property_text">
                                @if ($similar_item->category_id == 1)
                                <span class="tk">{{ $currency->currency_icon }}{{ propAmount($similar_item->price) }}</span>
                                @elseif ($similar_item->category_id == 2)
                                <span class="tk">{{ $currency->currency_icon }}{{ propAmount($similar_item->price) }}
                                    /
                                    @if ($similar_item->period == 'Daily')
                                    <span>{{ $websiteLang->where('lang_key', 'daily')->first()->custom_text }}</span>
                                    @elseif ($similar_item->period == 'Monthly')
                                    <span>{{ $websiteLang->where('lang_key', 'monthly')->first()->custom_text }}</span>
                                    @elseif ($similar_item->period == 'Yearly')
                                    <span>{{ $websiteLang->where('lang_key', 'yearly')->first()->custom_text }}</span>
                                    @endif
                                </span>
                                @endif

                                <a href="{{ route('property.details', $similar_item->slug) }}" class="title w-100">{{ $similar_item->title }}</a>
                                <ul class="d-flex flex-wrap justify-content-between">
                                    <li><i class="fal fa-bed"></i>
                                        {{ $similar_item->number_of_bedroom }}
                                        {{ $websiteLang->where('lang_key', 'bed')->first()->custom_text }}
                                    </li>
                                    <li><i class="fal fa-shower"></i>
                                        {{ $similar_item->number_of_bathroom }}
                                        {{ $websiteLang->where('lang_key', 'bath')->first()->custom_text }}
                                    </li>
                                    <li><i class="fal fa-draw-square"></i> {{ $similar_item->area }}
                                        {{ $websiteLang->where('lang_key', 'sqft_s')->first()->custom_text }}
                                    </li>
                                </ul>
                                <div class="wsus__single_property_footer d-flex justify-content-between align-items-center">
                                    <a href="@if (!empty($similar_item->propertyType)) {{ route('search-property', ['page_type' => 'list_view', 'property_type' => $similar_item->propertyType->id]) }} @endif" class="category">
                                        @if (!empty($similar_item->propertyType))
                                        {{ $similar_item->propertyType->type }}
                                        @endif
                                    </a>

                                    {{-- @php
                                    $total_review = $similar_item->reviews->where('status', 1)->count();
                                    if ($total_review > 0) {
                                    $avg_sum = $similar_item->reviews->where('status', 1)->sum('avarage_rating');

                                    $avg = $avg_sum / $total_review;
                                    $intAvg = intval($avg);
                                    $nextVal = $intAvg + 1;
                                    $reviewPoint = $intAvg;
                                    $halfReview = false;
                                    if ($intAvg < $avg && $avg < $nextVal) { $reviewPoint=$intAvg + 0.5; $halfReview=true; } } @endphp @if ($total_review> 0) --}}
                                        {{-- <span class="rating">{{ sprintf('%.1f', $reviewPoint) }} --}}

                                            {{-- @for ($i = 1; $i <= 5; $i++) @if ($i <=$reviewPoint) <i class="fas fa-star"></i> --}}
                                                {{-- @elseif ($i > $reviewPoint) --}}
                                                {{-- @if ($halfReview == true) --}}
                                                {{-- <i class="fas fa-star-half-alt"></i> --}}
                                                {{-- @php --}}
                                                {{-- $halfReview = false; --}}
                                                {{-- @endphp --}}
                                                {{-- @else
                                                <i class="fal fa-star"></i>
                                                @endif
                                                @endif
                                                @endfor
                                        </span>
                                        @else
                                        <span class="rating">0.0
                                            @for ($i = 1; $i <= 5; $i++) <i class="fal fa-star"></i>
                                                @endfor
                                        </span>
                                        @endif --}}
                                </div>
                            </div>
                        </div>
                    </div>
                    @elseif($similar_item->expired_date >= date('Y-m-d'))
                    <div class="col-xl-12 col-md-6 col-lg-12">
                        <div class="wsus__single_property">
                            <div class="wsus__single_property_img">
                                <img src="{{ asset($similar_item->thumbnail_image) }}" alt="properties" class="img-fluid w-100">

                                @if ($similar_item->category_id == 1)
                                <span class="sale">@if(!empty( $similar_item->propertyPurpose)){{ $similar_item->propertyPurpose->custom_purpose }}@endif</span>
                                @elseif($similar_item->category_id == 2)
                                <span class="sale">@if(!empty( $similar_item->propertyPurpose)){{ $similar_item->propertyPurpose->custom_purpose }}@endif</span>
                                @endif

                                {{-- @if ($similar_item->urgent_property == 1)
                                <span class="rent">{{ $websiteLang->where('lang_key', 'urgent')->first()->custom_text }}</span>
                                @endif --}}

                            </div>
                            <div class="wsus__single_property_text">
                                @if ($similar_item->category_id == 1)
                                <span class="tk">{{ $currency->currency_icon }}{{ propAmount($similar_item->price) }}</span>
                                @elseif ($similar_item->category_id == 2)
                                <span class="tk">{{ $currency->currency_icon }}{{ propAmount($similar_item->price) }}
                                    /
                                    @if ($similar_item->period == 'Daily')
                                    <span>{{ $websiteLang->where('lang_key', 'daily')->first()->custom_text }}</span>
                                    @elseif ($similar_item->period == 'Monthly')
                                    <span>{{ $websiteLang->where('lang_key', 'monthly')->first()->custom_text }}</span>
                                    @elseif ($similar_item->period == 'Yearly')
                                    <span>{{ $websiteLang->where('lang_key', 'yearly')->first()->custom_text }}</span>
                                    @endif
                                </span>
                                @endif

                                <a href="{{ route('property.details', $similar_item->slug) }}" class="title w-100">{{ $similar_item->title }}</a>
                                <ul class="d-flex flex-wrap justify-content-between">
                                    <li><i class="fal fa-bed"></i>
                                        {{ $similar_item->number_of_bedroom }}
                                        {{ $websiteLang->where('lang_key', 'bed')->first()->custom_text }}
                                    </li>
                                    <li><i class="fal fa-shower"></i>
                                        {{ $similar_item->number_of_bathroom }}
                                        {{ $websiteLang->where('lang_key', 'bath')->first()->custom_text }}
                                    </li>
                                    <li><i class="fal fa-draw-square"></i> {{ $similar_item->area }}
                                        {{ $websiteLang->where('lang_key', 'sqft_s')->first()->custom_text }}
                                    </li>
                                </ul>
                                {{-- @dd($similar_item->propertyPurpose->id); --}}

                                <div class="wsus__single_property_footer d-flex justify-content-between align-items-center">
                                    <a href="@if (!empty($similar_item->propertyType)) {{ route('search-property', ['page_type' => 'list_view', 'property_type' => $similar_item->propertyType->id]) }} @endif" class="category">
                                        @if (!empty($similar_item->propertyType))
                                        {{ $similar_item->propertyType->type }}
                                        @endif
                                    </a>

                                    @php
                                    $total_review = $similar_item->reviews->where('status', 1)->count();
                                    if ($total_review > 0) {
                                    $avg_sum = $similar_item->reviews->where('status', 1)->sum('avarage_rating');

                                    $avg = $avg_sum / $total_review;
                                    $intAvg = intval($avg);
                                    $nextVal = $intAvg + 1;
                                    $reviewPoint = $intAvg;
                                    $halfReview = false;
                                    if ($intAvg < $avg && $avg < $nextVal) { $reviewPoint=$intAvg + 0.5; $halfReview=true; } } @endphp @if ($total_review> 0)
                                        <span class="rating">{{ sprintf('%.1f', $reviewPoint) }}

                                            @for ($i = 1; $i <= 5; $i++) @if ($i <=$reviewPoint) <i class="fas fa-star"></i>
                                                @elseif ($i > $reviewPoint)
                                                @if ($halfReview == true)
                                                <i class="fas fa-star-half-alt"></i>
                                                @php
                                                $halfReview = false;
                                                @endphp
                                                @else
                                                <i class="fal fa-star"></i>
                                                @endif
                                                @endif
                                                @endfor
                                        </span>
                                        @else
                                        <span class="rating">0.0
                                            @for ($i = 1; $i <= 5; $i++) <i class="fal fa-star"></i>
                                                @endfor
                                        </span>
                                        @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif
                    @endforeach
                </div>
                @endif
            </div>
        </div>
    </div>
    </div>
</section>
<!--=====PROPERTY DETAILD  END=====-->


<!-- Create Location Modal -->

<div class="modal fade" id="newLocation" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">{{ $websiteLang->where('lang_key', 'submit_kyc')->first()->custom_text }}
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container-fluid">

                    <form action="{{ route('user.documentstore') }}" method="post" enctype="multipart/form-data" class="needs-validation" id="form_validation">
                        @csrf
                        
                        <div class="form-group has-validation">
                            <!-- <label for="aminity">{{ $websiteLang->where('lang_key', 'enter_your_name')->first()->custom_text }}</label> -->
                            <input type="text" class="form-control" name="name" id="name" value="{{ old('name') }}" placeholder="{{ $websiteLang->where('lang_key', 'enter_your_name')->first()->custom_text }}" required>
                        </div>
                        <input type="hidden" value="{{$property->id}}" name="property_id"/>
                        <input type="hidden" value="{{$property->user_id}}" name="agents_id"/>
                        <div class="form-group has-validation mt-4">
                            <!-- <label for="aminity">{{ $websiteLang->where('lang_key', 'enter_your_adhar')->first()->custom_text }}</label> -->
                            <input type="number" class="form-control" name="adhar" id="adhar" value="{{ old('adhar') }}" placeholder="{{ $websiteLang->where('lang_key', 'enter_your_adhar')->first()->custom_text }}" required>
                        </div>

                        <input type="hidden" name="property_id" value="{{$property->id}}"/>


                        <div class="form-group has-validation mt-4">
                            <!-- <label for="aminity">{{ $websiteLang->where('lang_key', 'enter_pan_number')->first()->custom_text }}</label> -->
                            <input type="text" class="form-control pan_number" name="pan_no" id="pan" value="{{ old('pan_no') }}" placeholder="{{ $websiteLang->where('lang_key', 'enter_pan_number')->first()->custom_text }}" required>
                        </div>

                        <div class="form-group has-validation mt-4">
                            <input type="number" class="form-control" name="acountnumber" id="accountnumber" value="{{ old('acountnumber') }}" placeholder="{{ $websiteLang->where('lang_key', 'enter_your_bank_account_number')->first()->custom_text }}" required>
                        </div>


                        <div class="form-group has-validation mt-4 my-4">
                            <input type="text" class="form-control" name="ifsc" id="ifsc" value="{{ old('ifsc') }}" placeholder="{{ $websiteLang->where('lang_key', 'enter_bank_ifc_code')->first()->custom_text }}" required>
                        </div>


                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">{{ $websiteLang->where('lang_key', 'close')->first()->custom_text }}</button>
                <button type="submit" class="btn btn-primary">{{ $websiteLang->where('lang_key', 'verify')->first()->custom_text }}</button>
            </div>
            </form>

        </div>
    </div>
</div>

<div class="modal fade" id="sendEnquery" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">{{ $websiteLang->where('lang_key', 'submit_enquiry')->first()->custom_text }}
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container-fluid">

                    <form action="{{ route('user.user-enquiry') }}" method="post" enctype="multipart/form-data" class="needs-validation" id="form_validation">
                        @csrf

                        <div class="form-group has-validation">
                        
                            <input type="text" class="form-control" name="name" id="name" value="{{ old('name') }}" placeholder="{{ $websiteLang->where('lang_key', 'enter_your_name')->first()->custom_text }}" required>
                        </div>
                        <input type="hidden" value="{{$property->id}}" name="property_id"/>
                        <input type="hidden" value="{{$property->user_id}}" name="agents_id"/>
                        <div class="form-group has-validation mt-4">
                            <input type="email" class="form-control" name="email" id="email" value="{{ old('email') }}" placeholder="{{ $websiteLang->where('lang_key', 'enter_your_email')->first()->custom_text }}" required>
                        </div>

                        <div class="form-group has-validation mt-4">
                            <textarea class="form-control" name="message" id="message" value="{{ old('message') }}" placeholder="{{ $websiteLang->where('lang_key', 'enter_your_message')->first()->custom_text }}"></textarea>
                        </div>

                        <input type="hidden" name="property_id" value="{{$property->id}}"/>

                        <div class="form-group has-validation mt-4">

                          
                        </div>

                    


                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">{{ $websiteLang->where('lang_key', 'close')->first()->custom_text }}</button>
                <button type="submit" class="btn btn-primary">{{ $websiteLang->where('lang_key', 'verify')->first()->custom_text }}</button>
            </div>
            </form>

        </div>
    </div>
</div>

<script>
    (function($) {
        "use strict";
        $(document).ready(function() {
            $("#listingAuthorContctBtn").on('click', function(e) {
                e.preventDefault();
                // project demo mode check
                var isDemo = "{{ env('PROJECT_MODE') }}"
                var demoNotify = "{{ env('NOTIFY_TEXT') }}"
                if (isDemo == 0) {
                    toastr.error(demoNotify);
                    return;
                }
                // end

                $("#listcontact-spinner").removeClass('d-none')
                $("#listingAuthorContctBtn").addClass('custom-opacity')
                $("#listingAuthorContctBtn").attr('disabled', true);
                $("#listingAuthorContctBtn").removeClass('site-btn-effect')

                $.ajax({
                    url: "{{ route('user.contact.message') }}"
                    , type: "post"
                    , data: $('#listingAuthContactForm').serialize()
                    , success: function(response) {
                        if (response.success) {
                            $("#listingAuthContactForm").trigger("reset");
                            toastr.success(response.success)
                            $("#listcontact-spinner").addClass('d-none')
                            $("#listingAuthorContctBtn").removeClass('custom-opacity')
                            $("#listingAuthorContctBtn").attr('disabled', false);
                            $("#listingAuthorContctBtn").addClass('site-btn-effect')
                        }
                        if (response.error) {
                            toastr.error(response.error)
                            $("#listcontact-spinner").addClass('d-none')
                            $("#listingAuthorContctBtn").removeClass('custom-opacity')
                            $("#listingAuthorContctBtn").attr('disabled', false);
                            $("#listingAuthorContctBtn").addClass('site-btn-effect')

                        }
                    }
                    , error: function(response) {
                        if (response.responseJSON.errors.name) {
                            $("#listcontact-spinner").addClass('d-none')
                            $("#listingAuthorContctBtn").removeClass('custom-opacity')
                            $("#listingAuthorContctBtn").attr('disabled', false);
                            $("#listingAuthorContctBtn").addClass('site-btn-effect')

                            toastr.error(response.responseJSON.errors.name[0])

                        }

                        if (response.responseJSON.errors.email) {
                            toastr.error(response.responseJSON.errors.email[0])
                            $("#listcontact-spinner").addClass('d-none')
                            $("#listingAuthorContctBtn").removeClass('custom-opacity')
                            $("#listingAuthorContctBtn").attr('disabled', false);
                            $("#listingAuthorContctBtn").addClass('site-btn-effect')

                        }

                        if (response.responseJSON.errors.phone) {
                            toastr.error(response.responseJSON.errors.phone[0])
                            $("#listcontact-spinner").addClass('d-none')
                            $("#listingAuthorContctBtn").removeClass('custom-opacity')
                            $("#listingAuthorContctBtn").attr('disabled', false);
                            $("#listingAuthorContctBtn").addClass('site-btn-effect')
                        }

                        if (response.responseJSON.errors.subject) {
                            toastr.error(response.responseJSON.errors.subject[0])
                            $("#listcontact-spinner").addClass('d-none')
                            $("#listingAuthorContctBtn").removeClass('custom-opacity')
                            $("#listingAuthorContctBtn").attr('disabled', false);
                            $("#listingAuthorContctBtn").addClass('site-btn-effect')
                        }

                        if (response.responseJSON.errors.message) {
                            toastr.error(response.responseJSON.errors.message[0])
                            $("#listcontact-spinner").addClass('d-none')
                            $("#listingAuthorContctBtn").removeClass('custom-opacity')
                            $("#listingAuthorContctBtn").attr('disabled', false);
                            $("#listingAuthorContctBtn").addClass('site-btn-effect')
                        } else {
                            toastr.error(
                                'Please Complete the recaptcha to submit the form')
                            $("#listcontact-spinner").addClass('d-none')
                            $("#listingAuthorContctBtn").removeClass('custom-opacity')
                            $("#listingAuthorContctBtn").attr('disabled', false);
                            $("#listingAuthorContctBtn").addClass('site-btn-effect')
                        }

                        if (response.responseJSON.errors.g - recaptcha) {
                            toastr.error(
                                'Please Complete the recaptcha to submit the form')
                            $("#listcontact-spinner").addClass('d-none')
                            $("#listingAuthorContctBtn").removeClass('custom-opacity')
                            $("#listingAuthorContctBtn").attr('disabled', false);
                            $("#listingAuthorContctBtn").addClass('site-btn-effect')
                        }


                    }

                });


            })
        });

    })(jQuery);


    function serviceReview(rating) {

        $("#service_rating").val(rating);
        $(".service_rat").each(function() {
            var service_rat = $(this).data('service_rating')
            if (service_rat > rating) {
                $(this).removeClass('fas fa-star').addClass('fal fa-star');
            } else {
                $(this).removeClass('fal fa-star').addClass('fas fa-star');
            }
        })

        var service_rating = $("#service_rating").val();
        var location_rating = $("#location_rating").val();
        var money_rating = $("#money_rating").val();
        var clean_rating = $("#clean_rating").val();
        var avg = (service_rating * 1) + (location_rating * 1) + (money_rating * 1) + (clean_rating * 1);
        avg = avg / 4;
        $("#avarage_rating").val(avg);
        $("#avg_rating").text(avg)
    }

    function locationReview(rating) {

        $("#location_rating").val(rating);
        $(".location_rat").each(function() {
            var location_rat = $(this).data('location_rating')
            if (location_rat > rating) {
                $(this).removeClass('fas fa-star').addClass('fal fa-star');
            } else {
                $(this).removeClass('fal fa-star').addClass('fas fa-star');
            }

        })


        var service_rating = $("#service_rating").val();
        var location_rating = $("#location_rating").val();
        var money_rating = $("#money_rating").val();
        var clean_rating = $("#clean_rating").val();
        var avg = (service_rating * 1) + (location_rating * 1) + (money_rating * 1) + (clean_rating * 1);
        avg = avg / 4;
        $("#avarage_rating").val(avg);
        $("#avg_rating").text(avg)

    }

    function moneyReview(rating) {
        $("#money_rating").val(rating);
        $(".money_rat").each(function() {
            var money_rat = $(this).data('money_rating')
            if (money_rat > rating) {
                $(this).removeClass('fas fa-star').addClass('fal fa-star');
            } else {
                $(this).removeClass('fal fa-star').addClass('fas fa-star');
            }

        })

        var service_rating = $("#service_rating").val();
        var location_rating = $("#location_rating").val();
        var money_rating = $("#money_rating").val();
        var clean_rating = $("#clean_rating").val();
        var avg = (service_rating * 1) + (location_rating * 1) + (money_rating * 1) + (clean_rating * 1);
        avg = avg / 4;
        $("#avarage_rating").val(avg);
        $("#avg_rating").text(avg)

    }

    function cleanReview(rating) {

        $("#clean_rating").val(rating);
        $(".clean_rat").each(function() {
            var clean_rat = $(this).data('clean_rating')
            if (clean_rat > rating) {
                $(this).removeClass('fas fa-star').addClass('fal fa-star');
            } else {
                $(this).removeClass('fal fa-star').addClass('fas fa-star');
            }

        })
        var service_rating = $("#service_rating").val();
        var location_rating = $("#location_rating").val();
        var money_rating = $("#money_rating").val();
        var clean_rating = $("#clean_rating").val();
        var avg = (service_rating * 1) + (location_rating * 1) + (money_rating * 1) + (clean_rating * 1);
        avg = avg / 4;
        $("#avarage_rating").val(avg);
        $("#avg_rating").text(avg)
    }

</script>


<script type="text/javascript">
    $(document).ready(function() {
        $('.pan_number').change(function (event) { 
             
            var regExp = /[a-zA-z]{5}\d{4}[a-zA-Z]{1}/; 
            var txtpan = $(this).val().toUpperCase(); 
            var txtpanlengh = txtpan.length;
            if (txtpan.length == 10 ) { 
            if( txtpan.match(regExp) ){ 
               $('#pan').val(txtpan)
            }
            else {
            toastr.error("PAN number Not a valid ");
            event.preventDefault(); 
            } 
            } 
            else { 
             toastr.error("Please enter 10 digits for a valid PAN number ");
                event.preventDefault(); 
            } 

            });






    });

</script>
 {{-- <script>
    $("#newLocation").click(function(){
        if($dsata){
            alert("you have already particiapted")
        }
    })
    
</script>  --}}
<style>
.wsus__single_details .featurestyle  li a {
    margin: 10px;
}
</style>
@endsection

