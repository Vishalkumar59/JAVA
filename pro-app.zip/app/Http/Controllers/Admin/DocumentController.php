<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\ManageText;

class DocumentController extends Controller
{


    public function __construct()
    {
        $this->middleware('auth:admin');

    }

    public function index(){
       
    }


    public function document(){
        $websiteLang=ManageText::all();
        return view('admin.document.create' ,compact('websiteLang'));
    }

   

    public function show($id){
       

    }

    
    public function destroy($id){


    }


}
