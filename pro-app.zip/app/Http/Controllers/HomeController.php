<?php

namespace App\Http\Controllers;

use DB;
use Str;
use Auth;
use File;
use Mail;
use Schema;
use App\Day;
use App\Faq;
use Session;
use Storage;
use App\Bank;
use App\Blog;
use App\City;
use App\User;
use App\About;
use App\Admin;
use App\Order;
use App\Slider;
use App\Aminity;
use App\Listing;
use App\Package;
use App\Partner;
use App\SeoText;
use App\Service;
use App\Setting;
use App\Locality;
use App\Location;
use App\Overview;
use App\Property;
use App\Razorpay;
use App\Wishlist;
use App\ContactUs;
use App\Subscribe;
use App\BankDetail;
use App\CustomPage;
use App\ManageText;
use App\Navigation;
use App\BannerImage;
use App\BlogComment;
use App\HomeSection;
use App\KycDocument;
use App\Testimonial;
use App\Transaction;
use App\AboutSection;
use App\BlogCategory;
use App\PropertyType;
use App\EmailTemplate;
use App\ListingReview;
use App\PrivacyPolicy;
use App\Rules\Captcha;
use App\PropertyReview;
use App\ValidationText;
use App\CustomPaginator;
use App\PropertyAminity;
use App\ConditionPrivacy;
use App\NotificationText;
use App\PropertyCategory;
use App\ContactInformation;
use App\Helpers\MailHelper;
use App\UserEnquiryDetails;
use Illuminate\Http\Request;
use App\Import\PropertyImport;
use App\Mail\EnquiryConfirmation;

use Illuminate\Pagination\Paginator;
use Maatwebsite\Excel\Facades\Excel;

use App\Mail\SubscribeUsNotification;


class HomeController extends Controller
{

    public function index(){
        $sliders =Slider::orderBy('id','asc')->where('status',1)->get();
        $aboutUs = About::first();
        $overviews=Overview::where('status',1)->get();
        $properties=Property::where('status',1)->get();
        // $onlyproperty =Property::where('status',1)->where('top_property',1)->where('category_id',1)->where('property_type_id','!=',3)->get();


        
        $onlyproperty =Property::whereHas('propertyType',function ($query) {
            $query->where('status','=',1);
        })->where('status',1)->where('top_property',1)->where('category_id',1)->where('property_type_id','!=',3)->get();



        $onlyvehicle =Property::whereHas('propertyType',function ($query) {
            $query->where('status','=',1);
        })->where('status',1)->where('top_property',1)->where('category_id',2)->where('property_type_id','!=',3)->get();
      
        $featureproperty =Property::where('status',1)->where('is_featured',1)->where('category_id',1)->where('property_type_id','!=',3)->get();
        $featurevehicle =Property::where('status',1)->where('is_featured',1)->where('category_id',2)->where('property_type_id','!=',3)->get();
        $sections=HomeSection::all();
        $services=Service::where('status',1)->get();
        $currency=Setting::first();
        $seo_text=SeoText::find(1);
        $service_bg=BannerImage::find(23);
        $agents=User::where('status',1)->where('user_type',2)->orderBy('id','desc')->get();
        $orders=Order::where('status',1)->get();
        $blogs=Blog::where(['status'=>1,'show_homepage'=>1])->get();
        $default_profile_image=BannerImage::find(15);
        $testimonials=Testimonial::where('status',1)->get();
        $propertyTypes=PropertyType::where('status',1)->orderBy('type','asc')->get();
        $cities=City::where('status',1)->orderBy('name','asc')->get();
        $feature_image=BannerImage::find(23);
        $testimonial_bg=BannerImage::find(25);
        $agent_bg=BannerImage::find(26);
        $websiteLang=ManageText::all();
        $banklist = Bank::where('status' , 1)->get();

        return view('user.index',compact('onlyproperty','featureproperty','featurevehicle','onlyvehicle','sliders', 'aboutUs',     'blogs','seo_text','sections','currency','overviews','services','default_profile_image','testimonials','properties','agents','orders','feature_image','propertyTypes','cities','websiteLang','testimonial_bg','agent_bg','service_bg','banklist'));
    }

    public function aboutUs(){
        $about=About::first();
        $banner_image=BannerImage::find(2);
        $overviews=Overview::where('status',1)->get();
        $partners=Partner::where('status',1)->get();
        $sections=AboutSection::all();
        $seo_text=SeoText::find(3);
        $menus=Navigation::all();
        $websiteLang=ManageText::all();
        return view('user.about-us',compact('about','banner_image','overviews','partners','sections','seo_text','menus','websiteLang'));
    }


    public function blog(){
        Paginator::useBootstrap();
        $banner_image=BannerImage::find(5);
        $paginator=CustomPaginator::where('id',1)->first()->qty;
        $blogs=Blog::where('status',1)->orderBy('id','desc')->paginate($paginator);
        $seo_text=SeoText::find(6);
        $menus=Navigation::all();
        $websiteLang=ManageText::all();
        return view('user.blog.index',compact('banner_image','blogs','seo_text','menus','websiteLang'));
    }

    public function blogDetails($slug){

        $blog=Blog::where(['slug'=>$slug,'status'=>1])->first();
        if($blog){
            $blog->view +=1;
            $blog->save();

            $blogCategories=BlogCategory::where('status',1)->get();
            $popularBlogs=Blog::where('id','!=',$blog->id)->orderBy('view','desc')->get()->take(4);
            $commentSetting=Setting::first();
            $banner_image=BannerImage::find(5);
            $menus=Navigation::all();
            $default_profile_image=BannerImage::find(15);
            $websiteLang=ManageText::all();
            $blogComments = BlogComment::where(['blog_id' => $blog->id, 'status' => 1])->paginate(10);
            return view('user.blog.show',compact('blog','blogCategories','popularBlogs','commentSetting','banner_image','menus','default_profile_image','websiteLang','blogComments'));
        }else{
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
            $notification=array('messege'=>$notification,'alert-type'=>'error');

            return back()->with($notification);
        }

    }


    public function blogCategory($slug,Request $request){
        Paginator::useBootstrap();
        $category=BlogCategory::where(['slug'=>$slug,'status'=>1])->first();
        if(!$category){
            return back();
        }

        $paginator=CustomPaginator::where('id',1)->first()->qty;
        $blogs=Blog::where(['blog_category_id'=>$category->id,'status'=>1])->paginate($paginator);
        $blogs=$blogs->appends($request->all());
        $banner_image=BannerImage::find(5);
        $seo_text=SeoText::find(6);
        $menus=Navigation::all();
        $websiteLang=ManageText::all();
        return view('user.blog.index',compact('blogs','banner_image','menus','seo_text','websiteLang'));
    }

    public function blogSearch(Request $request){
        Paginator::useBootstrap();
        $rules = [
            'search'=>'required',
        ];


        $this->validate($request, $rules);
        $paginator=CustomPaginator::where('id',1)->first()->qty;
        $blogs=Blog::where('title','LIKE','%'.$request->search.'%')->paginate($paginator);
        $blogs=$blogs->appends($request->all());
        $seo_text=SeoText::find(6);
        $banner_image=BannerImage::find(5);
        $menus=Navigation::all();
        $websiteLang=ManageText::all();
        return view('user.blog.index',compact('blogs','seo_text','banner_image','menus','websiteLang'));
    }

    public function blogComment(Request $request,$blogId){
        
        $valid_lang=ValidationText::all();
        $rules = [
            'name'=>'required',
            'email'=>'required|email',
            'comment'=>'required',
            'g-recaptcha-response'=>new Captcha()
        ];
        $customMessages = [
            'name.required' => $valid_lang->where('lang_key','name')->first()->custom_text,
            'email.required' => $valid_lang->where('lang_key','email')->first()->custom_text,
            'comment.required' => $valid_lang->where('lang_key','comment')->first()->custom_text,
        ];
        $this->validate($request, $rules, $customMessages);

        $comment=new BlogComment();
        $comment->blog_id=$blogId;
        $comment->name=$request->name;
        $comment->email=$request->email;
        $comment->comment=$request->comment;
        $comment->save();


        $notification=array(
            'messege'=>'Commented Successufully',
            'alert-type'=>'success'
        );

        return back()->with($notification);
    }

    public function faq(){
        $faqs=Faq::where('status',1)->get();
        $banner_image=BannerImage::find(19);
        $faq_image=BannerImage::find(20);

        $seo_text=SeoText::find(8);
        $menus=Navigation::all();

        return view('user.faq',compact('banner_image','faqs','faq_image','seo_text','menus'));

    }


    public function contactUs(){
        $contact=ContactInformation::first();
        $contactSetting=Setting::first();
        $seo_text=SeoText::find(7);
        $banner_image=BannerImage::find(6);
        $menus=Navigation::all();
        $websiteLang=ManageText::all();
        return view('user.contact-us',compact('contact','contactSetting','seo_text','banner_image','menus','websiteLang'));
    }


    public function termsCondition(){
        $termsCondtion=ConditionPrivacy::first();
        $banner_image=BannerImage::find(9);
        $menus=Navigation::all();

        return view('user.terms-condition',compact('termsCondtion','banner_image','menus'));
    }



    public function privacyPolicy(){
        $privacy = PrivacyPolicy::first();
        $banner_image=BannerImage::find(10);
        $menus=Navigation::all();
        return view('user.privacy-policy',compact('privacy','banner_image','menus'));
    }



    // manage subsciber
    public function subscribeUs(Request $request){
        $valid_lang=ValidationText::all();
        $rules = [
            'email'=>'required|email',
        ];
        $customMessages = [
            'email.required' => $valid_lang->where('lang_key','email')->first()->custom_text
        ];
        $this->validate($request, $rules, $customMessages);


        $isSubsriber=Subscribe::where('email',$request->email)->count();
        if($isSubsriber ==0){
            $subscribe=Subscribe::create([
                'email'=>$request->email,
                'verify_token'=>Str::random(25)
            ]);

            MailHelper::setMailConfig();

            $template=EmailTemplate::where('id',4)->first();
            $message=$template->description;
            $subject=$template->subject;
            Mail::to($subscribe->email)->send(new SubscribeUsNotification($subscribe,$message,$subject));

            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','subscribe')->first()->custom_text;
            return response()->json(['success'=>$notification]);
        }else{
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','already_subscribe')->first()->custom_text;
            return response()->json(['error'=>$notification]);
        }

    }

    public function subscriptionVerify($token){
        $subscribe=Subscribe::where('verify_token',$token)->first();
        if($subscribe){
            $subscribe->status=1;
            $subscribe->verify_token=null;
            $subscribe->save();

            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','verified')->first()->custom_text;
            $notification=array('messege'=>$notification,'alert-type'=>'success');

            return redirect()->to('/')->with($notification);
        }else{
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','invalid_token')->first()->custom_text;
            $notification=array('messege'=>$notification,'alert-type'=>'error');

            return redirect()->to('/')->with($notification);
        }
    }


    public function customPage($slug){
        $page=CustomPage::where('slug',$slug)->first();
        if(!$page){
            return back();
        }
        $banner_image=BannerImage::find(17);
        $menus=Navigation::all();
        return view('user.custom-page',compact('page','banner_image','menus'));
    }


    public function agent(){
        Paginator::useBootstrap();
        $banner_image=BannerImage::find(21);
        $paginate_qty=CustomPaginator::where('id',3)->first()->qty;
        $agents=User::where('status',1)->orderBy('id','desc')->paginate($paginate_qty);
        $orders=Order::where(['status'=>1])->get();
        $default_profile_image=BannerImage::find(15);
        $seo_text=SeoText::find(5);
        $menus=Navigation::all();
        $websiteLang=ManageText::all();
        return view('user.agent.index',compact('banner_image','menus','agents','orders','default_profile_image','seo_text','websiteLang'));
    }

    public function agentDetails(Request $request){
        
        Paginator::useBootstrap();
        $user_type='';
        if(!$request->user_type){
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
            $notification=array('messege'=>$notification,'alert-type'=>'error');
            return redirect()->route('home')->with($notification);
        }else{
            $user_type=$request->user_type;
        }


        if($user_type ==1 || $user_type ==2){
            if($request->user_name){
                if($user_type==1){

                    $user=Admin::where(['status'=>1,'slug'=>$request->user_name])->first();
                    if(!$user){
                        $notify_lang=NotificationText::all();
                        $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
                        $notification=array('messege'=>$notification,'alert-type'=>'error');
                        return redirect()->route('home')->with($notification);
                    }

                    $paginate_qty=CustomPaginator::where('id',2)->first()->qty;
                    $banner_image=BannerImage::find(1);
                    $default_image=BannerImage::find(18);
                    $menus=Navigation::all();
                    $currency=Setting::first();
                    $setting=Setting::first();
                    $properties=Property::whereHas('propertyType',function ($query) {
                        $query->where('status','=',1);
                    })->where(['status'=>1,'admin_id'=>$user->id])->paginate($paginate_qty);
                    $popluarProperties=Property::whereHas('propertyType',function ($query) {
                        $query->where('status','=',1);
                    })->where('status',1)->orderBy('views','desc')->get();
                    $properties=$properties->appends($request->all());

                    $default_profile_image=BannerImage::find(15);
                    $websiteLang=ManageText::all();
                    return view('user.agent.show',compact('properties','banner_image','default_image','menus','currency','user','setting','user_type','popluarProperties','default_profile_image','websiteLang'));

                }else{
                    $user=User::where(['status'=>1,'slug'=>$request->user_name])->first();
                    if(!$user){
                        $notify_lang=NotificationText::all();
                        $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
                        $notification=array('messege'=>$notification,'alert-type'=>'error');
                        return redirect()->route('home')->with($notification);
                    }

                    $paginate_qty=CustomPaginator::where('id',2)->first()->qty;
                    $banner_image=BannerImage::find(18);
                    $default_image=BannerImage::find(15);
                    $menus=Navigation::all();
                    $currency=Setting::first();
                    $setting=Setting::first();
                    $properties=Property::whereHas('propertyType',function ($query) {
                        $query->where('status','=',1);
                    })->where(['status'=>1,'user_id'=>$user->id])->paginate($paginate_qty);
                    $properties=$properties->appends($request->all());
                    $popluarProperties=Property::whereHas('propertyType',function ($query) {
                        $query->where('status','=',1);
                    })->where('status',1)->orderBy('views','desc')->get();
                    $default_profile_image=BannerImage::find(15);
                    $websiteLang=ManageText::all();
                    return view('user.agent.show',compact('properties','banner_image','default_image','menus','currency','user','setting','user_type','popluarProperties','default_profile_image','websiteLang'));
                }
            }else{
                $notify_lang=NotificationText::all();
                $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
                $notification=array('messege'=>$notification,'alert-type'=>'error');
                return redirect()->route('home')->with($notification);
            }
        }else{
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
            $notification=array('messege'=>$notification,'alert-type'=>'error');
            return redirect()->route('home')->with($notification);
        }
    }



    public function pricingPlan(){
        $packages=Package::where('status',1)->orderBy('package_order','asc')->get();
        $seo_text=SeoText::find(4);
        $banner_image=BannerImage::find(3);
        $menus=Navigation::all();
        $currency=Setting::first();
        $websiteLang=ManageText::all();
        return view('user.price-plan',compact('packages','seo_text','banner_image','menus','currency','websiteLang'));
    }


    public function properties(Request $request){
       
        Paginator::useBootstrap();
        // cheack page type, page type means grid view or listing view
        $page_type='';
        if(!$request->page_type){
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
            $notification=array('messege'=>$notification,'alert-type'=>'error');
            return redirect()->route('home')->with($notification);
        }else{
            if($request->page_type=='list_view'){
                $page_type=$request->page_type;
            }else if($request->page_type=='grid_view'){
                $page_type=$request->page_type;
            }else{
                $notify_lang=NotificationText::all();
                $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
                $notification=array('messege'=>$notification,'alert-type'=>'error');
                return redirect()->route('home')->with($notification);
            }
        }
        // end page type


        $paginate_qty=CustomPaginator::where('id',2)->first()->qty;
        // dd($paginate_qty);
        if(isset($request->type_id)){
            $where_case = ['category_id'=> 1, 'property_type_id'=> $request->type_id];
        } else{
            $where_case = ['category_id'=> 1];
        }


        if($request->sorting_id){
            $id=$request->sorting_id;
            if($id==1){
                $properties=Property::where($where_case)->where('status',1)->orderBy('id','desc')->paginate($paginate_qty);
            }else if($id==2){
                $properties=Property::where($where_case)->where('status',1)->orderBy('views','desc')->paginate($paginate_qty);
            }else if($id==3){
                $properties=Property::where($where_case)->where(['is_featured'=>1,'status'=>1])->orderBy('id','desc')->paginate($paginate_qty);
            }else if($id==4){
                $properties=Property::where($where_case)->where(['top_property'=>1,'status'=>1])->orderBy('id','desc')->paginate($paginate_qty);
            }else if($id==5){
                $properties=Property::where($where_case)->where(['status'=>1])->orderBy('id','desc')->paginate($paginate_qty);
            }else if($id==6){
                $properties=Property::where($where_case)->where(['urgent_property'=>1,'status'=>1])->orderBy('id','desc')->paginate($paginate_qty);
            }else if($id==7){
                $properties=Property::where($where_case)->where(['status'=>1])->orderBy('id','asc')->paginate($paginate_qty);
            }
        }else{
            $properties=Property::whereHas('propertyType',function ($query) {
                $query->where('status','=',1);
            })->where($where_case)->where('status',1)->orderBy('id','desc')->paginate($paginate_qty);
           
        }

        // if(isset($request->type_id))
        //     $properties=$properties->where('property_type_id',$request->type_id);

        $properties=$properties->appends($request->all());
       

        $banner_image=BannerImage::find(1);
        $default_image=BannerImage::find(15);
        $menus=Navigation::all();
        $currency=Setting::first();
        $seo_text=SeoText::find(2);
        $propertyTypes=PropertyType::where('status',1)->orderBy('type','asc')->get();
        $cities=City::where('status',1)->orderBy('name','asc')->get();
        $aminities=Aminity::where('category_id',1)->where('status',1)->orderBy('aminity','asc')->get();
        $propertylist = Property::all();
        $websiteLang=ManageText::all();
        $banklist = Bank::where('status' , 1)->get();
        $propertyCategoty = PropertyCategory::all();
        $locality = Locality::all();

        $maxpropertylist = Property::max('price');
        $minpropertylist = Property::min('price');
       
        
        

        return view('user.property.index',compact('where_case','locality','properties','banner_image','default_image','menus','currency','page_type','seo_text','propertyTypes','cities','aminities','websiteLang','propertylist','banklist','propertyCategoty','maxpropertylist','minpropertylist'));
    }


    public function allProperties(Request $request){
        Paginator::useBootstrap();
        // cheack page type, page type means grid view or listing view
       
        $menus=Navigation::all();
        $properties = Property::where('category_id' , 1)->where('property_enquiry' , 'auction')->paginate(10);
        $own_properties = Property::where('category_id' , 1)->where('property_enquiry' , 'own')->paginate(10);
        $citylist = City::where('status' , 1)->get();
        $property_type_list = PropertyType::where('status' , 1)->get();
        $banner_image=BannerImage::find(1);
        $websiteLang=ManageText::all();
        $kyclist = UserEnquiryDetails::all();
         $seo_text=SeoText::find(2);
        return view('user.property.all-property' , compact ('seo_text','properties','own_properties','citylist','property_type_list','menus','banner_image','websiteLang','kyclist'));
    }

  
    public function propAuction(Request $request){
        Paginator::useBootstrap();
        // cheack page type, page type means grid view or listing view
       
        $properties = Property::where('property_enquiry' ,$request->page_type)->paginate(10);

        $menus=Navigation::all();
        $citylist = City::where('status' , 1)->get();
        $property_type_list = PropertyType::where('status' , 1)->get();
        $banner_image=BannerImage::find(1);
        $websiteLang=ManageText::all();
        $kyclist = UserEnquiryDetails::all();
        $seo_text=SeoText::find(2);

        return view('user.property.all-property' , compact ('seo_text','properties','citylist','property_type_list','menus','banner_image','websiteLang','kyclist'));
    }

    public function propOwn(Request $request){
        Paginator::useBootstrap();
        // cheack page type, page type means grid view or listing view
       
        $properties = Property::where('property_enquiry' ,$request->page_type)->paginate(10);
       
        $menus=Navigation::all();
        $citylist = City::where('status' , 1)->get();
        $property_type_list = PropertyType::where('status' , 1)->get();
        $banner_image=BannerImage::find(1);
        $websiteLang=ManageText::all();
        $kyclist = UserEnquiryDetails::all();
        $seo_text=SeoText::find(2);

        return view('user.property.all-property' , compact ('seo_text','properties','citylist','property_type_list','menus','banner_image','websiteLang','kyclist'));
    }

    public function propertyTableSearch(Request $request){
        
        if($request->filterByCity){
            $filterByCity=Property::with('bank','city')->where('city_id' , $request->filterByCity)->where('category_id' , 1)->where('property_enquiry' , 'auction')->get();

        }    

        if($request->proptype){
            $filterByCity = Property::with('bank','city')->where('property_type_id' , $request->proptype)->where('category_id' , 1)->where('property_enquiry' , 'auction')->get();
        }

        $minprice = $request->pricefrom;
        $maxprice = $request->priceto;

        if($minprice != null && $maxprice != null){
            $filterByCity = Property::with('bank','city')->whereBetween('price', [(int)$minprice, (int)$maxprice])->where('category_id' , 1)->where('property_enquiry' , 'auction')->get();
        }

        if($minprice){
            $filterByCity = Property::with('bank','city')->where('price', '>=',(int)$minprice)->where('category_id' , 1)->where('property_enquiry' , 'auction')->get();
        }

        if($maxprice){
            $filterByCity = Property::with('bank','city')->where('price', '<=', (int)$maxprice)->where('category_id' , 1)->where('property_enquiry' , 'auction')->get();
        }
        
        if($request->property_search){
            $filterByCity = Property::with('bank','city')->where('title', 'like', '%' . $request->property_search. '%')->orWhere('price', 'like', '%' . $request->property_search. '%')->orWhere('emd_amount', 'like', '%' . $request->property_search. '%')->orWhere('property_unique_id', 'like', '%' . $request->property_search. '%')->where('category_id' , 1)->where('property_enquiry' , 'auction')->get();
        }

        $data['filterByCity']=$filterByCity;

        return response()->json($data);

    }


    public function propertyNonAuctionTableSearch(Request $request){
         
        if($request->filterByCity){
            $filterByCity=Property::with('bank','city')->where('city_id' , $request->filterByCity)->where('category_id' , 1)->where('property_enquiry' , 'own')->get();
        }    

        if($request->proptype){
            $filterByCity = Property::with('bank','city')->where('property_type_id' , $request->proptype)->where('category_id' , 1)->where('property_enquiry' , 'own')->get();
        }

        $minprice = $request->pricefrom;
        $maxprice = $request->priceto;

        if($minprice != null && $maxprice != null){
            $filterByCity = Property::with('bank','city')->whereBetween('price', [(int)$minprice, (int)$maxprice])->where('category_id' , 1)->where('property_enquiry' , 'own')->get();
        }

        if($minprice){
            $filterByCity = Property::with('bank','city')->where('price', '>=',(int)$minprice)->where('category_id' , 1)->where('property_enquiry' , 'own')->get();
        }

        if($maxprice){
            $filterByCity = Property::with('bank','city')->where('price', '<=', (int)$maxprice)->where('category_id' , 1)->where('property_enquiry' , 'own')->get();
        }
        
        if($request->property_search){
            $filterByCity = Property::with('bank','city')->where('title', 'like', '%' . $request->property_search. '%')->orWhere('price', 'like', '%' . $request->property_search. '%')->orWhere('emd_amount', 'like', '%' . $request->property_search. '%')->orWhere('property_unique_id', 'like', '%' . $request->property_search. '%')->where('category_id' , 1)->where('property_enquiry' , 'own')->get();
        }

        $data['filterByCity']=$filterByCity;

        return response()->json($data);
    }
   

    public function vehicles(Request $request)
    {
       
        
        Paginator::useBootstrap();
        // cheack page type, page type means grid view or listing view
        $page_type='';
        if(!$request->page_type){
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
            $notification=array('messege'=>$notification,'alert-type'=>'error');
            return redirect()->route('home')->with($notification);
        }else{
            if($request->page_type=='list_view'){
                $page_type=$request->page_type;
            }else if($request->page_type=='grid_view'){
                $page_type=$request->page_type;
            }else{
                $notify_lang=NotificationText::all();
                $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
                $notification=array('messege'=>$notification,'alert-type'=>'error');
                return redirect()->route('home')->with($notification);
            }
        }
        // end page type


        $paginate_qty=CustomPaginator::where('id',4)->first()->qty;

        if(isset($request->type_id)){
            $where_case = ['category_id'=> 2, 'property_type_id'=> $request->type_id];
        } else{
            $where_case = ['category_id'=> 2];
        }


        if($request->sorting_id){
            $id=$request->sorting_id;
            if($id==1){
                $properties=Property::where($where_case)->where('status',1)->orderBy('id','desc')->paginate($paginate_qty);
            }else if($id==2){
                $properties=Property::where($where_case)->where('status',1)->orderBy('views','desc')->paginate($paginate_qty);
            }else if($id==3){
                $properties=Property::where($where_case)->where(['is_featured'=>1,'status'=>1])->orderBy('id','desc')->paginate($paginate_qty);
            }else if($id==4){
                $properties=Property::where($where_case)->where(['top_property'=>1,'status'=>1])->orderBy('id','desc')->paginate($paginate_qty);
            }else if($id==5){
                $properties=Property::where($where_case)->where(['status'=>1])->orderBy('id','desc')->paginate($paginate_qty);
            }else if($id==6){
                $properties=Property::where($where_case)->where(['urgent_property'=>1,'status'=>1])->orderBy('id','desc')->paginate($paginate_qty);
            }else if($id==7){
                $properties=Property::where($where_case)->where(['status'=>1])->orderBy('id','asc')->paginate($paginate_qty);
            }
        }else{
            $properties=Property::whereHas('propertyType',function ($query) {
                $query->where('status','=',1);
            })->where($where_case)->where('status',1)->orderBy('id','desc')->paginate($paginate_qty);
        }



        $properties=$properties->appends($request->all());
        

        $banner_image=BannerImage::find(1);
        $default_image=BannerImage::find(15);
        $menus=Navigation::all();
        $currency=Setting::first();
        $seo_text=SeoText::find(10);
        $propertyTypes=PropertyType::where('status',1)->orderBy('type','asc')->get();
        $cities=City::where('status',1)->orderBy('name','asc')->get();
        $vehicle_name = Property::first();
        $aminities=Aminity::where('status',1)->orderBy('aminity','asc')->get();
        $propertylist = Property::where('status',1)->get();
        $websiteLang=ManageText::all();
        $banklist = Bank::where('status',1)->get();
        $locality = Locality::all();
        $propertyCategoty = PropertyCategory::where('status',1)->get();
        $searchkey = request(['bank','price','finance'],[]);
        return view('user.property.vehicle',compact('where_case','locality','propertyCategoty','vehicle_name','properties','banner_image','default_image','menus','currency','page_type','seo_text','propertyTypes','cities','aminities','websiteLang','propertylist','banklist','searchkey'));
    }



    public function downloadListingFile($file){
        $filepath= public_path() . "/uploads/custom-images/".$file;
        return response()->download($filepath);
    }

    public function propertDetails($slug){
        $property=Property::where(['status'=>1,'slug'=>$slug])->first();
        Session::put('getprice',$property->emd_amount);
        Session::put('commission',$property->commission);
        if($property){

            $isExpired=false;
            if($property->expired_date==null){
                $isExpired=false;
            }else if($property->expired_date >= date('Y-m-d')){
                $isExpired=false;
            }else{
                $isExpired=true;
            }
            if($isExpired){
                $notify_lang=NotificationText::all();
                $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
                $notification=array('messege'=>$notification,'alert-type'=>'error');
                return redirect()->back()->with($notification);
            }

            $property->views=$property->views +1;
            $property->save();
            $similarProperties=Property::where(['status'=>1,'property_type_id'=>$property->property_type_id])->where('id', '!=',$property->id)->get()->take(3);
            $banner_image=BannerImage::find(1);
            $default_image=BannerImage::find(15);
            $menus=Navigation::all();
            $currency=Setting::first();
            $setting=Setting::first();
            $websiteLang=ManageText::all();
            $userkyc = KycDocument::all();
            $propertyReviews = PropertyReview::where(['property_id' => $property->id, 'status' => 1])->paginate(10);
            $kyclist = KycDocument::all();
            $enqlist = UserEnquiryDetails::all();



            return view('user.property.show',compact('property','banner_image','default_image','menus','currency','setting','similarProperties','websiteLang','propertyReviews','userkyc','kyclist','enqlist'));
        }else{
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
            $notification=array('messege'=>$notification,'alert-type'=>'error');
            return redirect()->back()->with($notification);
        }
    }




    public function searchPropertyPage(Request $request){
      
      
        Paginator::useBootstrap();

      
        // check page type, page type means grid view or list view
        $page_type='';
        if(!$request->page_type){
            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
            $notification=array('messege'=>$notification,'alert-type'=>'error');
            return redirect()->route('home')->with($notification);
        }else{
            if($request->page_type=='list_view'){
                $page_type=$request->page_type;
            }else if($request->page_type=='grid_view'){
                $page_type=$request->page_type;
            }else{
                $notify_lang=NotificationText::all();
                $notification=$notify_lang->where('lang_key','something')->first()->custom_text;
                $notification=array('messege'=>$notification,'alert-type'=>'error');
                return redirect()->route('home')->with($notification);
            }
        }
        // end page type
        


       
        // check aminity
        $sortArry=[];
        if($request->aminity){
            foreach($request->aminity as $amnty){
                array_push($sortArry,(int)$amnty);
            }
        }else{
            $aminities=Aminity::where('status',1)->get();
            foreach($aminities as $aminity){
                array_push($sortArry,(int)$aminity->id);
            }
            
        }

       
        // end aminity
        

        // soriting data
        $paginate_qty=CustomPaginator::where('id',2)->first()->qty;
        // check order type
        $orderBy="desc";
        $orderByView=false;
        if($request->sorting_id){
            if($request->sorting_id==7){
                $orderBy="asc";
            }else if($request->sorting_id==1){
                $orderBy="desc";
            }else if($request->sorting_id==5){
                $orderBy="desc";
            }else if($request->sorting_id==2){
                $orderBy="asc";
                $orderByView=true;
            }
        }

        // end check order type

        // $propertyAminities=Property::where('propertyAminities',function($query) use ($request){
        // // $propertyAminities=PropertyAminity::whereHas('property',function($query) use ($request){
           
        // })->whereIn('aminity_id',$sortArry)

            // $property_query =Property::wherehas('propertyAminities', function($query) use ($sortArry){

            //     $query->whereIn('aminity_id',$sortArry);

            // });
        // $allCompanies = Property::with('propertyAminities', function($q) use($request){
        //         $q->where('aminity_id',$request->aminity);
        //         })->where('city_id', $request->city)->get();
        //     dd($allCompanies);
    

        // $key_list = Property::whereHas('propertyAminities', function ($query) use ($request){
        //     $query->where('aminity_id',$request->aminity);
        // })->where(['city_id' => $request->city])->get();
        // dd($key_list);

        // $allConsultants = Consultant::whereHas('user', function($query)
        // {
        //     $query->where('is_approved', '=', 1);
        
        // })->get();


        //$property_query =Property::query();

        $property_query =  Property::query();

            if($request->property_type != null){
                $property_query->where(['property_type_id'=>$request->property_type,'status'=>1]);
            }
            if($request->location != null){
                $property_query->where(['locality'=>$request->location,'status'=>1]);
            }
            if($request->city != null){
              $property_query->where(['city_id'=>$request->city,'status'=>1]);
            
            }
            if($request->search != null){
                $property_query->where('title','LIKE','%'.$request->search.'%')->where('status',1);
            }
            if($request->purpose_type != null){
                $property_query->where(['category_id'=>$request->purpose_type,'status'=>1]);
            }

            if($request->minamount != null && $request->minamount != null){
                
                $property_query->whereBetween('price', [(int)$request->minamount, (int)$request->maxamount]);
                // $query->where('price', '>=', $request->minamount)->orWhere('price', '<=', $request->maxamount);
            }

            if($request->auction != null){
                $property_query->where(['property_enquiry'=>$request->auction , 'status'=>1]);
            }


            if($request->price != null){
                if($request->price == 1){
                    $property_query->whereBetween('price', [0 , 5000000]);
                }else if($request->price == 2){
                    $property_query->whereBetween('price', [5000000 , 10000000]);
                }else if($request->price == 2){
                    $property_query->whereBetween('price', [10000000 , 20000000]);
                }else if($request->price == 2){
                    $property_query->where('price' > 20000000);
                }
            }

            

            if($request->sorting_id){
                if($request->sorting_id==3){
                    $property_query->where(['is_featured'=>1,'status'=>1]);
                }else if($request->sorting_id==6){
                    $property_query->where(['urgent_property'=>1,'status'=>1]);
                }elseif($request->sorting_id==4){
                    $property_query->where(['top_property'=>1,'status'=>1]);
                }
            }
           
        $property_query->where(['status'=>1]);

        if($request->aminity != null){
        $property_query->WhereHas('propertyAminities', function ($query) use($request) {
            $query->where('aminity_id',$request->aminity);
         });
        }

        $propertyAminities = $property_query->select('*')
        ->orderBy('id',$orderBy)
        ->paginate($paginate_qty);
 


        // end query, sorting

        $propertyAminities=$propertyAminities->appends($request->all());


        $aminities=Aminity::where('status',1)->orderBy('aminity','asc')->get();
        $banner_image=BannerImage::find(1);
        $default_image=BannerImage::find(15);
        $menus=Navigation::all();
        $currency=Setting::first();
        $seo_text=SeoText::find(2);
        $propertyTypes=PropertyType::where('status',1)->orderBy('type','asc')->get();
        $cities=City::where('status',1)->orderBy('name','asc')->get();
        $websiteLang=ManageText::all();
        $propertylist = Property::all();
        $locality = Locality::all();
        $banklist = Bank::where('status' , 1)->get();
        $searchkey = request(['bank','price','finance'], []);
        $maxpropertylist = Property::max('price');
        $minpropertylist = Property::min('price');
        $propertydata=Locality::where('city_id', $request->city)->get();
        

  


        return view('user.property.search',compact('propertydata','locality','propertyAminities','aminities','seo_text','banner_image','menus','page_type','currency','propertyTypes','cities','websiteLang','propertylist','banklist','searchkey','maxpropertylist','minpropertylist'));
    }



    public function property(Request $request)
    {

        $property_id = $request->property_category_id;

        $status=PropertyType::where('status', 1)->orderBy('type','asc')->get();
        
        if($property_id == '1' && $status) {
            $propertyTypes=PropertyType::where('category_id', 1)->orderBy('type','asc')->get();
            $data['propertyTypes']=$propertyTypes;
        } else if($property_id == '2' && $status){
            $propertyTypes=PropertyType::where('category_id', 2)->orderBy('type','asc')->get();
            $data['propertyTypes']=$propertyTypes;
        }else{
            $propertyTypes=PropertyType::all();
            $data['propertyTypes']=$propertyTypes;
        }

        return response()->json($data);
    }


    public function getcity(Request $request){

        $location = $request->location;

        $propertydata=Property::where('city_id', $location)->get('pincode');
        $data['propertydata']=$propertydata;

        return response()->json($data);

    }
    public function getlocality(Request $request)
    {
       $locality = $request->locality_id;

        $propertydata=Locality::where('city_id', $locality)->get();
        $data['propertydata']=$propertydata;

        return response()->json($data);
    }


    public function document(){
        $websiteLang=ManageText::all();
        return view('user.create' ,compact('websiteLang'));
    }


    public function documentstore(Request $request){

  

        $request->session()->put('property_id', $request->property_id);
        $request->session()->put('agents_id', $request->agents_id);


        $valid_lang=ValidationText::all();
        $rules = [
            'name'=>'required',
            'adhar'=>'required|min:12',
            'pan_no' => 'required|unique:user_kyc_details|regex:/([A-Z]){5}([0-9]){4}([A-Z]){1}$/|min:10|max:10',
            'acountnumber' => 'required',
            'ifsc' => 'required'

        ];

        $customMessages = [
            'name' => $valid_lang->where('lang_key','name')->first()->custom_text,
            'adhar' => $valid_lang->where('lang_key','adhar')->first()->custom_text,
            'pan_no' => $valid_lang->where('lang_key','pan')->first()->custom_text,
            'acountnumber' => $valid_lang->where('lang_key','accountnumber')->first()->custom_text,
            'ifsc' => $valid_lang->where('lang_key','ifsc')->first()->custom_text,

            'adhar.min' => $valid_lang->where('lang_key','min_adhar')->first()->custom_text,
        ];

        $this->validate($request, $rules, $customMessages);

        $document=new KycDocument();
        $document->user_id = Auth::user()->id;
        $document->property_id = $request->property_id;
        $document->name = $request->name;
        $document->aadhaar_no = $request->adhar;
        $document->pan_no = $request->pan_no;
        $document->bank_account_no = $request->acountnumber;
        $document->ifsc_code = $request->ifsc;
        $document->payment_status = 0;
        $document->save();

        $request->session()->put('kyc_id', $document->id);

        $notify_lang=NotificationText::all();
        $notification=$notify_lang->where('lang_key','create')->first()->custom_text;
        $notification=array('messege'=>$notification,'alert-type'=>'success');


        // return redirect()->route('home')->with($notification);
        return redirect()->route('user.verifyauction')->with($notification);

    }

    public function enquirystore(Request $request){

        //dd($request->all());
        $user=Auth::guard('web')->user();
     
             // project demo mode check
            
             // end
     
             $request->session()->put('property_id', $request->property_id);
             $request->session()->put('agents_id', $request->agents_id);
     
     
             $valid_lang=ValidationText::all();
             $rules = [
                 'name'=>'required',
                 'email'=>'required|min:12',
                 'message' => 'required',
     
             ];
     
             $customMessages = [
                 'name' => $valid_lang->where('lang_key','name')->first()->custom_text,
                 'email' => $valid_lang->where('lang_key','email_required')->first()->custom_text,
                 'message' => $valid_lang->where('lang_key','message')->first()->custom_text,
                 
             ];
     
             $this->validate($request, $rules, $customMessages);
     
             $document=new UserEnquiryDetails();
             $document->user_id = Auth::user()->id;
             $document->property_id = $request->property_id;
             $document->name = $request->name;
             $document->email = $request->email;
             $document->message = $request->message;
             $document->save();
     
            // $request->session()->put('kyc_id', $document->id);

            $template=EmailTemplate::where('id',11)->first();
                    
            $message=$template->description;
            $subject=$template->subject;    
            $messages=str_replace('{{ user_name }}',$user->name,$message);
            Mail::to($user->email)->send(new EnquiryConfirmation($messages,$subject));

            $template=EmailTemplate::where('id',13)->first();
            $message=$template->description;
            $subject=$template->subject;
            $message=str_replace('{{ user_name }}',$user->name,$message);
                               
            $message = str_replace('{{ email }}',$user->email,$message);

            $adminlist = Admin::where('admin_type' ,1)->get();
            foreach($adminlist as $admin){
                $admin_name = $admin->email;
            }
            
            Mail::to($admin_name)->send(new EnquiryConfirmation($message,$subject));
     
             $notify_lang=NotificationText::all();
             $notification=$notify_lang->where('lang_key','send_enquiry')->first()->custom_text;
             $notification=array('messege'=>$notification,'alert-type'=>'success');
     
     
             return redirect()->back()->with($notification);
    }

    public function verifyauction()
    {
        $websiteLang=ManageText::all();
        return view('user.verifyauction',compact('websiteLang'));
    }

    public function showpaymet()
    {
        
        $razorpay=Razorpay::first();
        $currency=Setting::first(); 
        $websiteLang=ManageText::all();
        $showprice = Session::get('getprice');
        $commission = Session::get('commission');
        $bankdeails = BankDetail::all();

        return view('user.showpayment',compact('websiteLang','razorpay','currency','showprice','bankdeails','commission'));
    }

    

    public function auction(){

        Paginator::useBootstrap();
        $user=Auth::guard('web')->user();
        $orders=Order::where(['user_id'=>$user->id,'status' => 1])->orderBy('id','desc')->paginate(10);
        $currency=Setting::first();
        $websiteLang=ManageText::all();
        $properties = Property::all();
        $trancation = Transaction::where('user_id' , Auth::user()->id)->with('kycdocument')->get();

        $userEnqlist = UserEnquiryDetails::where('user_id' , Auth::user()->id)->with('property')->get();
        
        return view('user.profile.auction.index',compact('orders','currency','websiteLang','trancation','properties','userEnqlist'));
    }

    public function auctionlist(Request $request){
        
        if(!empty($request->data)){
            $userauction = Transaction::with('kycdocument','user')->where('id', $request->data)->get();
            $currency=Setting::first();
           
            foreach($userauction as $key=>$value){
               
                $prop_id = $value->kycdocument->property_id;
                $property = Property::where('id' , $prop_id)->first();
                if(!empty($property)){
                $prop_title = $property;
                }else{
                    $prop_title = [];
                }
                
            }
        }else{
            $userauction = [];
        }


        return response()->json(['userauction'=>$userauction , 'prop_title' => $prop_title,'currenry' =>$currency]);
    }

    public function auctionEnqlist(Request $request){
        
        if(!empty($request->data)){
            $currency=Setting::first();
            $userauction = UserEnquiryDetails::with('property')->where('id', $request->data)->get();
        }else{
            $userauction = [];
        }
        return response()->json(['userauction'=>$userauction,'currenry' => $currency]);
    }

    
    public function uploadProperty(Request $request)
    {       
        
        $valid_lang=ValidationText::all();
             $rules = [
                 'file'=>'required',
     
             ];
     
             $customMessages = [
                 'file' => $valid_lang->where('lang_key','file')->first()->custom_text,
                 
             ];
     
             $this->validate($request, $rules, $customMessages);

           Excel::import(new PropertyImport, $request->file);


            $notify_lang=NotificationText::all();
            $notification=$notify_lang->where('lang_key','create')->first()->custom_text;
            $notification=array('messege'=>$notification,'alert-type'=>'success');
    
            return redirect()->route('agents.my.properties')->with($notification);
    }

    public function import(){
        $websiteLang=ManageText::all();
        return view('agents.profile.import.index' , compact('websiteLang'));
    }

    public function userEnqlist(Request $request){

        if(!empty($request->data)){
            $currency=Setting::first();
            $userenquiry = Property::where('id', $request->data)->first();
        }else{
            $userauction = [];
        }
        $websiteLang=ManageText::all();

        return response()->json(['websiteLang'=>$websiteLang,'userenquiry'=>$userenquiry]);
    }

    public function allVehicles(Request $request){
        Paginator::useBootstrap();
        // cheack page type, page type means grid view or listing view
        
        $properties = Property::where('category_id' , 2)->where('property_enquiry' , 'auction')->paginate(10);
        $own_properties = Property::where('category_id' , 2)->where('property_enquiry' , 'own')->paginate(10);
        // dd($own_properties);

        $seo_text=SeoText::find(2);
        $menus=Navigation::all();
        $citylist = City::where('status' , 1)->get();
        $property_type_list = PropertyType::where('status' , 1)->get();
        $banner_image=BannerImage::find(1);
        $websiteLang=ManageText::all();
        $kyclist = UserEnquiryDetails::all();

        return view('user.property.all-vehicles' , compact ('seo_text','properties','own_properties','citylist','property_type_list','menus','banner_image','websiteLang','kyclist'));
    }

    
    public function vehiclestablesearch(Request $request){
        // dd($request->all());
        if($request->filterByCity){
            $filterByCity=Property::with('bank','city')->where('city_id' , $request->filterByCity)->where('category_id' , 2)->get();
            
        }    

        if($request->proptype){
            $filterByCity = Property::with('bank','city')->where('property_type_id' , $request->proptype)->where('category_id' , 2)->get();
        }

        $minprice = $request->pricefrom;
        $maxprice = $request->priceto;

        if($minprice != null && $maxprice != null){
            $filterByCity = Property::with('bank','city')->whereBetween('price', [(int)$minprice, (int)$maxprice])->where('category_id' , 2)->get();
        }

        if($minprice){
            $filterByCity = Property::with('bank','city')->where('price', '>=',(int)$minprice)->where('category_id' , 2)->get();
        }

        if($maxprice){
            $filterByCity = Property::with('bank','city')->where('price', '<=', (int)$maxprice)->where('category_id' , 2)->get();
        }


        if($request->property_search){
            $filterByCity = Property::with('bank','city')->where('title', 'like', '%' . $request->property_search. '%')->orWhere('price', 'like', '%' . $request->property_search. '%')->orWhere('emd_amount', 'like', '%' . $request->property_search. '%')->where('category_id' , 2)->get();
        }
        
        $data['filterByCity']=$filterByCity;
       

        return response()->json($data);

    }
    public function vehiclesNonAuctiontablesearch(Request $request){
      

        if($request->filterByCity){
            $filterByCity=Property::with('bank','city')->where('city_id' , $request->filterByCity)->where('category_id' , 2)->where('property_enquiry' , 'own')->get();
             
        }  

        if($request->proptype){
            $filterByCity = Property::with('bank','city')->where('property_type_id' , $request->proptype)->where('category_id' , 2)->get();
        }

        $minprice = $request->pricefrom;
        $maxprice = $request->priceto;

        if($minprice != null && $maxprice != null){
            $filterByCity = Property::with('bank','city')->whereBetween('price', [(int)$minprice, (int)$maxprice])->where('category_id' , 2)->get();
        }

        if($minprice){
            $filterByCity = Property::with('bank','city')->where('price', '>=',(int)$minprice)->where('category_id' , 2)->get();
        }

        if($maxprice){
            $filterByCity = Property::with('bank','city')->where('price', '<=', (int)$maxprice)->where('category_id' , 2)->get();
        }


        if($request->property_search){
            $filterByCity = Property::with('bank','city')->where('title', 'like', '%' . $request->property_search. '%')->orWhere('price', 'like', '%' . $request->property_search. '%')->orWhere('emd_amount', 'like', '%' . $request->property_search. '%')->where('category_id' , 2)->get();
        }
        
        $data['filterByCity']=$filterByCity;
       

        return response()->json($data);

    }

}