@extends('layouts.user.layout')
@section('title')
    <title>{{ $menus->where('id',12)->first()->navbar }}</title>
@endsection
@section('user-content')

<!--===BREADCRUMB PART START====-->
  <section class="wsus__breadcrumb" style="background: url({{ url($banner_image->image) }});">
    <div class="wsus_bread_overlay">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h4>{{ $menus->where('id',27)->first()->navbar }}</h4>
                    <nav style="--bs-breadcrumb-divider: '-';" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{ route('home') }}">{{ $menus->where('id',1)->first()->navbar }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">{{ $menus->where('id',27)->first()->navbar }}</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</section>
<!--===BREADCRUMB PART END====-->




<!--=======LOGON PART START=========-->
<section class="wsus__logon mt_45 mb_45">
    <div class="container">
        <div class="row justify-content-center">
            
            <div class="col-xl-5 col-md-6 offset-xl-1 ml_to_mr">
                <div class="wsus__login_form" id="reg_button">
                    <h3>Register As</h3>
                    <div class="text-center">
                   

                        <button class="common_btn w-100 individual"  attr-type="indv_reg"><i id="reg-spinner" class="loading-icon fa fa-spin fa-spinner d-none"></i> {{ $websiteLang->where('lang_key','individual')->first()->custom_text }}</button> <br><br>

                        <button class="common_btn w-100 agent" attr-type="agent_reg"><i id="reg-spinner" class="loading-icon fa fa-spin fa-spinner d-none"></i> {{ $websiteLang->where('lang_key','agent')->first()->custom_text }}</button>
                    </div> 
                  
                </div>
            </div>

            <div class="text-center" id="registration_form">
                <div class="col-xl-5 col-md-6 m-auto"  >
                    <div class="wsus__login_form">
                        <h3>{{ $websiteLang->where('lang_key','dont_have_account')->first()->custom_text }} {{ $websiteLang->where('lang_key','please_register')->first()->custom_text }}</h3>
            

                        <form  action="" id="registerFormSubmitt"  class="row g-3 needs-validation  registerform" novalidate>
                            @csrf
                            {{-- <input type="hidden" id="csrf" value="{{Session::token()}}"> --}}
                            <input type="hidden" name="reg_type" id="reg_type"/>
                            <div class="form-group">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <i class="fad fa-envelope"></i>
                                        </span>
                                    </div>
                                    <input class="form-control form-control-lg" type="email" name="email" id="regiEmail" placeholder="{{ $websiteLang->where('lang_key','enter_email1')->first()->custom_text }}" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="input-group input-group-lg">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <i class="fas fa-phone"></i>
                                        </span>
                                    </div>
                                    <input class="form-control form-control-lg" type="number" name="number" id="regNumber" placeholder="{{ $websiteLang->where('lang_key','enter_number')->first()->custom_text }}" required>
                                </div>
                            </div>
                        

                            @if($setting->allow_captcha==1)
                            <div class="form-group mt-2">
                                <div class="input-group input-group-lg">
                                    <div class="g-recaptcha" data-sitekey="{{ $setting->captcha_key }}"></div>
                                </div>
                            </div>
                            @endif

                            <button  class="common_btn" id="registerBtnn" type="submit"><i id="reg-spinner" class="loading-icon fa fa-spin fa-spinner d-none"></i> {{ $websiteLang->where('lang_key','create_account')->first()->custom_text }}</button>

                        
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!--======= LOGON PART END========-->



@php
    $search_url = request()->fullUrl();
@endphp


<script>
    (function($) {
    "use strict";
    $(document).ready(function () {
        $("#userLoginBtn").on('click',function(e) {
            e.preventDefault();
            $.ajax({
                url: "{{ route('login') }}",
                type:"post",
                data:$('#loginFormSubmit').serialize(),
                success:function(response){
                    
                    if(response.success){
                        window.location.href = "{{ route('user.dashboard')}}";
                        toastr.success(response.success)

                    }
                    if(response.error){
                        toastr.error(response.error)

                        var query_url='<?php echo $search_url; ?>';
                        window.location.href = query_url;

                    }
                },
                error:function(response){
                    if(response.responseJSON.errors.email)toastr.error(response.responseJSON.errors.email[0])
                    if(response.responseJSON.errors.password){
                        toastr.error(response.responseJSON.errors.password[0])
                    }else{
                        toastr.error('Please Complete the recaptcha to submit the form')
                    }


                }

            });


        })


        $(document).on('keyup', '#loginEmail, #loginPassword', function (e) {
            if(e.keyCode == 13){
                e.preventDefault();

                $.ajax({
                url: "{{ route('login') }}",
                type:"post",
                data:$('#loginFormSubmit').serialize(),
                success:function(response){
                    if(response.success){
                        window.location.href = "{{ route('user.dashboard')}}";
                        toastr.success(response.success)

                    }
                    if(response.error){
                        toastr.error(response.error)

                        var query_url='<?php echo $search_url; ?>';
                        window.location.href = query_url;

                    }
                },
                error:function(response){


                    if(response.responseJSON.errors.email)toastr.error(response.responseJSON.errors.email[0])
                    if(response.responseJSON.errors.password){
                        toastr.error(response.responseJSON.errors.password[0])
                    }else{
                        toastr.error('Please Complete the recaptcha to submit the form')
                    }

                }

            });
            }

        })



        


        $("#registerBtnn").on('click',function(e) {
            e.preventDefault();
                // project demo mode check
                var isDemo="{{ env('PROJECT_MODE') }}"
                var demoNotify="{{ env('NOTIFY_TEXT') }}"
                if(isDemo==0){
                    toastr.error(demoNotify);
                    return;
                }
                // end
            $("#reg-spinner").removeClass('d-none')
            $("#registerBtnn").addClass('custom-opacity')
            $("#registerBtnn").attr('disabled',true);
            $.ajax({
                url: "{{route('otp-verify')}}",
                type:"post",
                data:$('#registerFormSubmitt').serialize(),
                success:function(response){
                   
                    if(response.success){
                        $("#registerFormSubmitt").trigger("reset");
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtnn").removeClass('custom-opacity')
                        $("#registerBtnn").attr('disabled',false);
                        toastr.success(response.success)

                        window.location.href = "{{route('otp-verification')}}";
                    }
                    if(response.error){
                        toastr.error(response.error)

                        var query_url='<?php echo $search_url; ?>';
                        window.location.href = query_url;
                    }
                },
                error:function(response){
                   
                    if(response.responseJSON.errors.email){
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtnn").removeClass('custom-opacity')
                        $("#registerBtnn").attr('disabled',false);
                        $("#registerBtnn").addClass('site-btn-effect')
                        toastr.error(response.responseJSON.errors.email[0])
                    }
                    if(response.responseJSON.errors.number){
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtnn").removeClass('custom-opacity')
                        $("#registerBtnn").attr('disabled',false);
                        $("#registerBtnn").addClass('site-btn-effect')
                        toastr.error(response.responseJSON.errors.number[0])
                    }//else{
                       // $("#reg-spinner").addClass('d-none')
                       // $("#registerBtnn").removeClass('custom-opacity')
                       // $("#registerBtnn").attr('disabled',false);
                        //$("#registerBtnn").addClass('site-btn-effect')
                      //  toastr.error('Please Complete the recaptcha to submit the form')
                    //}



                }

            });


        })

        $(document).on('keyup', '#regiEmail, #regNumber', function (e) {
            if(e.keyCode == 13){
                e.preventDefault();
                // project demo mode check
                var isDemo="{{ env('PROJECT_MODE') }}"
                var demoNotify="{{ env('NOTIFY_TEXT') }}"
                if(isDemo==0){
                    toastr.error(demoNotify);
                    return;
                }
                // end
            $("#reg-spinner").removeClass('d-none')
            $("#registerBtn").addClass('custom-opacity')
            $("#registerBtn").attr('disabled',true);
            $.ajax({
                url: "{{ route('register') }}",
                type:"post",
                data:$('#registerFormSubmitt').serialize(),
                success:function(response){
                    console.log(response);
                    if(response.success){
                        $("#registerFormSubmitt").trigger("reset");
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        toastr.success(response.success)
                    }
                    if(response.error){
                        toastr.error(response.error)
                        var query_url='<?php echo $search_url; ?>';
                        window.location.href = query_url;
                    }
                },
                error:function(response){
                    console.log(response);
                    

                    if(response.responseJSON.errors.email){
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        $("#registerBtn").addClass('site-btn-effect')
                        toastr.error(response.responseJSON.errors.email[0])
                    }

                    if(response.responseJSON.errors.password){
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        $("#registerBtn").addClass('site-btn-effect')
                        toastr.error(response.responseJSON.errors.password[0])
                    }//else{
                      //  $("#reg-spinner").addClass('d-none')
                      //  $("#registerBtn").removeClass('custom-opacity')
                      //  $("#registerBtn").attr('disabled',false);
                      //  $("#registerBtn").addClass('site-btn-effect')
                       // toastr.error('Please Complete the recaptcha to submit the form')
                   // }


                }

            });

            }

        })

    });

    })(jQuery);


    $("window").load(function(){
        $("#button").hide();
    });

    
</script>


<script>

        $("#registration_form").hide();
  

$(".individual").click(function(e){
    e.preventDefault();
    $("#reg_button").hide();
    $("#registration_form").show();
    $('#reg_type').val('1');

  // if($(this).attr('type') == 'indv_reg'){  
     //   console.log('hello');
    //    $("input[name='reg_type']").val('1');
   // } else {
    //    console.log('hii');
     //   $("input[name='reg_type']").val('2');
    //}
});

$(".agent").click(function(e){
    e.preventDefault();
    $("#reg_button").hide();
    $("#registration_form").show();
    $('#reg_type').val('2');
});

</script>

{{-- 
$("#registerBtn").on('click',function(e) { 
            e.preventDefault();
                // project demo mode check
                var isDemo="{{ env('PROJECT_MODE') }}"
                var demoNotify="{{ env('NOTIFY_TEXT') }}"
                if(isDemo==0){
                    toastr.error(demoNotify);
                    return;
                }
                // end
            $("#reg-spinner").removeClass('d-none')
            $("#registerBtn").addClass('custom-opacity')
            $("#registerBtn").attr('disabled',true);
            $.ajax({
                url: "{{ route('register') }}",
                type:"post",
                data:$('#registerFormSubmit').serialize(),
                success:function(response){
                    if(response.success){
                        $("#registerFormSubmit").trigger("reset");
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        toastr.success(response.success)
                    }
                    if(response.error){
                        toastr.error(response.error)

                        var query_url='<?php echo $search_url; ?>';
                        window.location.href = query_url;
                    }
                },
                error:function(response){
                    if(response.responseJSON.errors.name){
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        $("#registerBtn").addClass('site-btn-effect')
                        toastr.error(response.responseJSON.errors.name[0])
                    }

                    if(response.responseJSON.errors.email){
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        $("#registerBtn").addClass('site-btn-effect')
                        toastr.error(response.responseJSON.errors.email[0])
                    }

                    if(response.responseJSON.errors.password){
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        $("#registerBtn").addClass('site-btn-effect')
                        toastr.error(response.responseJSON.errors.password[0])
                    }else{
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        $("#registerBtn").addClass('site-btn-effect')
                        toastr.error('Please Complete the recaptcha to submit the form')
                    }



                }

            });


        })

        $(document).on('keyup', '#regEmail, #regPassword, #regName', function (e) {
            if(e.keyCode == 13){
                e.preventDefault();
                // project demo mode check
                var isDemo="{{ env('PROJECT_MODE') }}"
                var demoNotify="{{ env('NOTIFY_TEXT') }}"
                if(isDemo==0){
                    toastr.error(demoNotify);
                    return;
                }
                // end
            $("#reg-spinner").removeClass('d-none')
            $("#registerBtn").addClass('custom-opacity')
            $("#registerBtn").attr('disabled',true);
            $.ajax({
                url: "{{ route('register') }}",
                type:"post",
                data:$('#registerFormSubmit').serialize(),
                success:function(response){
                    if(response.success){
                        $("#registerFormSubmit").trigger("reset");
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        toastr.success(response.success)
                    }
                    if(response.error){
                        toastr.error(response.error)
                        var query_url='<?php echo $search_url; ?>';
                        window.location.href = query_url;
                    }
                },
                error:function(response){
                    if(response.responseJSON.errors.name){
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        $("#registerBtn").addClass('site-btn-effect')
                        toastr.error(response.responseJSON.errors.name[0])
                    }

                    if(response.responseJSON.errors.email){
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        $("#registerBtn").addClass('site-btn-effect')
                        toastr.error(response.responseJSON.errors.email[0])
                    }

                    if(response.responseJSON.errors.password){
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        $("#registerBtn").addClass('site-btn-effect')
                        toastr.error(response.responseJSON.errors.password[0])
                    }else{
                        $("#reg-spinner").addClass('d-none')
                        $("#registerBtn").removeClass('custom-opacity')
                        $("#registerBtn").attr('disabled',false);
                        $("#registerBtn").addClass('site-btn-effect')
                        toastr.error('Please Complete the recaptcha to submit the form')
                    }


                }

            });

            }

        })
--}}

@endsection


