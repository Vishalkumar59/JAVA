
@include('layouts.agents.header')
  @yield('agent-content')
@include('layouts.agents.footer')
